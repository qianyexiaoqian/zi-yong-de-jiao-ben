import{s as ae,v as le,x as ne,y as n,z as d,A as c,C as de,D as ie,E as C,G as b,H as te,d as se,I as be,N as he,J as ue,k as B,K as ke,L as ve,M as fe,O as xe,P as me,Q as V,R as ge,m as H,S as I,T as Ce,U as pe,V as $}from"../index.js";import{b as ze}from"./auth-I6YyRZIK.js";const we={sizeSmall:"14px",sizeMedium:"16px",sizeLarge:"18px",labelPadding:"0 8px",labelFontWeight:"400"};function ye(o){const{baseColor:a,inputColorDisabled:t,cardColor:h,modalColor:v,popoverColor:D,textColorDisabled:u,borderColor:k,primaryColor:s,textColor2:r,fontSizeSmall:f,fontSizeMedium:x,fontSizeLarge:p,borderRadiusSmall:z,lineHeight:m}=o;return Object.assign(Object.assign({},we),{labelLineHeight:m,fontSizeSmall:f,fontSizeMedium:x,fontSizeLarge:p,borderRadius:z,color:a,colorChecked:s,colorDisabled:t,colorDisabledChecked:t,colorTableHeader:h,colorTableHeaderModal:v,colorTableHeaderPopover:D,checkMarkColor:a,checkMarkColorDisabled:u,checkMarkColorDisabledChecked:u,border:`1px solid ${k}`,borderDisabled:`1px solid ${k}`,borderDisabledChecked:`1px solid ${k}`,borderChecked:`1px solid ${s}`,borderFocus:`1px solid ${s}`,boxShadowFocus:`0 0 0 2px ${le(s,{alpha:.3})}`,textColor:r,textColorDisabled:u})}const Se={common:ae,self:ye},Re=ne("n-checkbox-group"),De=()=>n("svg",{viewBox:"0 0 64 64",class:"check-icon"},n("path",{d:"M50.42,16.76L22.34,39.45l-8.1-11.46c-1.12-1.58-3.3-1.96-4.88-0.84c-1.58,1.12-1.95,3.3-0.84,4.88l10.26,14.51  c0.56,0.79,1.42,1.31,2.38,1.45c0.16,0.02,0.32,0.03,0.48,0.03c0.8,0,1.57-0.27,2.2-0.78l30.99-25.03c1.5-1.21,1.74-3.42,0.52-4.92  C54.13,15.78,51.93,15.55,50.42,16.76z"})),Me=()=>n("svg",{viewBox:"0 0 100 100",class:"line-icon"},n("path",{d:"M80.2,55.5H21.4c-2.8,0-5.1-2.5-5.1-5.5l0,0c0-3,2.3-5.5,5.1-5.5h58.7c2.8,0,5.1,2.5,5.1,5.5l0,0C85.2,53.1,82.9,55.5,80.2,55.5z"})),$e=d([c("checkbox",`
 font-size: var(--n-font-size);
 outline: none;
 cursor: pointer;
 display: inline-flex;
 flex-wrap: nowrap;
 align-items: flex-start;
 word-break: break-word;
 line-height: var(--n-size);
 --n-merged-color-table: var(--n-color-table);
 `,[C("show-label","line-height: var(--n-label-line-height);"),d("&:hover",[c("checkbox-box",[b("border","border: var(--n-border-checked);")])]),d("&:focus:not(:active)",[c("checkbox-box",[b("border",`
 border: var(--n-border-focus);
 box-shadow: var(--n-box-shadow-focus);
 `)])]),C("inside-table",[c("checkbox-box",`
 background-color: var(--n-merged-color-table);
 `)]),C("checked",[c("checkbox-box",`
 background-color: var(--n-color-checked);
 `,[c("checkbox-icon",[d(".check-icon",`
 opacity: 1;
 transform: scale(1);
 `)])])]),C("indeterminate",[c("checkbox-box",[c("checkbox-icon",[d(".check-icon",`
 opacity: 0;
 transform: scale(.5);
 `),d(".line-icon",`
 opacity: 1;
 transform: scale(1);
 `)])])]),C("checked, indeterminate",[d("&:focus:not(:active)",[c("checkbox-box",[b("border",`
 border: var(--n-border-checked);
 box-shadow: var(--n-box-shadow-focus);
 `)])]),c("checkbox-box",`
 background-color: var(--n-color-checked);
 border-left: 0;
 border-top: 0;
 `,[b("border",{border:"var(--n-border-checked)"})])]),C("disabled",{cursor:"not-allowed"},[C("checked",[c("checkbox-box",`
 background-color: var(--n-color-disabled-checked);
 `,[b("border",{border:"var(--n-border-disabled-checked)"}),c("checkbox-icon",[d(".check-icon, .line-icon",{fill:"var(--n-check-mark-color-disabled-checked)"})])])]),c("checkbox-box",`
 background-color: var(--n-color-disabled);
 `,[b("border",`
 border: var(--n-border-disabled);
 `),c("checkbox-icon",[d(".check-icon, .line-icon",`
 fill: var(--n-check-mark-color-disabled);
 `)])]),b("label",`
 color: var(--n-text-color-disabled);
 `)]),c("checkbox-box-wrapper",`
 position: relative;
 width: var(--n-size);
 flex-shrink: 0;
 flex-grow: 0;
 user-select: none;
 -webkit-user-select: none;
 `),c("checkbox-box",`
 position: absolute;
 left: 0;
 top: 50%;
 transform: translateY(-50%);
 height: var(--n-size);
 width: var(--n-size);
 display: inline-block;
 box-sizing: border-box;
 border-radius: var(--n-border-radius);
 background-color: var(--n-color);
 transition: background-color 0.3s var(--n-bezier);
 `,[b("border",`
 transition:
 border-color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier);
 border-radius: inherit;
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 border: var(--n-border);
 `),c("checkbox-icon",`
 display: flex;
 align-items: center;
 justify-content: center;
 position: absolute;
 left: 1px;
 right: 1px;
 top: 1px;
 bottom: 1px;
 `,[d(".check-icon, .line-icon",`
 width: 100%;
 fill: var(--n-check-mark-color);
 opacity: 0;
 transform: scale(0.5);
 transform-origin: center;
 transition:
 fill 0.3s var(--n-bezier),
 transform 0.3s var(--n-bezier),
 opacity 0.3s var(--n-bezier),
 border-color 0.3s var(--n-bezier);
 `),te({left:"1px",top:"1px"})])]),b("label",`
 color: var(--n-text-color);
 transition: color .3s var(--n-bezier);
 user-select: none;
 -webkit-user-select: none;
 padding: var(--n-label-padding);
 font-weight: var(--n-label-font-weight);
 `,[d("&:empty",{display:"none"})])]),de(c("checkbox",`
 --n-merged-color-table: var(--n-color-table-modal);
 `)),ie(c("checkbox",`
 --n-merged-color-table: var(--n-color-table-popover);
 `))]),Te=Object.assign(Object.assign({},V.props),{size:String,checked:{type:[Boolean,String,Number],default:void 0},defaultChecked:{type:[Boolean,String,Number],default:!1},value:[String,Number],disabled:{type:Boolean,default:void 0},indeterminate:Boolean,label:String,focusable:{type:Boolean,default:!0},checkedValue:{type:[Boolean,String,Number],default:!0},uncheckedValue:{type:[Boolean,String,Number],default:!1},"onUpdate:checked":[Function,Array],onUpdateChecked:[Function,Array],privateInsideTable:Boolean,onChange:[Function,Array]}),Ie=se({name:"Checkbox",props:Te,setup(o){const a=xe(Re,null),t=B(null),{mergedClsPrefixRef:h,inlineThemeDisabled:v,mergedRtlRef:D}=ke(o),u=B(o.defaultChecked),k=ve(o,"checked"),s=ze(k,u),r=fe(()=>{if(a){const e=a.valueSetRef.value;return e&&o.value!==void 0?e.has(o.value):!1}else return s.value===o.checkedValue}),f=me(o,{mergedSize(e){const{size:i}=o;if(i!==void 0)return i;if(a){const{value:l}=a.mergedSizeRef;if(l!==void 0)return l}if(e){const{mergedSize:l}=e;if(l!==void 0)return l.value}return"medium"},mergedDisabled(e){const{disabled:i}=o;if(i!==void 0)return i;if(a){if(a.disabledRef.value)return!0;const{maxRef:{value:l},checkedCountRef:g}=a;if(l!==void 0&&g.value>=l&&!r.value)return!0;const{minRef:{value:S}}=a;if(S!==void 0&&g.value<=S&&r.value)return!0}return e?e.disabled.value:!1}}),{mergedDisabledRef:x,mergedSizeRef:p}=f,z=V("Checkbox","-checkbox",$e,Se,o,h);function m(e){if(a&&o.value!==void 0)a.toggleCheckbox(!r.value,o.value);else{const{onChange:i,"onUpdate:checked":l,onUpdateChecked:g}=o,{nTriggerFormInput:S,nTriggerFormChange:M}=f,R=r.value?o.uncheckedValue:o.checkedValue;l&&$(l,R,e),g&&$(g,R,e),i&&$(i,R,e),S(),M(),u.value=R}}function w(e){x.value||m(e)}function F(e){if(!x.value)switch(e.key){case" ":case"Enter":m(e)}}function K(e){switch(e.key){case" ":e.preventDefault()}}const P={focus:()=>{var e;(e=t.value)===null||e===void 0||e.focus()},blur:()=>{var e;(e=t.value)===null||e===void 0||e.blur()}},j=ge("Checkbox",D,h),T=H(()=>{const{value:e}=p,{common:{cubicBezierEaseInOut:i},self:{borderRadius:l,color:g,colorChecked:S,colorDisabled:M,colorTableHeader:R,colorTableHeaderModal:N,colorTableHeaderPopover:L,checkMarkColor:U,checkMarkColorDisabled:_,border:E,borderFocus:O,borderDisabled:A,borderChecked:G,boxShadowFocus:W,textColor:J,textColorDisabled:Q,checkMarkColorDisabledChecked:Y,colorDisabledChecked:q,borderDisabledChecked:X,labelPadding:Z,labelLineHeight:ee,labelFontWeight:oe,[I("fontSize",e)]:re,[I("size",e)]:ce}}=z.value;return{"--n-label-line-height":ee,"--n-label-font-weight":oe,"--n-size":ce,"--n-bezier":i,"--n-border-radius":l,"--n-border":E,"--n-border-checked":G,"--n-border-focus":O,"--n-border-disabled":A,"--n-border-disabled-checked":X,"--n-box-shadow-focus":W,"--n-color":g,"--n-color-checked":S,"--n-color-table":R,"--n-color-table-modal":N,"--n-color-table-popover":L,"--n-color-disabled":M,"--n-color-disabled-checked":q,"--n-text-color":J,"--n-text-color-disabled":Q,"--n-check-mark-color":U,"--n-check-mark-color-disabled":_,"--n-check-mark-color-disabled-checked":Y,"--n-font-size":re,"--n-label-padding":Z}}),y=v?Ce("checkbox",H(()=>p.value[0]),T,o):void 0;return Object.assign(f,P,{rtlEnabled:j,selfRef:t,mergedClsPrefix:h,mergedDisabled:x,renderedChecked:r,mergedTheme:z,labelId:pe(),handleClick:w,handleKeyUp:F,handleKeyDown:K,cssVars:v?void 0:T,themeClass:y==null?void 0:y.themeClass,onRender:y==null?void 0:y.onRender})},render(){var o;const{$slots:a,renderedChecked:t,mergedDisabled:h,indeterminate:v,privateInsideTable:D,cssVars:u,labelId:k,label:s,mergedClsPrefix:r,focusable:f,handleKeyUp:x,handleKeyDown:p,handleClick:z}=this;(o=this.onRender)===null||o===void 0||o.call(this);const m=be(a.default,w=>s||w?n("span",{class:`${r}-checkbox__label`,id:k},s||w):null);return n("div",{ref:"selfRef",class:[`${r}-checkbox`,this.themeClass,this.rtlEnabled&&`${r}-checkbox--rtl`,t&&`${r}-checkbox--checked`,h&&`${r}-checkbox--disabled`,v&&`${r}-checkbox--indeterminate`,D&&`${r}-checkbox--inside-table`,m&&`${r}-checkbox--show-label`],tabindex:h||!f?void 0:0,role:"checkbox","aria-checked":v?"mixed":t,"aria-labelledby":k,style:u,onKeyup:x,onKeydown:p,onClick:z,onMousedown:()=>{ue("selectstart",window,w=>{w.preventDefault()},{once:!0})}},n("div",{class:`${r}-checkbox-box-wrapper`}," ",n("div",{class:`${r}-checkbox-box`},n(he,null,{default:()=>this.indeterminate?n("div",{key:"indeterminate",class:`${r}-checkbox-icon`},Me()):n("div",{key:"check",class:`${r}-checkbox-icon`},De())}),n("div",{class:`${r}-checkbox-box__border`}))),m)}});export{Ie as N};
