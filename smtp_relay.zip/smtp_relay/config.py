# ============================================
# SMTP 中继服务配置文件
# 复制此文件为 config.py 并修改配置
# ============================================

# 本地监听配置（面板连接这个）
# Windows: 填具体内网IP（如 192.168.100.9）或 127.0.0.1（仅本机）
# Linux: 可用 0.0.0.0 监听所有接口
LOCAL_HOST = '0.0.0.0'

# ---- 端口 1：无加密端口（可选）----
PLAIN_ENABLED = True          # 是否启用无加密端口
PLAIN_PORT = 2525             # 无加密端口（面板加密选"无"）

# ---- 端口 2：SSL 加密端口（可选）----
SSL_ENABLED = False           # 是否启用 SSL 端口
SSL_PORT = 2526               # SSL 端口（面板加密选"SSL"）

# 本地认证（面板填这个账号密码，两个端口共用）
# 设为空字符串则禁用认证
LOCAL_USER = 'admin'
LOCAL_PASS = 'your_password_here'

# SSL/TLS 证书配置（SSL 端口需要）
# 留空则自动生成自签名证书（自签名证书会包含 LOCAL_HOST 的 IP/域名）
# 填写路径则使用自定义证书（需要 cert 和 key 两个文件）
LOCAL_CERT_FILE = ''  # 证书文件路径，如: '/path/to/cert.pem'
LOCAL_KEY_FILE = ''   # 私钥文件路径，如: '/path/to/key.pem'

# IP 白名单配置
# 开启后，只有白名单中的 IP 才能连接
IP_WHITELIST_ENABLED = False  # True=开启白名单, False=关闭（允许所有IP）
IP_WHITELIST = [
    # '127.0.0.1',
    # '192.168.1.100',
    # '10.0.0.0/8',      # 支持 CIDR 格式
    # '192.168.0.0/16',
]

# ============================================
# 测试模式：纯文本邮件（去除所有 HTML/UI）
# ============================================
# 开启后，邮件会被转换为纯文本格式，去除所有 HTML 样式
# 用于测试是否因为邮件模板 UI 特征被拦截
PLAIN_TEXT_MODE = False  # True=纯文本模式, False=保留原始HTML

# ============================================
# 远程 SMTP 配置（真实发信服务器）
# ============================================

# 负载均衡模式
# 'random'      - 随机选择服务器
# 'round_robin' - 轮询（按顺序循环）
LOAD_BALANCE_MODE = 'random'

# 服务器列表（支持多个，至少配置一个）
# enabled: 是否启用该服务器
# host: SMTP 服务器地址
# port: 端口（465=SSL, 587=TLS, 25=无加密）
# ssl: 是否使用 SSL（端口465时设为 True）
# tls: 是否使用 STARTTLS（仅当 ssl=False 时有效，端口587时设为 True）
# user: 登录用户名（通常是邮箱地址）
# pass: 登录密码
REMOTE_SERVERS = [
    {
        'enabled': True,
        'host': 'smtp.example.com',
        'port': 465,
        'ssl': True,
        'tls': False,
        'user': 'your_email@example.com',
        'pass': 'your_smtp_password',
    },
    # 可以添加更多服务器，示例：
    # {
    #     'enabled': True,
    #     'host': 'smtp.gmail.com',
    #     'port': 587,
    #     'ssl': False,
    #     'tls': True,
    #     'user': 'user@gmail.com',
    #     'pass': 'app_password',
    # },
]

# 需要移除的邮件头
HEADERS_TO_REMOVE = [
    'X-Mailer',
    'X-Powered-By',
    'X-Laravel-Mailer',
    'X-PHP-Originating-Script',
    'X-PHP-Script',
]

# 敏感词列表（标题和内容中检测到会被删除）
SENSITIVE_WORDS = [
    'v2board',
    'V2Board',
    'V2board',
    'v2Board',
    'xboard',
    'Xboard',
    'XBoard',
    'XBOARD',
    'v2ray',
    'V2Ray',
    'V2RAY',
    'clash',
    'Clash',
    'CLASH',
    'shadowsocks',
    'Shadowsocks',
    'trojan',
    'Trojan',
    'vpn',
    'VPN',
    'Vpn',
    '翻墙',
    '科学上网',
    '机场',
    '节点',
    '梯子',
    '代理',
    'proxy',
    'Proxy',
    'PROXY',
    'ssr',
    'SSR',
]

# 日志级别: DEBUG, INFO, WARNING, ERROR
LOG_LEVEL = 'INFO'

