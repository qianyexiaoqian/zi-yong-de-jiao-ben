# SMTP 中继服务

清洗敏感邮件头，转发邮件。

## 原理

```
面板 → 中继服务(2525) → 清洗邮件头 → 发信服务器
```

## 安装

```bash
pip install -r requirements.txt
```

## 配置 config.py

```python
REMOTE_HOST = 'smtp.example.com'
REMOTE_PORT = 465
REMOTE_SSL = True
REMOTE_USER = 'your-email@example.com'
REMOTE_PASS = 'your-password'
```

## 运行

```bash
python smtp_relay.py
```

## 面板邮件设置

| 项目 | 值 |
|------|-----|
| 主机 | 127.0.0.1 |
| 端口 | 2525 |
| 加密 | 无 |
| 账号 | 留空 |
| 密码 | 留空 |

## 后台运行 (systemd)

```bash
sudo nano /etc/systemd/system/smtp-relay.service
```

```ini
[Unit]
Description=SMTP Relay
After=network.target

[Service]
Type=simple
WorkingDirectory=/path/to/smtp_relay
ExecStart=/usr/bin/python3 smtp_relay.py
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable smtp-relay
sudo systemctl start smtp-relay
```

## 移除的邮件头

- X-Mailer
- X-Powered-By
- X-Laravel-Mailer
- X-PHP-Originating-Script
- X-PHP-Script

