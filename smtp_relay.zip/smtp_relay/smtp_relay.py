#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SMTP 中继服务 - 剔除敏感邮件头和内容
支持 SSL/TLS/STARTTLS 加密，支持 IP 白名单，支持多服务器负载均衡
"""

import asyncio
import logging
import smtplib
import ssl
import os
import re
import random
import ipaddress
from email import policy
from email.parser import BytesParser
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.header import decode_header, make_header
from email.utils import formataddr, parseaddr
from aiosmtpd.controller import Controller
from aiosmtpd.smtp import SMTP, AuthResult

import config

# 轮询计数器（用于 round_robin 模式）
_round_robin_index = 0

# 兼容旧配置：如果存在 LOCAL_STARTTLS，转换为新格式
if hasattr(config, 'LOCAL_STARTTLS') and not hasattr(config, 'LOCAL_ENCRYPTION'):
    config.LOCAL_ENCRYPTION = 'STARTTLS' if config.LOCAL_STARTTLS else 'NONE'

# 确保 LOCAL_ENCRYPTION 存在
if not hasattr(config, 'LOCAL_ENCRYPTION'):
    config.LOCAL_ENCRYPTION = 'NONE'

# 确保白名单配置存在
if not hasattr(config, 'IP_WHITELIST_ENABLED'):
    config.IP_WHITELIST_ENABLED = False
if not hasattr(config, 'IP_WHITELIST'):
    config.IP_WHITELIST = ['127.0.0.1']

# 兼容旧版单服务器配置
if not hasattr(config, 'REMOTE_SERVERS'):
    config.REMOTE_SERVERS = [{
        'enabled': True,
        'host': getattr(config, 'REMOTE_HOST', 'localhost'),
        'port': getattr(config, 'REMOTE_PORT', 25),
        'ssl': getattr(config, 'REMOTE_SSL', False),
        'tls': getattr(config, 'REMOTE_TLS', False),
        'user': getattr(config, 'REMOTE_USER', ''),
        'pass': getattr(config, 'REMOTE_PASS', ''),
    }]

if not hasattr(config, 'LOAD_BALANCE_MODE'):
    config.LOAD_BALANCE_MODE = 'random'

logging.basicConfig(
    level=getattr(logging, config.LOG_LEVEL),
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)


def get_enabled_servers():
    """获取所有启用的服务器列表"""
    return [s for s in config.REMOTE_SERVERS if s.get('enabled', True)]


def select_server():
    """根据负载均衡模式选择服务器"""
    global _round_robin_index

    servers = get_enabled_servers()
    if not servers:
        raise RuntimeError("没有可用的远程服务器！请检查 REMOTE_SERVERS 配置。")

    if len(servers) == 1:
        return servers[0]

    mode = config.LOAD_BALANCE_MODE.lower()

    if mode == 'round_robin':
        # 轮询模式
        server = servers[_round_robin_index % len(servers)]
        _round_robin_index += 1
        return server
    else:
        # 默认随机模式
        return random.choice(servers)


# ============================================
# IP 白名单功能
# ============================================

def parse_whitelist():
    """解析白名单配置，返回 IP 地址和网络列表"""
    ip_addresses = set()
    ip_networks = []

    for item in config.IP_WHITELIST:
        item = item.strip()
        if not item:
            continue
        try:
            if '/' in item:
                # CIDR 格式，如 192.168.0.0/16
                ip_networks.append(ipaddress.ip_network(item, strict=False))
            else:
                # 单个 IP
                ip_addresses.add(ipaddress.ip_address(item))
        except ValueError as e:
            logger.warning(f"无效的白名单条目: {item} - {e}")

    return ip_addresses, ip_networks


def is_ip_allowed(client_ip: str) -> bool:
    """检查客户端 IP 是否在白名单中"""
    if not config.IP_WHITELIST_ENABLED:
        return True  # 白名单未启用，允许所有

    try:
        ip = ipaddress.ip_address(client_ip)
        ip_addresses, ip_networks = parse_whitelist()

        # 检查是否在单个 IP 列表中
        if ip in ip_addresses:
            return True

        # 检查是否在 CIDR 网段中
        for network in ip_networks:
            if ip in network:
                return True

        return False
    except ValueError:
        logger.error(f"无效的客户端 IP: {client_ip}")
        return False




# 默认证书文件路径（自签名证书保存位置）
DEFAULT_CERT_FILE = 'cert.pem'
DEFAULT_KEY_FILE = 'key.pem'


def get_cert_files():
    """获取证书文件路径（优先使用自定义证书）"""
    # 检查是否配置了自定义证书
    custom_cert = getattr(config, 'LOCAL_CERT_FILE', '')
    custom_key = getattr(config, 'LOCAL_KEY_FILE', '')

    if custom_cert and custom_key:
        if os.path.exists(custom_cert) and os.path.exists(custom_key):
            logger.info(f"使用自定义证书: {custom_cert}")
            return custom_cert, custom_key
        else:
            logger.warning(f"自定义证书不存在，将生成自签名证书")

    return DEFAULT_CERT_FILE, DEFAULT_KEY_FILE


def generate_self_signed_cert(cert_file, key_file):
    """生成自签名证书（包含 IP 和域名的 SAN）"""
    if os.path.exists(cert_file) and os.path.exists(key_file):
        logger.info(f"使用已存在的证书: {cert_file}")
        return

    try:
        from cryptography import x509
        from cryptography.x509.oid import NameOID
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.hazmat.backends import default_backend
        import datetime
        import ipaddress

        # 生成私钥
        key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
            backend=default_backend()
        )

        # 获取监听地址用于 SAN
        host = config.LOCAL_HOST

        # 构建 Subject Alternative Names (SAN)
        san_list = [
            x509.DNSName("localhost"),
            x509.DNSName("smtp-relay"),
            x509.IPAddress(ipaddress.IPv4Address("127.0.0.1")),
        ]

        # 添加配置的 HOST
        try:
            # 尝试作为 IP 地址添加
            ip = ipaddress.ip_address(host)
            san_list.append(x509.IPAddress(ip))
            cn_name = f"SMTP Relay ({host})"
        except ValueError:
            # 不是 IP，作为域名添加
            san_list.append(x509.DNSName(host))
            cn_name = host

        # 生成证书
        subject = issuer = x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, cn_name),
        ])

        cert = (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(issuer)
            .public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(datetime.datetime.utcnow())
            .not_valid_after(datetime.datetime.utcnow() + datetime.timedelta(days=3650))
            .add_extension(
                x509.SubjectAlternativeName(san_list),
                critical=False
            )
            .sign(key, hashes.SHA256(), default_backend())
        )

        # 保存私钥
        with open(key_file, "wb") as f:
            f.write(key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.TraditionalOpenSSL,
                encryption_algorithm=serialization.NoEncryption()
            ))

        # 保存证书
        with open(cert_file, "wb") as f:
            f.write(cert.public_bytes(serialization.Encoding.PEM))

        logger.info(f"已生成自签名证书: {cert_file}")
        logger.info(f"证书包含 SAN: localhost, smtp-relay, 127.0.0.1, {host}")

    except ImportError:
        logger.error("需要安装 cryptography: pip install cryptography")
        raise


def create_tls_context(cert_file, key_file):
    """创建 TLS 上下文"""
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(cert_file, key_file)
    return context




class Authenticator:
    """SMTP 认证处理器"""

    def __call__(self, server, session, envelope, mechanism, auth_data):
        logger.info(f">>> 认证器被调用: mechanism={mechanism}")

        # 解析认证数据
        try:
            # 新版 aiosmtpd 统一使用 LoginPassword 对象
            if hasattr(auth_data, 'login') and hasattr(auth_data, 'password'):
                login = auth_data.login
                pwd = auth_data.password
                username = login if isinstance(login, str) else login.decode('utf-8')
                password = pwd if isinstance(pwd, str) else pwd.decode('utf-8')
            elif isinstance(auth_data, bytes):
                # 旧版可能是原始字节
                parts = auth_data.split(b'\x00')
                if len(parts) == 3:
                    username = parts[1].decode('utf-8')
                    password = parts[2].decode('utf-8')
                elif len(parts) == 2:
                    username = parts[0].decode('utf-8')
                    password = parts[1].decode('utf-8')
                else:
                    logger.warning(f"认证格式错误")
                    return False
            else:
                logger.warning(f"未知认证数据格式: {type(auth_data)}")
                return False

            # 验证账号密码
            if username == config.LOCAL_USER and password == config.LOCAL_PASS:
                logger.info(f"✓ 认证成功: {username}")
                # 返回 AuthResult 对象表示认证成功
                return AuthResult(success=True, handled=True, auth_data=username)
            else:
                logger.warning(f"✗ 认证失败: 用户={username}")
                return AuthResult(success=False, handled=True)

        except Exception as e:
            logger.error(f"认证错误: {e}")
            import traceback
            traceback.print_exc()
            return AuthResult(success=False, handled=True)


class RelayHandler:
    """SMTP 邮件处理器，支持 IP 白名单检查"""

    async def handle_MAIL(self, server, session, envelope, address, mail_options):
        """在 MAIL FROM 时检查 IP 白名单"""
        client_ip = session.peer[0] if session.peer else None

        if not is_ip_allowed(client_ip):
            logger.warning(f"IP 白名单拒绝 MAIL FROM: {client_ip}")
            return '550 Access denied: IP not in whitelist'

        logger.info(f"MAIL FROM: {address} (客户端: {client_ip})")
        envelope.mail_from = address
        envelope.mail_options.extend(mail_options)
        return '250 OK'

    async def handle_RCPT(self, server, session, envelope, address, rcpt_options):
        """在 RCPT TO 时检查 IP 白名单"""
        client_ip = session.peer[0] if session.peer else None

        if not is_ip_allowed(client_ip):
            logger.warning(f"IP 白名单拒绝 RCPT TO: {client_ip}")
            return '550 Access denied: IP not in whitelist'

        envelope.rcpt_tos.append(address)
        envelope.rcpt_options.extend(rcpt_options)
        return '250 OK'

    async def handle_DATA(self, server, session, envelope):
        try:
            logger.info(f"收到邮件: {envelope.mail_from} -> {envelope.rcpt_tos}")

            # 解析原始邮件
            raw_email = envelope.content
            if isinstance(raw_email, bytes):
                from email import message_from_bytes
                original_msg = message_from_bytes(raw_email)
            else:
                from email import message_from_string
                original_msg = message_from_string(raw_email)

            # 完全重构邮件（只保留必要信息）
            new_msg = self._rebuild_email(original_msg, envelope.rcpt_tos)

            # 转换为字符串
            cleaned_email = new_msg.as_string()

            # 保存调试文件，查看最终发送的邮件
            with open('last_email_debug.txt', 'w', encoding='utf-8') as f:
                f.write(cleaned_email)
            logger.info("已保存调试邮件到 last_email_debug.txt")

            # 转发邮件（发件人由 _send_mail 根据所选服务器决定）
            if self._send_mail(None, envelope.rcpt_tos, cleaned_email):
                logger.info(f"✓ 发送成功: {envelope.rcpt_tos}")
                return '250 OK'
            else:
                logger.error(f"✗ 发送失败: {envelope.rcpt_tos}")
                return '550 Failed'

        except Exception as e:
            logger.error(f"错误: {e}", exc_info=True)
            return f'550 Error: {str(e)}'

    def _rebuild_email(self, original_msg, rcpt_tos):
        """完全重构邮件，移除所有可疑特征"""
        from email.mime.multipart import MIMEMultipart
        from email.mime.text import MIMEText
        from email.utils import formatdate, make_msgid

        # 提取并清洗主题
        subject = self._extract_clean_subject(original_msg)

        # 提取并清洗正文
        html_body, text_body = self._extract_clean_body(original_msg)

        # 纯文本测试模式：将 HTML 转换为纯文本
        if getattr(config, 'PLAIN_TEXT_MODE', False) and html_body:
            plain_body = self._html_to_plain_text(html_body)
            logger.info("纯文本模式：已将 HTML 转换为纯文本")
            new_msg = MIMEText(plain_body, 'plain', 'utf-8')
        # 正常模式
        elif html_body and text_body:
            new_msg = MIMEMultipart('alternative')
            new_msg.attach(MIMEText(text_body, 'plain', 'utf-8'))
            new_msg.attach(MIMEText(html_body, 'html', 'utf-8'))
        elif html_body:
            new_msg = MIMEText(html_body, 'html', 'utf-8')
        else:
            new_msg = MIMEText(text_body or '', 'plain', 'utf-8')

        # 选择服务器获取发件人域名
        srv = select_server()
        sender_email = srv['user']
        sender_domain = sender_email.split('@')[1] if '@' in sender_email else 'mail.local'

        # 生成更自然的 Message-ID（模拟常见邮件客户端格式）
        import uuid
        import time
        msg_id = f"<{uuid.uuid4().hex}@{sender_domain}>"

        # 提取原始邮件的发件人显示名称
        original_from = original_msg.get('From', '')
        display_name = ''
        if original_from:
            # 解析 "显示名称 <email@example.com>" 格式
            parsed_name, parsed_email = parseaddr(original_from)
            if parsed_name:
                # 解码显示名称（可能是 MIME 编码）
                try:
                    decoded_parts = decode_header(parsed_name)
                    display_name = str(make_header(decoded_parts))
                except Exception:
                    display_name = parsed_name

        # 组合发件人：保留原始显示名称 + 使用真实发信邮箱
        if display_name:
            # 使用 formataddr 正确编码非 ASCII 显示名称
            from email.header import Header
            # formataddr 需要 (name, email) 元组
            new_msg['From'] = formataddr((display_name, sender_email))
        else:
            new_msg['From'] = sender_email
        new_msg['To'] = ', '.join(rcpt_tos)

        # 正确编码主题（处理非 ASCII 字符）
        if subject:
            from email.header import Header
            # 检查是否包含非 ASCII 字符
            try:
                subject.encode('ascii')
                new_msg['Subject'] = subject
            except UnicodeEncodeError:
                # 包含非 ASCII 字符，使用 UTF-8 编码
                new_msg['Subject'] = Header(subject, 'utf-8')
        else:
            new_msg['Subject'] = ''

        new_msg['Date'] = formatdate(localtime=True)
        new_msg['Message-ID'] = msg_id
        new_msg['MIME-Version'] = '1.0'

        # 保存选中的服务器信息供 _send_mail 使用
        self._selected_server = srv

        subject_preview = subject[:50] if subject else '(无主题)'
        logger.info(f"邮件已重构，主题: {subject_preview}...")
        return new_msg

    def _extract_clean_subject(self, msg):
        """提取并清洗邮件主题"""
        subject = msg.get('Subject', '')
        if subject:
            try:
                decoded_parts = decode_header(subject)
                decoded_subject = ''
                for part, charset in decoded_parts:
                    if isinstance(part, bytes):
                        decoded_subject += part.decode(charset or 'utf-8', errors='replace')
                    else:
                        decoded_subject += part
                subject = decoded_subject
            except:
                pass

        # 删除敏感词
        cleaned, removed = self._remove_sensitive_words(subject)
        if removed:
            logger.info(f"主题中删除敏感词: {removed}")
        return cleaned

    def _extract_clean_body(self, msg):
        """提取并清洗邮件正文"""
        html_body = None
        text_body = None

        if msg.is_multipart():
            for part in msg.walk():
                content_type = part.get_content_type()
                if content_type == 'text/html' and html_body is None:
                    html_body = self._decode_part(part)
                elif content_type == 'text/plain' and text_body is None:
                    text_body = self._decode_part(part)
        else:
            content_type = msg.get_content_type()
            content = self._decode_part(msg)
            if content_type == 'text/html':
                html_body = content
            else:
                text_body = content

        # 清洗敏感词
        if html_body:
            html_body, removed = self._remove_sensitive_words(html_body)
            if removed:
                logger.info(f"HTML正文中删除敏感词: {removed}")

        if text_body:
            text_body, removed = self._remove_sensitive_words(text_body)
            if removed:
                logger.info(f"文本正文中删除敏感词: {removed}")

        return html_body, text_body

    def _decode_part(self, part):
        """解码 MIME 部分"""
        try:
            charset = part.get_content_charset() or 'utf-8'
            payload = part.get_payload(decode=True)
            if payload:
                return payload.decode(charset, errors='replace')
        except Exception as e:
            logger.warning(f"解码失败: {e}")
        return None



    def _remove_sensitive_words(self, text: str) -> tuple:
        """删除敏感词，返回 (清洗后的文本, 删除的词列表)"""
        import re
        cleaned = text
        removed = []

        # 从配置中获取敏感域名列表（可选配置）
        sensitive_domains = getattr(config, 'SENSITIVE_DOMAINS', [])

        # 处理 HTML 链接：删除包含敏感域名的整个 <a> 标签
        for domain in sensitive_domains:
            # 匹配包含敏感域名的整个 <a>...</a> 标签
            pattern = rf'<a[^>]*href="[^"]*{re.escape(domain)}[^"]*"[^>]*>.*?</a>'
            if re.search(pattern, cleaned, re.IGNORECASE | re.DOTALL):
                cleaned = re.sub(pattern, '', cleaned, flags=re.IGNORECASE | re.DOTALL)
                if domain not in removed:
                    removed.append(f'链接({domain})')

        # 处理普通敏感词（只处理 config.SENSITIVE_WORDS 中的词）
        for word in config.SENSITIVE_WORDS:
            if word in cleaned:
                cleaned = cleaned.replace(word, '')
                if word not in removed:
                    removed.append(word)

        return cleaned, removed

    def _html_to_plain_text(self, html: str) -> str:
        """将 HTML 转换为纯文本，提取有效信息（验证码等）"""
        import re

        text = html

        # 移除 style 和 script 标签及其内容
        text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.DOTALL | re.IGNORECASE)
        text = re.sub(r'<script[^>]*>.*?</script>', '', text, flags=re.DOTALL | re.IGNORECASE)

        # 移除 HTML 注释（包括 mso 条件注释）
        text = re.sub(r'<!--.*?-->', '', text, flags=re.DOTALL)

        # 将 <br> 和 <br/> 转换为换行
        text = re.sub(r'<br\s*/?>', '\n', text, flags=re.IGNORECASE)

        # 将 </p>, </div>, </tr>, </td> 转换为换行
        text = re.sub(r'</(?:p|div|tr|td|table|thead|tbody)>', '\n', text, flags=re.IGNORECASE)

        # 移除所有 HTML 标签
        text = re.sub(r'<[^>]+>', '', text)

        # 解码 HTML 实体
        import html as html_module
        text = html_module.unescape(text)

        # 清理多余空白
        text = re.sub(r'[ \t]+', ' ', text)  # 多个空格/制表符合并为一个
        text = re.sub(r'\n\s*\n', '\n\n', text)  # 多个空行合并为两个
        text = text.strip()

        # 提取验证码（6位数字）并突出显示
        code_match = re.search(r'\b(\d{6})\b', text)
        if code_match:
            code = code_match.group(1)
            # 在文本末尾再次强调验证码
            text += f"\n\n【验证码: {code}】"

        return text

    def _send_mail(self, mail_from: str, rcpt_tos: list, msg: str) -> bool:
        """转发到真实 SMTP 服务器（支持多服务器负载均衡）"""
        srv = None
        try:
            # 使用已选择的服务器（在 _rebuild_email 中已选择）
            srv = getattr(self, '_selected_server', None) or select_server()
            sender = srv['user']
            logger.info(f"选择服务器: {srv['host']}:{srv['port']} (发件人: {sender})")

            # 保存实际发送的邮件到调试文件
            with open('last_email_sent.txt', 'w', encoding='utf-8') as f:
                f.write(msg)
            logger.info("已保存实际发送邮件到 last_email_sent.txt")

            # 连接服务器
            if srv['ssl']:
                server = smtplib.SMTP_SSL(srv['host'], srv['port'])
            else:
                server = smtplib.SMTP(srv['host'], srv['port'])
                if srv['tls']:
                    server.starttls()

            # 登录并发送
            server.login(srv['user'], srv['pass'])
            server.sendmail(sender, rcpt_tos, msg)
            server.quit()
            return True
        except Exception as e:
            host_info = srv['host'] if srv else 'unknown'
            logger.error(f"SMTP 错误 ({host_info}): {e}")
            return False

    def _replace_from_header(self, msg: str, new_from: str) -> str:
        """替换邮件中的 From 头"""
        import re
        # 替换 From: 头
        new_msg = re.sub(r'^From:.*$', f'From: {new_from}', msg, count=1, flags=re.MULTILINE)
        logger.info(f"From 头已替换为: {new_from}")
        return new_msg


def main():
    controllers = []

    # 认证配置（两个端口共用）
    auth_kwargs = {}
    if config.LOCAL_USER and config.LOCAL_PASS:
        auth_kwargs = {
            'authenticator': Authenticator(),
            'auth_required': True,
            'auth_require_tls': False,
        }
        auth_info = f"{config.LOCAL_USER} / {config.LOCAL_PASS}"
    else:
        auth_info = "无需认证"

    # IP 白名单状态
    if config.IP_WHITELIST_ENABLED:
        whitelist_info = f"✓ 已开启({len(config.IP_WHITELIST)}条)"
    else:
        whitelist_info = "✗ 关闭"

    # 读取配置
    plain_enabled = getattr(config, 'PLAIN_ENABLED', True)
    plain_port = getattr(config, 'PLAIN_PORT', 2525)
    ssl_enabled = getattr(config, 'SSL_ENABLED', False)
    ssl_port = getattr(config, 'SSL_PORT', 2526)

    # 检查至少启用一个端口
    if not plain_enabled and not ssl_enabled:
        print("错误: 至少需要启用一个端口 (PLAIN_ENABLED 或 SSL_ENABLED)")
        return

    # ---- 端口 1：无加密端口（可选）----
    if plain_enabled:
        plain_controller = Controller(
            RelayHandler(),
            hostname=config.LOCAL_HOST,
            port=plain_port,
            **auth_kwargs
        )
        controllers.append(plain_controller)
        port1_info = f"✓ {config.LOCAL_HOST}:{plain_port} (无加密)"
    else:
        port1_info = "✗ 未启用 (PLAIN_ENABLED=False)"

    # ---- 端口 2：SSL 加密端口（可选）----
    cert_info = ""
    if ssl_enabled:
        # 准备证书
        cert_file, key_file = get_cert_files()
        generate_self_signed_cert(cert_file, key_file)
        tls_context = create_tls_context(cert_file, key_file)
        cert_info = f"证书: {cert_file}"

        # 使用 Controller + ssl_context 参数
        ssl_controller = Controller(
            RelayHandler(),
            hostname=config.LOCAL_HOST,
            port=ssl_port,
            ssl_context=tls_context,
            **auth_kwargs
        )
        controllers.append(ssl_controller)
        port2_info = f"✓ {config.LOCAL_HOST}:{ssl_port} (SSL加密)"
    else:
        port2_info = "✗ 未启用 (SSL_ENABLED=False)"

    # 获取远程服务器信息
    enabled_servers = get_enabled_servers()
    mode_name = '随机' if config.LOAD_BALANCE_MODE.lower() == 'random' else '轮询'

    # 打印启动信息
    print(f"""
┌──────────────────────────────────────────────┐
│        SMTP 中继服务 - 邮件头清洗            │
├──────────────────────────────────────────────┤
│  无加密: {port1_info}
│  SSL加密: {port2_info}""")
    if ssl_enabled:
        print(f"│  {cert_info}")
    print(f"│  认证: {auth_info}")
    print(f"│  白名单: {whitelist_info}")
    print(f"├──────────────────────────────────────────────┤")
    print(f"│  远程服务器: {len(enabled_servers)}个 (负载均衡: {mode_name})")
    for i, srv in enumerate(enabled_servers, 1):
        ssl_mark = "SSL" if srv['ssl'] else ("TLS" if srv['tls'] else "无加密")
        print(f"│    {i}. {srv['host']}:{srv['port']} ({ssl_mark})")
    print(f"""├──────────────────────────────────────────────┤
│  Ctrl+C 停止                                 │
└──────────────────────────────────────────────┘
    """)

    # 启动所有 Controller
    for ctrl in controllers:
        ctrl.start()

    if plain_enabled:
        logger.info(f"无加密端口已启动: {config.LOCAL_HOST}:{plain_port}")
    if ssl_enabled:
        logger.info(f"SSL加密端口已启动: {config.LOCAL_HOST}:{ssl_port}")

    try:
        asyncio.get_event_loop().run_forever()
    except KeyboardInterrupt:
        for ctrl in controllers:
            ctrl.stop()
        print("\n已停止")


if __name__ == '__main__':
    main()

