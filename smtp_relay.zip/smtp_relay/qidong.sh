#!/bin/sh

# ============================================
# SMTP 中继服务管理脚本
# 兼容 sh/bash/dash/zsh 等各种 shell
# ============================================

# 获取脚本所在目录（兼容各种情况）
get_script_dir() {
    # 尝试多种方式获取脚本目录
    if [ -n "$BASH_SOURCE" ]; then
        DIR="$(cd "$(dirname "$BASH_SOURCE")" && pwd)"
    elif [ -n "$ZSH_VERSION" ]; then
        DIR="$(cd "$(dirname "$0")" && pwd)"
    else
        DIR="$(cd "$(dirname "$0")" && pwd)"
    fi
    echo "$DIR"
}

SCRIPT_DIR="$(get_script_dir)"
PID_FILE="$SCRIPT_DIR/smtp_relay.pid"
LOG_FILE="$SCRIPT_DIR/smtp_relay.log"
PYTHON_SCRIPT="$SCRIPT_DIR/smtp_relay.py"
PYTHON_CMD=""
PIP_CMD=""

# 检测终端是否支持颜色
if [ -t 1 ] && command -v tput >/dev/null 2>&1 && [ "$(tput colors 2>/dev/null)" -ge 8 ] 2>/dev/null; then
    RED=$(tput setaf 1)
    GREEN=$(tput setaf 2)
    YELLOW=$(tput setaf 3)
    BLUE=$(tput setaf 4)
    NC=$(tput sgr0)
else
    # 尝试使用 ANSI 转义码
    RED='\033[0;31m'
    GREEN='\033[0;32m'
    YELLOW='\033[1;33m'
    BLUE='\033[0;34m'
    NC='\033[0m'
fi

# 打印函数（兼容所有 shell）
print_info() {
    printf "%b[INFO]%b %s\n" "$BLUE" "$NC" "$1"
}

print_success() {
    printf "%b[SUCCESS]%b %s\n" "$GREEN" "$NC" "$1"
}

print_warning() {
    printf "%b[WARNING]%b %s\n" "$YELLOW" "$NC" "$1"
}

print_error() {
    printf "%b[ERROR]%b %s\n" "$RED" "$NC" "$1"
}

# 检查命令是否存在
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# 查找 Python3
find_python() {
    # 按优先级尝试不同的 Python 命令
    for cmd in python3 python python3.12 python3.11 python3.10 python3.9 python3.8; do
        if command_exists "$cmd"; then
            # 检查是否为 Python 3
            ver=$("$cmd" -c 'import sys; print(sys.version_info[0])' 2>/dev/null)
            if [ "$ver" = "3" ]; then
                PYTHON_CMD="$cmd"
                return 0
            fi
        fi
    done
    return 1
}

# 查找 pip
find_pip() {
    if [ -z "$PYTHON_CMD" ]; then
        return 1
    fi

    # 优先使用 python -m pip（最可靠）
    if "$PYTHON_CMD" -m pip --version >/dev/null 2>&1; then
        PIP_CMD="$PYTHON_CMD -m pip"
        return 0
    fi

    # 尝试 pip3/pip
    for cmd in pip3 pip; do
        if command_exists "$cmd"; then
            PIP_CMD="$cmd"
            return 0
        fi
    done

    return 1
}

# 安装 pip（如果缺失）
install_pip() {
    print_info "尝试安装 pip..."

    # 尝试使用 ensurepip
    if "$PYTHON_CMD" -m ensurepip --upgrade >/dev/null 2>&1; then
        print_success "pip 安装成功 (ensurepip)"
        PIP_CMD="$PYTHON_CMD -m pip"
        return 0
    fi

    # 尝试系统包管理器
    if command_exists apt-get; then
        print_info "使用 apt 安装 pip..."
        sudo apt-get update && sudo apt-get install -y python3-pip
    elif command_exists apt; then
        print_info "使用 apt 安装 pip..."
        sudo apt update && sudo apt install -y python3-pip
    elif command_exists yum; then
        print_info "使用 yum 安装 pip..."
        sudo yum install -y python3-pip
    elif command_exists dnf; then
        print_info "使用 dnf 安装 pip..."
        sudo dnf install -y python3-pip
    elif command_exists pacman; then
        print_info "使用 pacman 安装 pip..."
        sudo pacman -S --noconfirm python-pip
    elif command_exists apk; then
        print_info "使用 apk 安装 pip..."
        sudo apk add py3-pip
    elif command_exists zypper; then
        print_info "使用 zypper 安装 pip..."
        sudo zypper install -y python3-pip
    else
        # 最后尝试 get-pip.py
        print_info "尝试使用 get-pip.py..."
        if command_exists curl; then
            curl -sS https://bootstrap.pypa.io/get-pip.py | "$PYTHON_CMD"
        elif command_exists wget; then
            wget -qO- https://bootstrap.pypa.io/get-pip.py | "$PYTHON_CMD"
        else
            print_error "无法自动安装 pip，请手动安装"
            return 1
        fi
    fi

    # 重新检测
    find_pip
}

# 安装依赖
install_dependencies() {
    printf "\n"
    print_info "========== 开始安装 =========="
    printf "\n"

    # 检查 Python
    print_info "检查 Python..."
    if ! find_python; then
        print_error "Python3 未安装！请先安装 Python3"
        printf "\n"
        print_info "安装命令参考:"
        print_info "  Ubuntu/Debian: sudo apt install python3 python3-pip python3-venv"
        print_info "  CentOS/RHEL:   sudo yum install python3 python3-pip"
        print_info "  Fedora:        sudo dnf install python3 python3-pip"
        print_info "  Arch:          sudo pacman -S python python-pip"
        print_info "  Alpine:        sudo apk add python3 py3-pip"
        return 1
    fi

    py_version=$("$PYTHON_CMD" --version 2>&1)
    print_success "Python3 已安装: $py_version"

    # 检查 pip
    print_info "检查 pip..."
    if ! find_pip; then
        install_pip
        if ! find_pip; then
            print_error "pip 安装失败，请手动安装"
            return 1
        fi
    fi

    pip_version=$($PIP_CMD --version 2>&1)
    print_success "pip 已安装: $pip_version"

    # 安装 Python 依赖
    printf "\n"
    print_info "安装 Python 依赖..."

    # 检查是否需要 --break-system-packages（Python 3.11+ 在某些系统需要）
    PIP_EXTRA_ARGS=""
    if "$PYTHON_CMD" -c "import sys; exit(0 if sys.version_info >= (3,11) else 1)" 2>/dev/null; then
        # 检查是否是受管理的环境
        if $PIP_CMD install --help 2>&1 | grep -q "break-system-packages"; then
            PIP_EXTRA_ARGS="--break-system-packages"
        fi
    fi

    if [ -f "$SCRIPT_DIR/requirements.txt" ]; then
        if $PIP_CMD install $PIP_EXTRA_ARGS -r "$SCRIPT_DIR/requirements.txt"; then
            print_success "依赖安装完成！"
        else
            # 如果失败，尝试用 --user
            print_warning "尝试使用 --user 模式安装..."
            if $PIP_CMD install --user -r "$SCRIPT_DIR/requirements.txt"; then
                print_success "依赖安装完成（用户模式）！"
            else
                print_error "依赖安装失败！"
                return 1
            fi
        fi
    else
        print_warning "requirements.txt 不存在，直接安装核心依赖..."
        if $PIP_CMD install $PIP_EXTRA_ARGS aiosmtpd cryptography; then
            print_success "依赖安装完成！"
        else
            $PIP_CMD install --user aiosmtpd cryptography
        fi
    fi

    printf "\n"
    print_success "========== 安装完成 =========="
    printf "\n"
}

# 检查服务是否运行
is_running() {
    if [ -f "$PID_FILE" ]; then
        pid=$(cat "$PID_FILE" 2>/dev/null)
        if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
            return 0
        fi
    fi
    return 1
}

# 获取运行状态
get_status() {
    if is_running; then
        pid=$(cat "$PID_FILE")
        print_success "服务正在运行 (PID: $pid)"
    else
        print_warning "服务未运行"
    fi
}

# 前台启动
start_foreground() {
    printf "\n"
    if is_running; then
        print_warning "服务已经在运行！"
        get_status
        return 1
    fi

    if ! find_python; then
        print_error "Python3 未安装，请先运行选项 1 安装"
        return 1
    fi

    print_info "前台启动服务... (Ctrl+C 停止)"
    printf "\n"
    cd "$SCRIPT_DIR" || exit 1
    "$PYTHON_CMD" "$PYTHON_SCRIPT"
}

# 后台启动
start_background() {
    printf "\n"
    if is_running; then
        print_warning "服务已经在运行！"
        get_status
        return 1
    fi

    if ! find_python; then
        print_error "Python3 未安装，请先运行选项 1 安装"
        return 1
    fi

    print_info "后台启动服务..."
    cd "$SCRIPT_DIR" || exit 1
    nohup "$PYTHON_CMD" "$PYTHON_SCRIPT" > "$LOG_FILE" 2>&1 &
    echo $! > "$PID_FILE"
    sleep 2

    if is_running; then
        print_success "服务启动成功！"
        get_status
        print_info "日志文件: $LOG_FILE"
    else
        print_error "服务启动失败，请检查日志: $LOG_FILE"
        rm -f "$PID_FILE"
    fi
}

# 停止服务
stop_service() {
    printf "\n"
    if ! is_running; then
        print_warning "服务未在运行"
        return 1
    fi

    pid=$(cat "$PID_FILE")
    print_info "停止服务 (PID: $pid)..."
    kill "$pid" 2>/dev/null

    # 等待进程结束（兼容 POSIX sh，不用 {1..10}）
    count=0
    while [ $count -lt 10 ]; do
        if ! kill -0 "$pid" 2>/dev/null; then
            break
        fi
        sleep 1
        count=$((count + 1))
    done

    # 如果还在运行，强制杀死
    if kill -0 "$pid" 2>/dev/null; then
        print_warning "进程未响应，强制终止..."
        kill -9 "$pid" 2>/dev/null
    fi

    rm -f "$PID_FILE"
    print_success "服务已停止"
}

# 重启服务
restart_service() {
    printf "\n"
    print_info "重启服务..."

    if is_running; then
        stop_service
        sleep 2
    fi

    start_background
}

# 查看日志
view_logs() {
    printf "\n"
    if [ -f "$LOG_FILE" ]; then
        print_info "显示最后 50 行日志 (Ctrl+C 退出):"
        printf "----------------------------------------\n"
        tail -n 50 -f "$LOG_FILE"
    else
        print_warning "日志文件不存在"
    fi
}

# 显示菜单
show_menu() {
    # 尝试清屏，如果失败就打印空行
    clear 2>/dev/null || printf "\n\n\n"

    printf "\n"
    printf "%b============================================%b\n" "$BLUE" "$NC"
    printf "%b       SMTP 中继服务管理脚本%b\n" "$GREEN" "$NC"
    printf "%b============================================%b\n" "$BLUE" "$NC"
    printf "\n"
    get_status
    printf "\n"
    printf "%b请选择操作:%b\n" "$YELLOW" "$NC"
    printf "\n"
    printf "  1) 前台启动\n"
    printf "  2) 后台启动\n"
    printf "  3) 重新启动\n"
    printf "  4) 停止服务\n"
    printf "  5) 查看日志\n"
    printf "  6) 查看状态\n"
    printf "  9) 安装/更新 (检查环境并安装依赖)\n"
    printf "\n"
    printf "  0) 退出\n"
    printf "\n"
    printf "%b============================================%b\n" "$BLUE" "$NC"
    printf "\n"
}

# 等待用户按键
wait_key() {
    printf "\n"
    printf "按 Enter 键继续..."
    read -r REPLY 2>/dev/null || read REPLY
}

# 读取用户输入
read_choice() {
    printf "请输入选项 [0-6, 9]: "
    read -r choice 2>/dev/null || read choice
    # 去除首尾空格和特殊字符
    choice=$(printf "%s" "$choice" | tr -d '[:space:]' | tr -cd '0-9')
}

# 主循环
main() {
    # 尝试修复终端设置
    stty sane 2>/dev/null

    while true; do
        show_menu
        read_choice

        case $choice in
            1)
                start_foreground
                ;;
            2)
                start_background
                ;;
            3)
                restart_service
                ;;
            4)
                stop_service
                ;;
            5)
                view_logs
                ;;
            6)
                printf "\n"
                get_status
                ;;
            9)
                install_dependencies
                ;;
            0)
                printf "\n"
                print_info "再见！"
                exit 0
                ;;
            "")
                # 空输入，继续显示菜单
                continue
                ;;
            *)
                print_error "无效选项，请重新输入"
                ;;
        esac

        wait_key
    done
}

# 运行主程序
main

