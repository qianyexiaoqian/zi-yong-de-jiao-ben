#!/bin/bash

# ================= 配置区域 =================
BASE_DIR=$(cd "$(dirname "$0")" && pwd)
GLOBAL_CONFIG="$BASE_DIR/shangchuanpeizhi_config.yaml"
SSH_CONFIG_DIR="$BASE_DIR/ssh"
LOG_DIR="$BASE_DIR/log"
TIMESTAMP=$(date "+%Y%m%d_%H%M%S")
LOG_FILE="$LOG_DIR/deploy_$TIMESTAMP.log"

# 创建日志目录
mkdir -p "$LOG_DIR"

# ================= 工具函数 =================

get_yaml_value() {
    local file="$1"
    local key="$2"
    grep "^${key}:" "$file" | head -n 1 | sed "s/^${key}:[[:space:]]*//" | sed 's/#.*//' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//' | sed 's/^"//;s/"$//' | sed "s/^'//;s/'$//"
}

log_info() {
    local msg="[INFO] $(date "+%Y-%m-%d %H:%M:%S") - $1"
    echo -e "\033[32m$msg\033[0m"
    echo "$msg" >> "$LOG_FILE"
}

log_error() {
    local msg="[ERROR] $(date "+%Y-%m-%d %H:%M:%S") - $1"
    echo -e "\033[31m$msg\033[0m"
    echo "$msg" >> "$LOG_FILE"
}

log_warn() {
    local msg="[WARN] $(date "+%Y-%m-%d %H:%M:%S") - $1"
    echo -e "\033[33m$msg\033[0m"
    echo "$msg" >> "$LOG_FILE"
}

check_and_install_sshpass() {
    if command -v sshpass &> /dev/null; then return 0; fi
    log_warn "未检测到 sshpass，准备安装..."
    if [ "$EUID" -eq 0 ]; then CMD_PREFIX=""; else CMD_PREFIX="sudo"; fi
    export DEBIAN_FRONTEND=noninteractive
    
    if [ -f /etc/debian_version ]; then
        $CMD_PREFIX apt-get update -yq >> "$LOG_FILE" 2>&1
        $CMD_PREFIX apt-get install -yq sshpass >> "$LOG_FILE" 2>&1
    elif [ -f /etc/redhat-release ]; then
        $CMD_PREFIX yum install -y sshpass >> "$LOG_FILE" 2>&1
    elif [ -f /etc/alpine-release ]; then
        $CMD_PREFIX apk add sshpass >> "$LOG_FILE" 2>&1
    else
        return 1
    fi
    command -v sshpass &> /dev/null
}

# === V9 优化：邮件发送函数 (针对自建邮局优化) ===
send_email_alert() {
    local server_name="$1"
    local error_msg="$2"
    local smtp_server=$(get_yaml_value "$GLOBAL_CONFIG" "smtp_server")
    local smtp_user=$(get_yaml_value "$GLOBAL_CONFIG" "smtp_user")
    local smtp_pass=$(get_yaml_value "$GLOBAL_CONFIG" "smtp_pass")
    local email_from=$(get_yaml_value "$GLOBAL_CONFIG" "email_from")
    local email_to=$(get_yaml_value "$GLOBAL_CONFIG" "email_to")

    if [[ -z "$smtp_server" || -z "$smtp_user" ]]; then return; fi
    log_info "正在向 $email_to 发送报警邮件..."

    # 构建标准邮件头
    local mail_content="Subject: ⚠️ SSL部署失败: $server_name
From: $email_from
To: $email_to
Date: $(date -R)
Content-Type: text/plain; charset=UTF-8

服务器: $server_name
发生时间: $(date "+%Y-%m-%d %H:%M:%S")
错误详情: 
$error_msg

请登录服务器检查日志文件: $LOG_FILE
"
    # 使用 curl 发送
    # -k / --insecure : 关键参数，允许自签或受信任链不完整的证书
    # --url : 支持 smtps:// 协议
    curl --url "$smtp_server" \
         -k \
         --mail-from "$email_from" \
         --mail-rcpt "$email_to" \
         --user "$smtp_user:$smtp_pass" \
         -T <(echo -e "$mail_content") \
         --silent --show-error >> "$LOG_FILE" 2>&1
         
    if [ $? -eq 0 ]; then
        log_info "📧 邮件发送成功"
    else
        log_error "📧 邮件发送失败 (详情见日志)"
    fi
}

# ================= 主逻辑 =================

if [ ! -f "$GLOBAL_CONFIG" ]; then echo "ERROR: 找不到全局配置"; exit 1; fi

LOCAL_FULLCHAIN=$(get_yaml_value "$GLOBAL_CONFIG" "local_fullchain")
LOCAL_PRIVKEY=$(get_yaml_value "$GLOBAL_CONFIG" "local_privkey")
REMOTE_PATH=$(get_yaml_value "$GLOBAL_CONFIG" "remote_path")
REMOTE_FULLCHAIN_NAME=$(get_yaml_value "$GLOBAL_CONFIG" "remote_fullchain_name")
REMOTE_PRIVKEY_NAME=$(get_yaml_value "$GLOBAL_CONFIG" "remote_privkey_name")
PRE_CMD=$(get_yaml_value "$GLOBAL_CONFIG" "pre_cmd")
POST_CMD=$(get_yaml_value "$GLOBAL_CONFIG" "post_cmd")

if [ ! -f "$LOCAL_FULLCHAIN" ] || [ ! -f "$LOCAL_PRIVKEY" ]; then
    log_error "本地证书缺失: $LOCAL_FULLCHAIN 或 $LOCAL_PRIVKEY"
    exit 1
fi

# 遍历服务器列表 (使用 FD 3 防止 SSH 吞噬 stdin)
while IFS= read -r -d '' -u 3 SERVER_FILE; do
    SERVER_NAME=$(basename "$SERVER_FILE" .yaml)
    log_info --------------------"感谢使用qianye-ssl同步工具--------------------"
    log_info "处理服务器: $SERVER_NAME"

    HOST=$(get_yaml_value "$SERVER_FILE" "host")
    PORT=$(get_yaml_value "$SERVER_FILE" "port")
    USER=$(get_yaml_value "$SERVER_FILE" "user")
    AUTH_TYPE=$(get_yaml_value "$SERVER_FILE" "auth_type")
    KEY_FILE=$(get_yaml_value "$SERVER_FILE" "key_file")
    PASSWORD=$(get_yaml_value "$SERVER_FILE" "password")
    EMAIL_NOTIFY=$(get_yaml_value "$SERVER_FILE" "email_notify")
    
    CURRENT_ERROR=""
    [ -z "$PORT" ] && PORT=22
    [ -z "$USER" ] && USER=root
    if [ -z "$HOST" ]; then continue; fi

    SSH_OPTS="-o StrictHostKeyChecking=no -o ConnectTimeout=10 -p $PORT"
    SCP_OPTS="-o StrictHostKeyChecking=no -o ConnectTimeout=10 -P $PORT"
    
    SSH_CMD_BASE=""
    SCP_CMD=""
    PASS_PREFIX=""

    # 鉴权逻辑构建
    case "$AUTH_TYPE" in
        key)
            if [ -z "$KEY_FILE" ] || [ ! -f "$KEY_FILE" ]; then
                CURRENT_ERROR="Key文件未找到"
            else
                SSH_CMD_BASE="ssh $SSH_OPTS -i $KEY_FILE $USER@$HOST"
                SCP_CMD="scp $SCP_OPTS -i $KEY_FILE"
            fi
            ;;
        password)
            if [ -z "$PASSWORD" ]; then
                CURRENT_ERROR="密码为空"
            else
                if ! check_and_install_sshpass; then
                    CURRENT_ERROR="sshpass 安装失败"
                else
                    PASS_PREFIX="sshpass -p $PASSWORD"
                    SSH_CMD_BASE="ssh $SSH_OPTS $USER@$HOST"
                    SCP_CMD="sshpass -p $PASSWORD scp $SCP_OPTS"
                fi
            fi
            ;;
        *)
            if [ -n "$KEY_FILE" ] && [ -f "$KEY_FILE" ]; then
                SSH_CMD_BASE="ssh $SSH_OPTS -i $KEY_FILE $USER@$HOST"
                SCP_CMD="scp $SCP_OPTS -i $KEY_FILE"
            elif [ -n "$PASSWORD" ]; then
                 check_and_install_sshpass
                 PASS_PREFIX="sshpass -p $PASSWORD"
                 SSH_CMD_BASE="ssh $SSH_OPTS $USER@$HOST"
                 SCP_CMD="sshpass -p $PASSWORD scp $SCP_OPTS"
            else
                CURRENT_ERROR="未配置鉴权方式"
            fi
            ;;
    esac

    if [ -z "$CURRENT_ERROR" ] && [ -n "$SCP_CMD" ]; then
        
        if [ -n "$PASS_PREFIX" ]; then
            FINAL_SSH_CMD="$PASS_PREFIX $SSH_CMD_BASE"
        else
            FINAL_SSH_CMD="$SSH_CMD_BASE"
        fi

        # 1. 创建目录
        ERR_OUT=$($FINAL_SSH_CMD "bash -login -c 'mkdir -p $REMOTE_PATH'" 2>&1)
        if [ $? -ne 0 ]; then
            CURRENT_ERROR="连接/创建目录失败: $ERR_OUT"
        else
            # 2. Pre-CMD
            if [ -n "$PRE_CMD" ]; then
                echo "$PRE_CMD" | $FINAL_SSH_CMD "bash -login" >/dev/null 2>&1
            fi

            # 3. 上传文件
            REMOTE_FULLCHAIN_PATH="${REMOTE_PATH%/}/$REMOTE_FULLCHAIN_NAME"
            REMOTE_PRIVKEY_PATH="${REMOTE_PATH%/}/$REMOTE_PRIVKEY_NAME"

            OUT1=$($SCP_CMD "$LOCAL_FULLCHAIN" "$USER@$HOST:$REMOTE_FULLCHAIN_PATH" 2>&1)
            RET1=$?
            OUT2=$($SCP_CMD "$LOCAL_PRIVKEY" "$USER@$HOST:$REMOTE_PRIVKEY_PATH" 2>&1)
            RET2=$?

            if [ $RET1 -eq 0 ] && [ $RET2 -eq 0 ]; then
                log_info "[$HOST] ✅ 证书上传成功"
                
                # 4. Post-CMD
                if [ -n "$POST_CMD" ]; then
                    OUT3=$(echo "$POST_CMD" | $FINAL_SSH_CMD "bash -login" 2>&1)
                    if [ $? -ne 0 ]; then
                        if [[ "$OUT3" == *"成功"* ]]; then
                             log_info "[$HOST] ✅ 脚本反馈执行成功"
                        else
                             log_warn "[$HOST] 重启脚本可能报错: $OUT3"
                        fi
                    else
                        log_info "[$HOST] ✅ 服务重启/后置命令完成"
                        if [ -n "$OUT3" ]; then echo "      命令回显: $OUT3" >> "$LOG_FILE"; fi
                    fi
                fi
            else
                CURRENT_ERROR="SCP错误 >>> Fullchain: $OUT1 || Privkey: $OUT2"
            fi
        fi
    fi

    if [ -n "$CURRENT_ERROR" ]; then
        echo -e "\033[31m[ERROR] [$HOST] 失败:\033[0m"
        echo -e "\033[31m$CURRENT_ERROR\033[0m"
        echo "[ERROR] [$HOST] $CURRENT_ERROR" >> "$LOG_FILE"
        if [ "$EMAIL_NOTIFY" == "true" ]; then
            send_email_alert "$SERVER_NAME ($HOST)" "$CURRENT_ERROR"
        fi
    fi

done 3< <(find "$SSH_CONFIG_DIR" -name "*.yaml" -print0)

log_info "=== 任务结束 ==="