<!doctype html>
<html lang="zh-CN">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=5,minimum-scale=1,user-scalable=yes,viewport-fit=cover" />
  <meta name="description" content="{{$description ?? ''}}" />
  <meta name="keywords" content="{{$keywords ?? ''}}" />

  <!-- 移动端优化 -->
  <meta name="mobile-web-app-capable" content="yes" />
  <meta name="apple-mobile-web-app-capable" content="yes" />
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
  <meta name="format-detection" content="telephone=no" />
  <meta name="theme-color" content="#FF69B4" />

  <!-- Windows平板优化 -->
  <meta name="msapplication-tap-highlight" content="no" />

  <title>{{$title}}</title>

  @empty($logo)
  <link rel="icon" href="/theme/{{$theme}}/favicon.svg" />
  @else
  <link rel="icon" href="{{ $logo }}" />
  @endempty

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@300;400;500;700&display=swap" rel="stylesheet">

  <script>
    // 设置 Vite 的 base 路径，用于动态导入
    window.__vite_base__ = '/theme/{{$theme}}/static/';

    // 设置全局配置
    window.routerBase = "/";
    window.settings = {
      title: '{{$title}}',
      assets_path: '/theme/{{$theme}}/static',
      theme: {
        color: '{{ $theme_config['theme_color'] ?? "sakura" }}',
        enable_particles: {{ $theme_config['enable_particles'] ?? 'true' }},
      },
      version: '{{$version}}',
      background_url: '{{$theme_config['background_url'] ?? ''}}',
      logo_url: '{{$theme_config['logo_url'] ?? ''}}',
      hero_title: '{{$theme_config['hero_title'] ?? '欢迎来到二次元世界'}}',
      hero_subtitle: '{{$theme_config['hero_subtitle'] ?? '开启你的奇幻之旅'}}',
      description: '{{$description}}',
      // 特性卡片配置
      feature1_icon: '{{$theme_config['feature1_icon'] ?? '🎬'}}',
      feature1_title: '{{$theme_config['feature1_title'] ?? '高清秒播'}}',
      feature1_desc: '{{$theme_config['feature1_desc'] ?? '超清画质即点即播，告别缓冲等待，追番体验丝滑流畅'}}',
      feature2_icon: '{{$theme_config['feature2_icon'] ?? '✨'}}',
      feature2_title: '{{$theme_config['feature2_title'] ?? '无广告打扰'}}',
      feature2_desc: '{{$theme_config['feature2_desc'] ?? '纯净观看环境，专注欣赏每一帧精彩，沉浸二次元世界'}}',
      feature3_icon: '{{$theme_config['feature3_icon'] ?? '🎨'}}',
      feature3_title: '{{$theme_config['feature3_title'] ?? '番剧宝库'}}',
      feature3_desc: '{{$theme_config['feature3_desc'] ?? '日漫、国漫、剧场版全覆盖，万部动漫随心看'}}',
      feature4_icon: '{{$theme_config['feature4_icon'] ?? '🔔'}}',
      feature4_title: '{{$theme_config['feature4_title'] ?? '更新提醒'}}',
      feature4_desc: '{{$theme_config['feature4_desc'] ?? '新番更新及时推送，第一时间追上最新剧情不落伍'}}',
      feature5_icon: '{{$theme_config['feature5_icon'] ?? '💫'}}',
      feature5_title: '{{$theme_config['feature5_title'] ?? '多端同步'}}',
      feature5_desc: '{{$theme_config['feature5_desc'] ?? '手机、平板、电脑无缝切换，随时随地想看就看'}}',
      feature6_icon: '{{$theme_config['feature6_icon'] ?? '🔒'}}',
      feature6_title: '{{$theme_config['feature6_title'] ?? '账号安全'}}',
      feature6_desc: '{{$theme_config['feature6_desc'] ?? '多重加密保护，确保您的账号和观看记录安全无忧，隐私有保障'}}',
      i18n: [
        'zh-CN',
        'en-US',
        'ja-JP',
        'vi-VN',
        'ko-KR',
        'zh-TW',
        'fa-IR'
      ],
      logo: '{{$logo}}'
    }
  </script>

  <script>
    // 修复 Vite 动态导入路径
    (function() {
      const originalFetch = window.fetch;
      const basePath = '/theme/{{$theme}}/static/';

      window.fetch = function(url, options) {
        if (typeof url === 'string' && url.startsWith('./')) {
          url = basePath + url.substring(2);
        } else if (typeof url === 'string' && url.startsWith('/') && !url.startsWith(basePath)) {
          // 如果是绝对路径但不包含 basePath，检查是否是资源文件
          if (url.match(/\.(js|css|json)$/)) {
            url = basePath + url.substring(1);
          }
        }
        return originalFetch.call(this, url, options);
      };

      // 修复动态 import
      const originalImport = window.import || (async (url) => import(url));
      window.import = async function(url) {
        if (typeof url === 'string' && url.startsWith('./')) {
          url = basePath + url.substring(2);
        }
        return originalImport(url);
      };
    })();
  </script>

  <link rel="stylesheet" crossorigin href="/theme/{{$theme}}/static/index.css">
</head>

<body>
  <div id="app"></div>

  @if(!empty($theme_config['custom_css']))
  <style>
    {!! $theme_config['custom_css'] !!}
  </style>
  @endif

  <script src="/theme/{{$theme}}/expose.js"></script>
  {!! $theme_config['custom_html'] ?? '' !!}

  <script type="module" crossorigin src="/theme/{{$theme}}/static/index.js"></script>
</body>

</html>

