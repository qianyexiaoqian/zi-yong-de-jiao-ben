from flask import Flask, request, jsonify, send_file, Response
from flask_cors import CORS
import requests
import sqlite3
from datetime import datetime, timedelta
import os
import uuid
import ipaddress
import yaml
import logging
from logging.handlers import TimedRotatingFileHandler
import glob
import threading
import time

app = Flask(__name__)
CORS(app)  # 启用CORS支持

# 配置文件路径
CONFIG_FILE = "config.yaml"
config = None
config_lock = threading.Lock()
last_modified_time = 0

# 加载配置文件
def load_config():
    global config, last_modified_time

    if not os.path.exists(CONFIG_FILE):
        raise FileNotFoundError(f"配置文件不存在: {CONFIG_FILE}")

    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        new_config = yaml.safe_load(f)

    with config_lock:
        config = new_config
        last_modified_time = os.path.getmtime(CONFIG_FILE)

    logging.info("配置文件已加载")
    return config

# 检查配置文件是否更新
def check_config_update():
    global last_modified_time

    try:
        current_modified_time = os.path.getmtime(CONFIG_FILE)
        if current_modified_time > last_modified_time:
            logging.info("检测到配置文件更新，正在重新加载...")
            load_config()
            logging.info("配置文件热更新成功")
    except Exception as e:
        logging.error(f"检查配置文件更新失败: {e}")

# 配置文件监控线程
def config_monitor_thread():
    """后台线程，每5秒检查一次配置文件是否更新"""
    while True:
        time.sleep(5)  # 每5秒检查一次
        check_config_update()

# 启动配置监控线程
monitor_thread = threading.Thread(target=config_monitor_thread, daemon=True)
monitor_thread.start()

# 初始加载配置
config = load_config()

# 获取配置的线程安全函数
def get_config():
    with config_lock:
        return config

# ==================== 日志配置 ====================
def setup_logging():
    """配置日志系统（按日期分文件）"""
    cfg = get_config()
    log_config = cfg.get("logging", {})

    if not log_config.get("enabled", True):
        return

    # 创建日志目录
    log_dir = log_config.get("log_dir", "logs")
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    # 日志文件路径（按日期命名）
    log_file = os.path.join(log_dir, "app.log")

    # 日志级别
    level_str = log_config.get("level", "INFO").upper()
    level = getattr(logging, level_str, logging.INFO)

    # 日志格式
    log_format = log_config.get("format", "%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    formatter = logging.Formatter(log_format)

    # 配置根日志记录器
    root_logger = logging.getLogger()
    root_logger.setLevel(level)

    # 清除现有的处理器
    root_logger.handlers.clear()

    # 文件处理器（按日期轮转）
    retention_days = log_config.get("retention_days", 30)
    file_handler = TimedRotatingFileHandler(
        log_file,
        when='midnight',  # 每天午夜轮转
        interval=1,  # 每1天
        backupCount=retention_days,  # 保留天数
        encoding='utf-8'
    )
    # 设置日志文件命名格式：app.2026-01-30.log
    file_handler.suffix = "%Y-%m-%d.log"
    # 自定义文件命名函数
    def custom_namer(default_name):
        # default_name 格式: logs/app.log.2026-01-30.log
        # 需要转换为: logs/app.2026-01-30.log
        base_name = default_name.replace('.log.', '.')
        return base_name
    file_handler.namer = custom_namer
    file_handler.setLevel(level)
    file_handler.setFormatter(formatter)
    root_logger.addHandler(file_handler)

    # 控制台处理器
    console_handler = logging.StreamHandler()
    console_handler.setLevel(level)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)

    # 清理过期日志
    clean_old_logs()

    logging.info("日志系统初始化完成（按日期分文件存储）")

def clean_old_logs():
    """清理过期的日志文件"""
    cfg = get_config()
    log_config = cfg.get("logging", {})
    retention_days = log_config.get("retention_days", 30)
    log_dir = log_config.get("log_dir", "logs")

    if not os.path.exists(log_dir):
        return

    # 计算过期时间
    cutoff_time = datetime.now() - timedelta(days=retention_days)

    # 查找所有日志文件
    log_pattern = os.path.join(log_dir, "*.log*")
    log_files = glob.glob(log_pattern)

    deleted_count = 0
    for log_file in log_files:
        try:
            # 获取文件修改时间
            file_mtime = datetime.fromtimestamp(os.path.getmtime(log_file))

            # 如果文件过期，删除它
            if file_mtime < cutoff_time:
                os.remove(log_file)
                deleted_count += 1
                logging.info(f"删除过期日志文件: {log_file}")
        except Exception as e:
            logging.error(f"删除日志文件失败 {log_file}: {e}")

    if deleted_count > 0:
        logging.info(f"清理了 {deleted_count} 个过期日志文件")

# 初始化日志
setup_logging()
cfg = get_config()
logging.info("=" * 60)
logging.info("请求转发器启动")
logging.info(f"配置文件: config.yaml")
logging.info(f"监听地址: {cfg['server']['host']}:{cfg['server']['port']}")
logging.info(f"配置热更新: 已启用 (每5秒检查一次)")
logging.info("=" * 60)

# 初始化数据库
def init_db():
    conn = sqlite3.connect("access_logs.db")
    cursor = conn.cursor()

    # 创建访问日志表
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS access_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            uuid TEXT NOT NULL,
            ip TEXT NOT NULL,
            ip_location TEXT,
            access_time TEXT NOT NULL,
            full_path TEXT NOT NULL,
            proxy_path TEXT,
            upstream_url TEXT,
            user_agent TEXT,
            access_type TEXT NOT NULL DEFAULT 'proxy',
            status_code INTEGER DEFAULT 200
        )
    """)

    # 创建索引以提高查询性能
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_uuid ON access_logs(uuid)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_access_time ON access_logs(access_time)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_access_type ON access_logs(access_type)")

    conn.commit()
    conn.close()
    logging.info("数据库初始化完成")

init_db()

# ==================== IP 黑名单功能 ====================

def ip_to_int(ip_str):
    """将 IP 地址转换为整数"""
    try:
        parts = ip_str.split(".")
        return (int(parts[0]) << 24) + (int(parts[1]) << 16) + (int(parts[2]) << 8) + int(parts[3])
    except:
        return 0

def is_ip_in_range(ip, start_ip, end_ip):
    """检查 IP 是否在指定范围内"""
    ip_int = ip_to_int(ip)
    start_int = ip_to_int(start_ip)
    end_int = ip_to_int(end_ip)
    return start_int <= ip_int <= end_int

def is_ip_in_cidr(ip, cidr):
    """检查 IP 是否在 CIDR 范围内"""
    try:
        network = ipaddress.ip_network(cidr, strict=False)
        ip_obj = ipaddress.ip_address(ip)
        return ip_obj in network
    except:
        return False

def is_ip_blocked(ip):
    """
    检查 IP 是否被封禁
    支持：单个 IP、IP 范围、CIDR 格式
    """
    blacklist = get_config().get("ip_blacklist", {})

    if not blacklist.get("enabled", False):
        return False

    # 检查单个 IP
    blocked_ips = blacklist.get("ips", [])
    if ip in blocked_ips:
        return True

    # 检查 IP 范围
    ip_ranges = blacklist.get("ip_ranges", [])
    for ip_range in ip_ranges:
        start_ip = ip_range.get("start", "")
        end_ip = ip_range.get("end", "")
        if start_ip and end_ip and is_ip_in_range(ip, start_ip, end_ip):
            return True

    # 检查 CIDR
    cidrs = blacklist.get("cidrs", [])
    for cidr in cidrs:
        if is_ip_in_cidr(ip, cidr):
            return True

    return False

def get_block_message():
    """获取封禁提示信息"""
    return get_config().get("ip_blacklist", {}).get("block_message", "您的IP已被禁止访问")

# 获取客户端真实IP地址（兼容各种CDN、反向代理、负载均衡器）
def get_real_ip():
    """
    按优先级顺序检查各种可能包含真实IP的请求头
    支持：Cloudflare, AWS CloudFront, Fastly, Akamai, Nginx, Apache,
          OpenResty, HAProxy, 阿里云CDN, 腾讯云CDN, 七牛云CDN等
    """
    # 定义请求头优先级列表（从高到低）
    ip_headers = [
        # Cloudflare
        "CF-Connecting-IP",
        "True-Client-IP",

        # Fastly CDN
        "Fastly-Client-IP",

        # Akamai
        "True-Client-IP",

        # 阿里云 CDN
        "Ali-CDN-Real-IP",
        "Cdn-Src-Ip",

        # 腾讯云 CDN
        "X-Tencent-Ua",

        # 通用标准头（最常用）
        "X-Real-IP",
        "X-Forwarded-For",
        "X-Original-Forwarded-For",

        # Proxy 相关
        "X-Client-IP",
        "X-Cluster-Client-IP",
        "Forwarded-For",
        "Forwarded",

        # 其他
        "CF-Pseudo-IPv4",
        "X-ProxyUser-Ip",
        "WL-Proxy-Client-IP",
        "Proxy-Client-IP",
        "HTTP_X_FORWARDED_FOR",
        "HTTP_X_FORWARDED",
        "HTTP_X_CLUSTER_CLIENT_IP",
        "HTTP_CLIENT_IP",
        "HTTP_FORWARDED_FOR",
        "HTTP_FORWARDED",
        "HTTP_VIA",
        "REMOTE_ADDR",
    ]

    # 按优先级检查每个请求头
    for header in ip_headers:
        ip_value = request.headers.get(header)
        if ip_value:
            # 处理可能包含多个IP的情况（如 X-Forwarded-For）
            if "," in ip_value:
                # 取第一个IP（最原始的客户端IP）
                ip_value = ip_value.split(",")[0].strip()

            # 清理IP字符串
            ip_value = ip_value.strip()

            # 验证IP格式（简单验证）
            if is_valid_ip(ip_value):
                return ip_value

    # 如果所有请求头都没有，使用 Flask 的 remote_addr
    return request.remote_addr or "unknown"

# 验证IP地址格式
def is_valid_ip(ip):
    """
    简单验证IP地址格式（支持IPv4和IPv6）
    """
    if not ip or ip == "unknown":
        return False

    # 过滤掉内网IP和特殊IP（可选）
    private_ips = ["127.0.0.1", "localhost", "0.0.0.0", "::1"]
    if ip in private_ips:
        return True  # 内网IP也是有效的，只是标记一下

    # IPv4 简单验证
    if "." in ip:
        parts = ip.split(".")
        if len(parts) == 4:
            try:
                return all(0 <= int(part) <= 255 for part in parts)
            except ValueError:
                return False

    # IPv6 简单验证
    if ":" in ip:
        return True  # 简化处理，包含冒号就认为是IPv6

    return False

# 记录访问日志（增强版，支持所有类型的访问）
def log_access(uuid_str, ip, full_path, access_type='proxy', proxy_path=None, upstream_url=None, user_agent=None, status_code=200):
    """
    记录访问日志
    access_type: 'proxy' | 'page' | 'download' | '404' | 'blacklist' | 'direct'
    """
    access_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ip_location = get_ip_location(ip)

    conn = sqlite3.connect("access_logs.db")
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT INTO access_logs (uuid, ip, ip_location, access_time, full_path, proxy_path, upstream_url, user_agent, access_type, status_code)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (uuid_str, ip, ip_location, access_time, full_path, proxy_path, upstream_url, user_agent, access_type, status_code))
        conn.commit()
        logging.info(f"访问记录已保存 - 类型: {access_type}, UUID: {uuid_str}, IP: {ip}, 路径: {full_path}")
    finally:
        conn.close()

# 获取IP归属地（支持多种API提供商）
def get_nested_value(data, path):
    """从嵌套字典中获取值，支持 'data.city' 这样的路径"""
    keys = path.split(".")
    value = data
    for key in keys:
        if isinstance(value, dict) and key in value:
            value = value[key]
        else:
            return ""
    return value if value else ""

def get_ip_location(ip):
    """
    获取 IP 归属地
    支持多种 API 提供商，可在 config.json 中配置
    """
    ip_api_config = get_config().get("ip_api", {})

    if not ip_api_config.get("enabled", False):
        return "未启用IP查询"

    # 获取当前使用的提供商
    provider_name = ip_api_config.get("provider", "ip-api")
    providers = ip_api_config.get("providers", {})

    if provider_name not in providers:
        return "未配置IP查询提供商"

    provider = providers[provider_name]

    try:
        # 构建请求 URL
        api_url = provider["url"].format(ip=ip)
        method = provider.get("method", "GET").upper()

        # 发送请求
        if method == "GET":
            response = requests.get(api_url, timeout=5)
        elif method == "POST":
            response = requests.post(api_url, timeout=5)
        else:
            return "不支持的请求方法"

        if response.status_code != 200:
            return "查询失败"

        data = response.json()

        # 检查是否成功
        success_field = provider.get("success_field")
        success_value = provider.get("success_value")

        if success_field and success_value is not None:
            actual_value = get_nested_value(data, success_field)
            if actual_value != success_value:
                return "查询失败"

        # 提取结果
        result_path = provider.get("result_path", {})
        country = get_nested_value(data, result_path.get("country", "country"))
        region = get_nested_value(data, result_path.get("region", "region"))
        city = get_nested_value(data, result_path.get("city", "city"))

        # 组合结果
        parts = [p for p in [country, region, city] if p]
        return "-".join(parts) if parts else "未知地区"

    except requests.exceptions.Timeout:
        return "查询超时"
    except requests.exceptions.RequestException:
        return "网络错误"
    except ValueError:
        return "解析失败"
    except Exception:
        return "查询失败"

# 首页
@app.route("/")
def index():
    client_ip = get_real_ip()
    user_agent = request.headers.get('User-Agent', 'Unknown')

    # 记录首页访问
    log_access(
        uuid_str=str(uuid.uuid4()),
        ip=client_ip,
        full_path="/",
        access_type='page',
        user_agent=user_agent,
        status_code=200
    )

    index_file = "pages/index.html"
    if os.path.exists(index_file):
        return send_file(index_file)
    else:
        # 记录404
        log_access(
            uuid_str=str(uuid.uuid4()),
            ip=client_ip,
            full_path="/",
            access_type='404',
            user_agent=user_agent,
            status_code=404
        )
        return "404 - 首页文件不存在", 404

# 查询所有访问记录
@app.route(config["query_path"])
def query_all_access():
    conn = sqlite3.connect("access_logs.db")
    cursor = conn.cursor()
    cursor.execute("""
        SELECT uuid, ip, ip_location, access_time, upstream_url, user_agent
        FROM access_logs ORDER BY access_time DESC
    """)
    results = cursor.fetchall()
    conn.close()

    if results:
        data = []
        for result in results:
            data.append({
                "uuid": result[0],
                "ip": result[1],
                "ip_location": result[2],
                "access_time": result[3],
                "upstream_url": result[4],
                "user_agent": result[5]
            })
        return jsonify({
            "success": True,
            "total": len(data),
            "data": data
        })
    else:
        return jsonify({"success": True, "total": 0, "data": []}), 200

# 查询指定 UUID 的所有访问记录
@app.route(config["query_path"] + "/<uuid_str>")
def query_access(uuid_str):
    conn = sqlite3.connect("access_logs.db")
    cursor = conn.cursor()
    cursor.execute("""
        SELECT uuid, ip, ip_location, access_time, upstream_url, user_agent
        FROM access_logs WHERE uuid=? ORDER BY access_time DESC
    """, (uuid_str,))
    results = cursor.fetchall()
    conn.close()

    if results:
        data = []
        for result in results:
            data.append({
                "uuid": result[0],
                "ip": result[1],
                "ip_location": result[2],
                "access_time": result[3],
                "upstream_url": result[4],
                "user_agent": result[5]
            })
        return jsonify({
            "success": True,
            "total": len(data),
            "data": data
        })
    else:
        return jsonify({"success": False, "message": "未找到该UUID的访问记录"}), 404

# 代理处理函数
def handle_proxy(path, route):
    proxy_path = route["path"].strip("/")
    upstream = route["upstream"].rstrip("/")

    # 构建上游URL - 保持完整路径
    remaining_path = path[len(proxy_path):]
    upstream_url = upstream + "/" + proxy_path + remaining_path

    # 添加查询参数（直接拼接，保持原始格式）
    if request.query_string:
        upstream_url += "?" + request.query_string.decode('utf-8')

    # 获取客户端真实IP（使用优化后的函数）
    client_ip = get_real_ip()

    logging.info(f"代理请求 - 方法: {request.method}, IP: {client_ip}, 路径: /{path}, 转发到: {upstream_url}")

    # ========== IP 黑名单检查 ==========
    if is_ip_blocked(client_ip):
        block_msg = get_block_message()
        logging.warning(f"IP 被封禁 - IP: {client_ip}, 路径: /{path}")

        # 记录黑名单拦截
        log_access(
            uuid_str=str(uuid.uuid4()),
            ip=client_ip,
            full_path="/" + path,
            access_type='blacklist',
            user_agent=request.headers.get('User-Agent', 'Unknown'),
            status_code=403
        )

        return jsonify({
            "error": "Access Denied",
            "message": block_msg,
            "ip": client_ip
        }), 403

    # 提取UUID（假设UUID在路径的最后一段）
    path_parts = remaining_path.strip("/").split("/")
    uuid_str = path_parts[-1] if path_parts and path_parts[-1] else str(uuid.uuid4())

    # 获取 User-Agent
    user_agent = request.headers.get('User-Agent', 'Unknown')

    # 记录访问日志
    if route.get("record_access", False):
        log_access(
            uuid_str=uuid_str,
            ip=client_ip,
            full_path="/" + path,
            access_type='proxy',
            proxy_path=route["path"],
            upstream_url=upstream_url,
            user_agent=user_agent,
            status_code=200
        )

    try:
        # ========== 准备转发的请求头 ==========
        # 所有 IP 相关头部必须先排除，再由代理统一重建
        # 避免入站旧头部（可能来自 CDN/Nginx，且大小写不一致）与新设置的头部在 dict 中共存
        # Python dict 大小写敏感，但 HTTP header 大小写不敏感，共存会导致上游收到重复冲突的值
        ip_related_headers = {
            'host', 'connection',
            # 标准 IP 透传头 — 由代理统一重建
            'x-forwarded-for', 'x-real-ip', 'x-client-ip',
            'x-forwarded-proto', 'x-forwarded-host', 'x-forwarded-port',
            'x-original-forwarded-for', 'forwarded', 'forwarded-for',
            # CDN 专有 IP 头 — 上游不在 CDN 后面，转发无意义且会干扰上游 IP 解析
            'cf-connecting-ip', 'true-client-ip', 'fastly-client-ip',
            'ali-cdn-real-ip', 'cdn-src-ip', 'x-tencent-ua',
            'cf-pseudo-ipv4', 'x-proxyuser-ip',
            'wl-proxy-client-ip', 'proxy-client-ip',
            'x-cluster-client-ip',
        }
        headers = {}
        for key, value in request.headers:
            if key.lower() not in ip_related_headers:
                headers[key] = value

        # ========== 构建完整的 IP 透传头部 ==========
        # 所有 IP 头部只包含用户真实 IP，不暴露代理服务器自身 IP

        # 1. X-Forwarded-For: 只包含用户真实 IP（不链式追加，不暴露代理链路）
        headers['X-Forwarded-For'] = client_ip

        # 2. X-Real-IP: 最终用户的真实 IP
        headers['X-Real-IP'] = client_ip

        # 3. X-Client-IP: 兼容性头部
        headers['X-Client-IP'] = client_ip

        # 4. True-Client-IP: 穿透上游 Nginx 的关键头部
        #    Nginx 默认只覆盖 X-Real-IP / X-Forwarded-For，不会动 True-Client-IP
        #    上游 IpHelper 优先级第2位读取此头部，无需改动插件代码即可拿到真实 IP
        headers['True-Client-IP'] = client_ip

        # 5. X-Forwarded-Proto / Host / Port
        headers['X-Forwarded-Proto'] = request.scheme
        headers['X-Forwarded-Host'] = request.host
        if ':' in request.host:
            forwarded_port = request.host.rsplit(':', 1)[-1]
        else:
            forwarded_port = '443' if request.scheme == 'https' else '80'
        headers['X-Forwarded-Port'] = forwarded_port

        # 6. Forwarded（RFC 7239 标准）— 只包含用户 IP，不暴露代理 IP
        forwarded_for = f'"{client_ip}"' if ':' in client_ip else client_ip
        headers['Forwarded'] = f'for={forwarded_for};proto={request.scheme};host="{request.host}"'

        # 准备请求参数
        request_kwargs = {
            'headers': headers,
            # 区分连接超时和读取超时：(连接超时, 读取超时)
            # 连接超时10秒，读取超时300秒（支持大文件和慢速连接）
            'timeout': (10, 300),
            'allow_redirects': False,
            'stream': True,  # 启用流式传输
        }

        # 对于有请求体的方法，传递原始数据
        if request.method in ['POST', 'PUT', 'PATCH']:
            # 使用 request.stream 进行流式传输，支持大文件上传
            # Content-Length 头已经在上面被保留并转发
            # 如果客户端发送了压缩的请求体（Content-Encoding），也会被正确转发
            request_kwargs['data'] = request.stream

        # 发送请求 - 支持所有HTTP方法
        response = requests.request(
            method=request.method,
            url=upstream_url,
            **request_kwargs
        )

        logging.info(f"代理响应 - IP: {client_ip}, 状态码: {response.status_code}, UUID: {uuid_str}")

        # ==================== 智能内容编码处理 ====================
        # 根据客户端能力和请求类型决定是否解压内容

        # 1. 检查是否是 Range 请求（断点续传）
        is_range_request = 'Range' in request.headers or response.status_code == 206

        # 2. 获取客户端支持的编码
        client_accept_encoding = request.headers.get('Accept-Encoding', '').lower()
        client_has_accept_encoding = bool(client_accept_encoding.strip())

        # 解析客户端支持的压缩算法
        client_supported_encodings = set()
        if client_has_accept_encoding:
            # 解析 "gzip, deflate, br" 格式
            for encoding in client_accept_encoding.replace(' ', '').split(','):
                if encoding and encoding != '*':
                    client_supported_encodings.add(encoding)

        # 3. 获取上游响应的编码
        upstream_content_encoding = response.headers.get('Content-Encoding', '').lower().strip()

        # 解析上游使用的压缩算法（可能是多重编码，如 "gzip, deflate"）
        upstream_encodings = []
        if upstream_content_encoding:
            upstream_encodings = [enc.strip() for enc in upstream_content_encoding.split(',') if enc.strip()]

        # 4. 决定是否需要解压
        should_decode = False
        decode_reason = "保持原样"

        if is_range_request:
            # Range 请求必须保持原样，否则字节范围会错乱
            should_decode = False
            decode_reason = "Range请求，禁止解压"
        elif not upstream_encodings:
            # 上游没有压缩，保持原样
            should_decode = False
            decode_reason = "上游未压缩"
        elif not client_has_accept_encoding:
            # 客户端没有声明 Accept-Encoding
            # 保守策略：解压内容，确保兼容性（如某些代理客户端）
            should_decode = True
            decode_reason = "客户端未声明Accept-Encoding，解压以确保兼容"
        else:
            # 检查上游的编码是否都被客户端支持
            # 注意：requests 的 decode_content 只支持 gzip 和 deflate
            unsupported_encodings = []
            for encoding in upstream_encodings:
                if encoding not in client_supported_encodings:
                    # 客户端不支持这个编码
                    if encoding in ['gzip', 'deflate']:
                        # requests 可以解压
                        unsupported_encodings.append(encoding)
                    else:
                        # br (Brotli) 等其他编码，requests 无法解压
                        # 只能保持原样，让客户端处理（可能失败）
                        logging.warning(f"上游使用了 {encoding} 编码，但客户端不支持且代理无法解压")

            if unsupported_encodings:
                should_decode = True
                decode_reason = f"客户端不支持 {', '.join(unsupported_encodings)}，需要解压"
            else:
                should_decode = False
                decode_reason = "客户端支持上游编码"

        logging.info(f"内容编码处理 - 上游: [{upstream_content_encoding or '无'}], "
                    f"客户端: [{client_accept_encoding or '未声明'}], "
                    f"Range请求: {is_range_request}, "
                    f"解压: {should_decode} ({decode_reason})")

        # ==================== 构建响应头 ====================
        # 完全透明代理，保留所有原始响应头
        # 只排除可能导致冲突的传输层相关头
        excluded_headers = ['transfer-encoding', 'connection', 'keep-alive',
                           'proxy-authenticate', 'proxy-authorization', 'te',
                           'trailers', 'upgrade']

        # 如果需要解压，还要移除 Content-Encoding 和 Content-Length 头
        # 因为解压后的内容大小会改变
        if should_decode:
            excluded_headers.extend(['content-encoding', 'content-length'])
            logging.info("将解压内容并移除 Content-Encoding 和 Content-Length 头")

        response_headers = []
        for name, value in response.raw.headers.items():
            if name.lower() not in excluded_headers:
                response_headers.append((name, value))

        # ==================== 流式传输响应体 ====================
        def generate():
            try:
                # decode_content 参数：
                # - False: 保持原始压缩状态（透明转发）
                # - True: 自动解压 gzip/deflate（确保客户端兼容）
                for chunk in response.raw.stream(8192, decode_content=should_decode):
                    if chunk:  # 过滤掉保持连接的空块
                        yield chunk
            finally:
                response.close()  # 确保关闭连接

        return Response(generate(), response.status_code, response_headers)

    except requests.exceptions.Timeout:
        logging.error(f"代理请求超时 - IP: {client_ip}, URL: {upstream_url}")
        return jsonify({"error": "上游服务器响应超时"}), 504
    except requests.exceptions.ConnectionError as e:
        logging.error(f"代理连接失败 - IP: {client_ip}, URL: {upstream_url}, 错误: {str(e)}")
        return jsonify({"error": "无法连接到上游服务器"}), 502
    except requests.exceptions.RequestException as e:
        logging.error(f"代理请求失败 - IP: {client_ip}, URL: {upstream_url}, 错误: {str(e)}")
        return jsonify({"error": f"代理请求失败: {str(e)}"}), 502
    except Exception as e:
        logging.error(f"代理处理异常 - IP: {client_ip}, URL: {upstream_url}, 错误: {str(e)}")
        return jsonify({"error": "内部服务器错误"}), 500

# 处理HTML页面/文件下载路由
@app.route("/<path:path>", methods=['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS'])
def catch_all(path):
    client_ip = get_real_ip()
    user_agent = request.headers.get('User-Agent', 'Unknown')

    # 检查是否是配置的页面/文件路由
    route_path = "/" + path
    html_pages = get_config().get("routes", {}).get("html_pages", {})

    if route_path in html_pages:
        page_config = html_pages[route_path]
        file_path = page_config.get("file", "")
        route_type = page_config.get("type", "display")

        if os.path.exists(file_path):
            # 记录访问日志
            access_type = 'download' if route_type == 'download' else 'page'
            log_access(
                uuid_str=str(uuid.uuid4()),
                ip=client_ip,
                full_path=route_path,
                access_type=access_type,
                user_agent=user_agent,
                status_code=200
            )

            # 根据类型决定是显示还是下载
            if route_type == "download":
                # 触发下载
                filename = os.path.basename(file_path)
                return send_file(
                    file_path,
                    as_attachment=True,
                    download_name=filename
                )
            else:
                # 直接显示（默认行为）
                return send_file(file_path)
        else:
            # 记录404
            log_access(
                uuid_str=str(uuid.uuid4()),
                ip=client_ip,
                full_path=route_path,
                access_type='404',
                user_agent=user_agent,
                status_code=404
            )
            return f"文件不存在: {file_path}", 404

    # 检查是否是代理路由
    proxy_routes = get_config().get("routes", {}).get("proxy_routes", [])
    for route in proxy_routes:
        proxy_path = route["path"].strip("/")
        # 精确匹配：完全匹配或者匹配后跟斜杠
        if path == proxy_path or path.startswith(proxy_path + "/"):
            return handle_proxy(path, route)

    # 未找到路径，返回 404 页面
    log_access(
        uuid_str=str(uuid.uuid4()),
        ip=client_ip,
        full_path=route_path,
        access_type='404',
        user_agent=user_agent,
        status_code=404
    )

    not_found_file = "pages/404.html"
    if os.path.exists(not_found_file):
        return send_file(not_found_file), 404
    else:
        return "404 - 页面未找到", 404

if __name__ == "__main__":
    app.run(
        host=config["server"]["host"],
        port=config["server"]["port"],
        debug=True
    )

