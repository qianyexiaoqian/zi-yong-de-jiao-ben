#!/bin/bash

# 配置 - 转发服务
FORWARD_NAME="转发服务"
FORWARD_FILE="app.py"
FORWARD_PID_FILE="app.pid"
FORWARD_LOG_FILE="logs/app.log"
FORWARD_CONFIG_FILE="config.yaml"

# 配置 - 管理服务
ADMIN_NAME="管理服务"
ADMIN_FILE="admin.py"
ADMIN_PID_FILE="admin.pid"
ADMIN_LOG_FILE="logs/admin.log"
ADMIN_CONFIG_FILE="admin_config.yaml"

# 通用配置
VENV_DIR=".venv"
VENV_FLAG_FILE=".use_venv"

# 颜色
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m'

print_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
print_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# 获取 Python 命令
get_python_cmd() {
    if [ -f "$VENV_FLAG_FILE" ] && [ -d "$VENV_DIR" ]; then
        if [ -f "$VENV_DIR/bin/python" ]; then
            echo "$VENV_DIR/bin/python"
        elif [ -f "$VENV_DIR/Scripts/python.exe" ]; then
            echo "$VENV_DIR/Scripts/python.exe"
        else
            echo "python3"
        fi
    else
        if command -v python3 &> /dev/null; then
            echo "python3"
        elif command -v python &> /dev/null; then
            echo "python"
        else
            echo "python3"
        fi
    fi
}

# 获取 uv 运行命令
get_uv_run_cmd() {
    if [ -f "$VENV_FLAG_FILE" ] && command -v uv &> /dev/null; then
        echo "uv run"
    else
        echo "$(get_python_cmd)"
    fi
}

is_running() {
    local pid_file=$1
    if [ -f "$pid_file" ]; then
        pid=$(cat "$pid_file")
        if ps -p "$pid" > /dev/null 2>&1; then
            return 0
        else
            rm -f "$pid_file"
            return 1
        fi
    fi
    return 1
}

get_pid() {
    local pid_file=$1
    if [ -f "$pid_file" ]; then
        cat "$pid_file"
    else
        echo ""
    fi
}

start_background() {
    local service_name=$1
    local app_file=$2
    local pid_file=$3
    local config_file=$4

    print_info "正在启动 ${service_name}..."
    if is_running "$pid_file"; then
        print_warning "${service_name} 已经在运行中 (PID: $(get_pid $pid_file))"
        return 1
    fi
    if [ ! -f "$config_file" ]; then
        print_error "配置文件不存在: $config_file"
        return 1
    fi

    # 使用 uv 或 python 命令
    if [ -f "$VENV_FLAG_FILE" ] && command -v uv &> /dev/null; then
        PYTHON_CMD="uv run python"
    else
        PYTHON_CMD=$(get_python_cmd)
    fi

    mkdir -p logs
    nohup $PYTHON_CMD "$app_file" > /dev/null 2>&1 &
    pid=$!
    echo $pid > "$pid_file"
    sleep 2
    if is_running "$pid_file"; then
        print_success "${service_name} 启动成功 (PID: $pid)"
    else
        print_error "${service_name} 启动失败"
        rm -f "$pid_file"
        return 1
    fi
}

stop_app() {
    local service_name=$1
    local pid_file=$2

    print_info "正在停止 ${service_name}..."
    if ! is_running "$pid_file"; then
        print_warning "${service_name} 未运行"
        return 1
    fi
    pid=$(get_pid "$pid_file")
    kill "$pid" 2>/dev/null
    for i in {1..10}; do
        if ! is_running "$pid_file"; then
            rm -f "$pid_file"
            print_success "${service_name} 已停止"
            return 0
        fi
        sleep 1
    done
    print_warning "正在强制停止..."
    kill -9 "$pid" 2>/dev/null
    rm -f "$pid_file"
    print_success "${service_name} 已强制停止"
}

restart_app() {
    local service_name=$1
    local app_file=$2
    local pid_file=$3
    local config_file=$4

    print_info "正在重启 ${service_name}..."
    stop_app "$service_name" "$pid_file"
    sleep 2
    start_background "$service_name" "$app_file" "$pid_file" "$config_file"
}

view_logs() {
    local service_name=$1
    local log_file=$2

    if [ ! -f "$log_file" ]; then
        print_warning "日志文件不存在: $log_file"
        return 1
    fi
    print_info "查看 ${service_name} 日志 (按 Ctrl+C 退出)..."
    echo "----------------------------------------"
    tail -f "$log_file"
}

start_foreground() {
    local service_name=$1
    local app_file=$2
    local pid_file=$3
    local config_file=$4

    print_info "正在前台启动 ${service_name}..."
    if is_running "$pid_file"; then
        print_warning "${service_name} 已经在运行中 (PID: $(get_pid $pid_file))"
        print_info "请先停止后台进程"
        return 1
    fi
    if [ ! -f "$config_file" ]; then
        print_error "配置文件不存在: $config_file"
        return 1
    fi

    # 使用 uv 或 python 命令
    if [ -f "$VENV_FLAG_FILE" ] && command -v uv &> /dev/null; then
        PYTHON_CMD="uv run python"
    else
        PYTHON_CMD=$(get_python_cmd)
    fi

    mkdir -p logs
    print_info "启动中... (按 Ctrl+C 停止)"
    echo "----------------------------------------"
    $PYTHON_CMD "$app_file"
}

show_status() {
    echo "========================================"
    echo "  服务状态"
    echo "========================================"
    echo ""

    # 转发服务状态
    echo -e "${CYAN}【转发服务】${NC}"
    if is_running "$FORWARD_PID_FILE"; then
        pid=$(get_pid "$FORWARD_PID_FILE")
        print_success "状态: 运行中"
        echo "PID: $pid"
        if command -v ps &> /dev/null; then
            mem=$(ps -p "$pid" -o rss= 2>/dev/null | awk '{print $1/1024 " MB"}')
            echo "内存: $mem"
            etime=$(ps -p "$pid" -o etime= 2>/dev/null | xargs)
            echo "运行时间: $etime"
        fi
        if [ -f "$FORWARD_CONFIG_FILE" ]; then
            if command -v python3 &> /dev/null; then
                port=$(python3 -c "import yaml; print(yaml.safe_load(open('$FORWARD_CONFIG_FILE'))['server']['port'])" 2>/dev/null)
                if [ -n "$port" ]; then
                    echo "监听端口: $port"
                fi
            fi
        fi
    else
        print_warning "状态: 未运行"
    fi

    echo ""

    # 管理服务状态
    echo -e "${MAGENTA}【管理服务】${NC}"
    if is_running "$ADMIN_PID_FILE"; then
        pid=$(get_pid "$ADMIN_PID_FILE")
        print_success "状态: 运行中"
        echo "PID: $pid"
        if command -v ps &> /dev/null; then
            mem=$(ps -p "$pid" -o rss= 2>/dev/null | awk '{print $1/1024 " MB"}')
            echo "内存: $mem"
            etime=$(ps -p "$pid" -o etime= 2>/dev/null | xargs)
            echo "运行时间: $etime"
        fi
        if [ -f "$ADMIN_CONFIG_FILE" ]; then
            if command -v python3 &> /dev/null; then
                port=$(python3 -c "import yaml; print(yaml.safe_load(open('$ADMIN_CONFIG_FILE'))['server']['port'])" 2>/dev/null)
                if [ -n "$port" ]; then
                    echo "监听端口: $port"
                fi
            fi
        fi
    else
        print_warning "状态: 未运行"
    fi
    echo ""
}

install_dependencies() {
    clear
    echo "========================================"
    echo "  一键安装依赖"
    echo "========================================"
    echo ""

    # 检测操作系统
    print_info "检测操作系统..."
    OS_TYPE=""
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS_TYPE=$ID
    elif [ "$(uname)" == "Darwin" ]; then
        OS_TYPE="macos"
    else
        print_error "无法识别操作系统"
        return 1
    fi
    print_success "操作系统: $OS_TYPE"

    # 检查 Python
    echo ""
    print_info "检查 Python..."
    if command -v python3 &> /dev/null; then
        PYTHON_VERSION=$(python3 --version)
        print_success "Python 已安装: $PYTHON_VERSION"
    else
        print_warning "Python3 未安装，正在安装..."
        case $OS_TYPE in
            ubuntu|debian)
                sudo apt update && sudo apt install -y python3 python3-pip python3-venv
                ;;
            centos|rhel|fedora)
                sudo yum install -y python3 python3-pip
                ;;
            macos)
                if command -v brew &> /dev/null; then
                    brew install python3
                else
                    print_error "请先安装 Homebrew: https://brew.sh"
                    return 1
                fi
                ;;
            *)
                print_error "不支持的操作系统: $OS_TYPE"
                return 1
                ;;
        esac
        if ! command -v python3 &> /dev/null; then
            print_error "Python3 安装失败"
            return 1
        fi
        print_success "Python3 安装成功"
    fi

    # 检查并安装 uv
    echo ""
    print_info "检查 uv 包管理器..."
    if command -v uv &> /dev/null; then
        UV_VERSION=$(uv --version 2>/dev/null || echo "unknown")
        print_success "uv 已安装: $UV_VERSION"
    else
        print_info "正在安装 uv（极速 Python 包管理器）..."
        if command -v curl &> /dev/null; then
            curl -LsSf https://astral.sh/uv/install.sh | sh
            export PATH="$HOME/.local/bin:$HOME/.cargo/bin:$PATH"

            if command -v uv &> /dev/null; then
                print_success "uv 安装成功"
            else
                print_warning "uv 安装失败，将降级使用 pip + venv"
            fi
        else
            print_warning "curl 未安装，无法安装 uv，将使用 pip + venv"
        fi
    fi

    # 检查 requirements.txt
    if [ ! -f "requirements.txt" ]; then
        print_error "requirements.txt 文件不存在"
        return 1
    fi

    # 使用 uv 安装（优先）
    echo ""
    if command -v uv &> /dev/null; then
        print_info "使用 uv 安装依赖..."

        # 创建虚拟环境
        if [ ! -d "$VENV_DIR" ]; then
            print_info "创建虚拟环境..."
            uv venv "$VENV_DIR"
        fi

        # 安装依赖
        uv pip install -r requirements.txt

        if [ $? -eq 0 ]; then
            print_success "依赖安装成功！"
            echo ""
            print_info "已安装的包:"
            uv pip list 2>/dev/null | grep -E "flask|requests|pyyaml|flask-cors" || \
            uv pip freeze 2>/dev/null | grep -E "Flask|requests|PyYAML|flask-cors"
            touch "$VENV_FLAG_FILE"
            print_info "已启用 uv 虚拟环境模式"
        else
            print_error "uv 安装失败，尝试降级到 pip..."
            rm -rf "$VENV_DIR"
            command -v uv &> /dev/null && uv="fallback"
        fi
    fi

    # 降级到 pip + venv（如果 uv 失败或不可用）
    if [ ! -f "$VENV_FLAG_FILE" ]; then
        print_info "使用 pip + venv 安装依赖..."

        # 确保 python3-venv 已安装
        if ! python3 -m venv --help &> /dev/null; then
            print_info "安装 python3-venv..."
            case $OS_TYPE in
                ubuntu|debian)
                    sudo apt update && sudo apt install -y python3-venv python3-full
                    ;;
                centos|rhel|fedora)
                    sudo yum install -y python3-virtualenv
                    ;;
            esac
        fi

        # 创建虚拟环境
        if [ ! -d "$VENV_DIR" ]; then
            print_info "创建虚拟环境..."
            python3 -m venv "$VENV_DIR"
            if [ $? -ne 0 ]; then
                print_error "虚拟环境创建失败"
                return 1
            fi
        fi

        # 激活并安装
        if [ -f "$VENV_DIR/bin/activate" ]; then
            source "$VENV_DIR/bin/activate"
            PIP_CMD="$VENV_DIR/bin/pip"
        elif [ -f "$VENV_DIR/Scripts/activate" ]; then
            source "$VENV_DIR/Scripts/activate"
            PIP_CMD="$VENV_DIR/Scripts/pip.exe"
        else
            print_error "无法激活虚拟环境"
            return 1
        fi

        print_info "正在安装依赖..."
        $PIP_CMD install --upgrade pip
        $PIP_CMD install -r requirements.txt

        if [ $? -eq 0 ]; then
            print_success "依赖安装成功！"
            echo ""
            print_info "已安装的包:"
            $PIP_CMD list | grep -E "Flask|requests|PyYAML|flask-cors"
            touch "$VENV_FLAG_FILE"
            print_info "已启用虚拟环境模式"
        else
            print_error "依赖安装失败"
            return 1
        fi
    fi

    echo ""
    print_success "所有依赖安装完成！"
    echo ""
    read -p "按 Enter 键返回主菜单..."
}

set_timezone() {
    clear
    echo "========================================"
    echo "  设置系统时区"
    echo "========================================"
    echo ""

    # 显示当前时区
    print_info "当前系统时区:"
    if command -v timedatectl &> /dev/null; then
        current_tz=$(timedatectl | grep "Time zone" | awk '{print $3}')
        current_time=$(date "+%Y-%m-%d %H:%M:%S %Z")
        echo "时区: $current_tz"
        echo "时间: $current_time"
    else
        current_time=$(date "+%Y-%m-%d %H:%M:%S %Z")
        echo "时间: $current_time"
    fi

    echo ""
    echo "========================================"
    echo "  常用时区列表"
    echo "========================================"
    echo ""
    echo "  1) 北京时间 (Asia/Shanghai) - UTC+8 [常用]"
    echo "  2) 洛杉矶时间 (America/Los_Angeles) - UTC-8/-7 [常用]"
    echo "  3) 纽约时间 (America/New_York) - UTC-5/-4 [常用]"
    echo "  4) 伦敦时间 (Europe/London) - UTC+0/+1 [常用]"
    echo "  5) 东京时间 (Asia/Tokyo) - UTC+9"
    echo "  6) 香港时间 (Asia/Hong_Kong) - UTC+8"
    echo "  7) 新加坡时间 (Asia/Singapore) - UTC+8"
    echo "  8) 悉尼时间 (Australia/Sydney) - UTC+10/+11"
    echo "  9) 巴黎时间 (Europe/Paris) - UTC+1/+2"
    echo " 10) UTC 时间 (UTC) - UTC+0"
    echo "  0) 返回主菜单"
    echo ""

    read -p "请选择时区 [0-10]: " tz_choice

    case $tz_choice in
        1) TIMEZONE="Asia/Shanghai" ;;
        2) TIMEZONE="America/Los_Angeles" ;;
        3) TIMEZONE="America/New_York" ;;
        4) TIMEZONE="Europe/London" ;;
        5) TIMEZONE="Asia/Tokyo" ;;
        6) TIMEZONE="Asia/Hong_Kong" ;;
        7) TIMEZONE="Asia/Singapore" ;;
        8) TIMEZONE="Australia/Sydney" ;;
        9) TIMEZONE="Europe/Paris" ;;
        10) TIMEZONE="UTC" ;;
        0) return 0 ;;
        *)
            print_error "无效选项"
            sleep 2
            return 1
            ;;
    esac

    echo ""
    print_info "正在设置时区为: $TIMEZONE"

    # 检测操作系统并设置时区
    if command -v timedatectl &> /dev/null; then
        # 使用 timedatectl（systemd 系统）
        sudo timedatectl set-timezone "$TIMEZONE"
        if [ $? -eq 0 ]; then
            print_success "时区设置成功！"
            echo ""
            print_info "新的系统时间:"
            timedatectl | grep "Time zone"
            date "+%Y-%m-%d %H:%M:%S %Z"
        else
            print_error "时区设置失败"
        fi
    elif [ -f /etc/timezone ]; then
        # Debian/Ubuntu 旧版本
        echo "$TIMEZONE" | sudo tee /etc/timezone > /dev/null
        sudo ln -sf "/usr/share/zoneinfo/$TIMEZONE" /etc/localtime
        if [ $? -eq 0 ]; then
            print_success "时区设置成功！"
            echo ""
            print_info "新的系统时间:"
            date "+%Y-%m-%d %H:%M:%S %Z"
        else
            print_error "时区设置失败"
        fi
    else
        # 通用方法
        sudo ln -sf "/usr/share/zoneinfo/$TIMEZONE" /etc/localtime
        if [ $? -eq 0 ]; then
            print_success "时区设置成功！"
            echo ""
            print_info "新的系统时间:"
            date "+%Y-%m-%d %H:%M:%S %Z"
        else
            print_error "时区设置失败"
        fi
    fi

    echo ""
    print_warning "提示: 如果应用正在运行，建议重启以应用新时区"
    echo ""
    read -p "按 Enter 键返回主菜单..."
}

show_menu() {
    clear
    echo "========================================"
    echo "  服务管理脚本"
    echo "========================================"
    echo ""
    show_status
    echo "========================================"
    echo "  操作菜单"
    echo "========================================"
    echo ""
    echo -e "${CYAN}【转发服务】${NC}"
    echo "  1) 后台启动转发服务"
    echo "  2) 停止转发服务"
    echo "  3) 重启转发服务"
    echo "  4) 查看转发日志"
    echo "  5) 前台启动转发服务"
    echo ""
    echo -e "${MAGENTA}【管理服务】${NC}"
    echo "  6) 后台启动管理服务"
    echo "  7) 停止管理服务"
    echo "  8) 重启管理服务"
    echo "  9) 查看管理日志"
    echo " 10) 前台启动管理服务"
    echo ""
    echo -e "${YELLOW}【系统设置】${NC}"
    echo " 11) 设置时区"
    echo " 12) 安装依赖"
    echo ""
    echo "  0) 退出"
    echo ""
}

# 读取用户输入（支持退格删除）
read_input() {
    local prompt="$1"
    local input=""
    # 使用 -e 选项启用 readline 编辑功能，支持退格、箭头等
    read -e -p "$prompt" input
    echo "$input"
}

main() {
    while true; do
        show_menu
        choice=$(read_input "请输入选项 [0-12]: ")
        echo ""
        case $choice in
            1)
                start_background "$FORWARD_NAME" "$FORWARD_FILE" "$FORWARD_PID_FILE" "$FORWARD_CONFIG_FILE"
                echo ""
                read -p "按 Enter 键继续..."
                ;;
            2)
                stop_app "$FORWARD_NAME" "$FORWARD_PID_FILE"
                echo ""
                read -p "按 Enter 键继续..."
                ;;
            3)
                restart_app "$FORWARD_NAME" "$FORWARD_FILE" "$FORWARD_PID_FILE" "$FORWARD_CONFIG_FILE"
                echo ""
                read -p "按 Enter 键继续..."
                ;;
            4)
                view_logs "$FORWARD_NAME" "$FORWARD_LOG_FILE"
                ;;
            5)
                start_foreground "$FORWARD_NAME" "$FORWARD_FILE" "$FORWARD_PID_FILE" "$FORWARD_CONFIG_FILE"
                ;;
            6)
                start_background "$ADMIN_NAME" "$ADMIN_FILE" "$ADMIN_PID_FILE" "$ADMIN_CONFIG_FILE"
                echo ""
                read -p "按 Enter 键继续..."
                ;;
            7)
                stop_app "$ADMIN_NAME" "$ADMIN_PID_FILE"
                echo ""
                read -p "按 Enter 键继续..."
                ;;
            8)
                restart_app "$ADMIN_NAME" "$ADMIN_FILE" "$ADMIN_PID_FILE" "$ADMIN_CONFIG_FILE"
                echo ""
                read -p "按 Enter 键继续..."
                ;;
            9)
                view_logs "$ADMIN_NAME" "$ADMIN_LOG_FILE"
                ;;
            10)
                start_foreground "$ADMIN_NAME" "$ADMIN_FILE" "$ADMIN_PID_FILE" "$ADMIN_CONFIG_FILE"
                ;;
            11)
                set_timezone
                ;;
            12)
                install_dependencies
                ;;
            0)
                print_info "退出管理脚本"
                exit 0
                ;;
            *)
                print_error "无效选项，请重新选择"
                sleep 2
                ;;
        esac
    done
}

main
