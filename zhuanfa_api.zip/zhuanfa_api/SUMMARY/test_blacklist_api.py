#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
测试黑名单 API 是否正常工作
"""

import yaml
import json

def test_load_main_config():
    """测试加载主配置文件"""
    print("=" * 60)
    print("测试1: 加载 config.yaml")
    print("=" * 60)
    
    try:
        with open("config.yaml", "r", encoding="utf-8") as f:
            config = yaml.safe_load(f)
        
        print("✅ 配置文件加载成功")
        print("\n配置文件内容:")
        print(json.dumps(config, indent=2, ensure_ascii=False))
        
        return config
    except Exception as e:
        print(f"❌ 配置文件加载失败: {e}")
        return None

def test_blacklist_config(config):
    """测试黑名单配置"""
    print("\n" + "=" * 60)
    print("测试2: 读取黑名单配置")
    print("=" * 60)
    
    if not config:
        print("❌ 配置为空，无法测试")
        return
    
    blacklist_config = config.get("ip_blacklist", {})
    
    print("\n黑名单配置:")
    print(json.dumps(blacklist_config, indent=2, ensure_ascii=False))
    
    # 检查各个字段
    print("\n字段检查:")
    print(f"  enabled: {blacklist_config.get('enabled', False)}")
    print(f"  block_message: {blacklist_config.get('block_message', '')}")
    print(f"  ips 数量: {len(blacklist_config.get('ips', []))}")
    print(f"  ip_ranges 数量: {len(blacklist_config.get('ip_ranges', []))}")
    print(f"  cidrs 数量: {len(blacklist_config.get('cidrs', []))}")
    
    # 详细显示
    print("\n详细内容:")
    print(f"  ips: {blacklist_config.get('ips', [])}")
    print(f"  ip_ranges: {blacklist_config.get('ip_ranges', [])}")
    print(f"  cidrs: {blacklist_config.get('cidrs', [])}")

def test_api_response_format(config):
    """测试 API 响应格式"""
    print("\n" + "=" * 60)
    print("测试3: 模拟 API 响应格式")
    print("=" * 60)
    
    if not config:
        print("❌ 配置为空，无法测试")
        return
    
    blacklist_config = config.get("ip_blacklist", {})
    
    # 模拟 API 返回的数据格式
    blacklist_data = {
        "enabled": blacklist_config.get("enabled", False),
        "block_message": blacklist_config.get("block_message", "您的IP已被禁止访问"),
        "ips": blacklist_config.get("ips", []),
        "ip_ranges": blacklist_config.get("ip_ranges", []),
        "cidrs": blacklist_config.get("cidrs", [])
    }
    
    api_response = {
        "success": True,
        "data": blacklist_data
    }
    
    print("\nAPI 响应格式:")
    print(json.dumps(api_response, indent=2, ensure_ascii=False))
    
    print("\n✅ API 响应格式正确")

if __name__ == "__main__":
    print("开始测试黑名单 API...\n")
    
    # 测试1: 加载配置
    config = test_load_main_config()
    
    # 测试2: 读取黑名单配置
    test_blacklist_config(config)
    
    # 测试3: 模拟 API 响应
    test_api_response_format(config)
    
    print("\n" + "=" * 60)
    print("测试完成")
    print("=" * 60)

