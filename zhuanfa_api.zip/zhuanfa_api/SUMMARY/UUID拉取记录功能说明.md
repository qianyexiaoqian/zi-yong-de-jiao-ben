# UUID拉取记录功能说明

## 功能概述

新增"UUID拉取记录"功能，用于统计和展示每个UUID的代理请求拉取次数，帮助管理员了解各UUID的使用情况。

## 功能特性

### 1. 今日UUID拉取排行

**功能说明：**
- 统计今日（当天）每个UUID的代理请求次数
- 按拉取次数从高到低排序
- 显示排名、UUID、拉取次数
- 前三名有特殊徽章标识（🥇🥈🥉）

**数据来源：**
- 从 `access_logs` 表中筛选今日数据
- 只统计 `access_type = 'proxy'` 的记录
- 按 `uuid` 分组统计

**显示信息：**
- 当前日期
- 今日总UUID数量
- 排行榜列表

### 2. 总UUID拉取排行

**功能说明：**
- 统计所有时间每个UUID的代理请求总次数
- 按总拉取次数从高到低排序
- 显示排名、UUID、总拉取次数
- 前三名有特殊徽章标识（🥇🥈🥉）

**数据来源：**
- 从 `access_logs` 表中统计所有数据
- 只统计 `access_type = 'proxy'` 的记录
- 按 `uuid` 分组统计

**显示信息：**
- 总UUID数量
- 排行榜列表

### 3. 查看详情功能

**功能说明：**
- 点击"查看详情"按钮可跳转到访问记录页面
- 自动填充UUID到搜索框并执行搜索
- 显示该UUID的所有访问记录详情

## 技术实现

### 后端API (admin.py)

#### 1. 今日UUID统计接口

```python
@app.route("/api/uuid-stats/today", methods=["GET"])
@login_required
def get_today_uuid_stats():
    # 查询今日每个UUID的拉取次数
    # 返回排序后的统计数据
```

**请求方式：** GET  
**请求路径：** `/api/uuid-stats/today`  
**需要认证：** 是

**响应示例：**
```json
{
    "success": true,
    "date": "2026-01-30",
    "total_uuids": 10,
    "data": [
        {
            "uuid": "abc123",
            "count": 150
        },
        {
            "uuid": "def456",
            "count": 120
        }
    ]
}
```

#### 2. 总UUID统计接口

```python
@app.route("/api/uuid-stats/total", methods=["GET"])
@login_required
def get_total_uuid_stats():
    # 查询所有UUID的总拉取次数
    # 返回排序后的统计数据
```

**请求方式：** GET  
**请求路径：** `/api/uuid-stats/total`  
**需要认证：** 是

**响应示例：**
```json
{
    "success": true,
    "total_uuids": 50,
    "data": [
        {
            "uuid": "abc123",
            "count": 5000
        },
        {
            "uuid": "def456",
            "count": 3500
        }
    ]
}
```

### 前端实现 (admin.html)

#### 1. 导航菜单

在侧边栏添加新的菜单项：

```html
<button onclick="showPage('uuidStats', event)" class="nav-item ...">
    <span class="material-symbols-outlined">analytics</span>
    <span>UUID拉取记录</span>
</button>
```

#### 2. 页面内容

新增 `uuidStatsPage` 页面，包含：
- 今日排行表格
- 总排行表格
- 排名徽章样式
- 查看详情按钮

#### 3. JavaScript函数

**loadUUIDStats()** - 加载UUID统计数据
```javascript
async function loadUUIDStats() {
    // 并行加载今日和总统计数据
    // 调用displayTodayStats和displayTotalStats显示
}
```

**displayTodayStats(data)** - 显示今日统计
```javascript
function displayTodayStats(data) {
    // 渲染今日排行表格
    // 添加排名徽章
}
```

**displayTotalStats(data)** - 显示总统计
```javascript
function displayTotalStats(data) {
    // 渲染总排行表格
    // 添加排名徽章
}
```

**viewUUIDRecords(uuid)** - 查看UUID详情
```javascript
function viewUUIDRecords(uuid) {
    // 切换到访问记录页面
    // 自动搜索该UUID的记录
}
```

## UI设计

### 排名徽章

- **第1名：** 🥇 金色徽章 (bg-yellow-500/20 text-yellow-400)
- **第2名：** 🥈 银色徽章 (bg-gray-400/20 text-gray-300)
- **第3名：** 🥉 铜色徽章 (bg-orange-600/20 text-orange-400)
- **其他：** 灰色文字

### 拉取次数标签

- **今日统计：** 红色标签 (bg-primary/20 text-primary)
- **总统计：** 绿色标签 (bg-success/20 text-success)

### 响应式设计

- 支持桌面端和移动端
- 表格可横向滚动
- 字体大小自适应

## 使用场景

1. **监控热门UUID**
   - 查看哪些UUID使用频率最高
   - 识别异常高频访问

2. **使用趋势分析**
   - 对比今日排行和总排行
   - 发现新增活跃UUID

3. **资源分配优化**
   - 根据使用频率调整资源
   - 优化高频UUID的服务质量

4. **安全审计**
   - 发现异常UUID访问模式
   - 追踪可疑UUID的详细记录

## 注意事项

1. **性能考虑**
   - 统计查询使用了GROUP BY，数据量大时可能较慢
   - 建议定期清理过期日志数据
   - 可考虑添加缓存机制

2. **数据准确性**
   - 只统计 `access_type = 'proxy'` 的记录
   - 不包括页面访问、下载、404等其他类型

3. **时区问题**
   - 今日统计基于服务器时区
   - 确保服务器时间设置正确

## 未来改进方向

1. **时间范围选择**
   - 支持查看指定日期的统计
   - 支持周统计、月统计

2. **图表展示**
   - 添加柱状图、折线图
   - 可视化趋势变化

3. **导出功能**
   - 导出统计数据为CSV/Excel
   - 生成统计报告

4. **实时更新**
   - WebSocket实时推送数据
   - 自动刷新排行榜

5. **高级筛选**
   - 按IP归属地筛选
   - 按时间段筛选
   - 按拉取次数范围筛选

