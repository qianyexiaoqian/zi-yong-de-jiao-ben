# 🔧 IP 归属地查询与黑名单配置指南

本文档详细说明如何配置 IP 归属地查询和 IP 黑名单功能。

---

## 📋 目录

1. [IP 归属地查询配置](#ip-归属地查询配置)
2. [IP 黑名单配置](#ip-黑名单配置)
3. [完整配置示例](#完整配置示例)
4. [常见问题](#常见问题)

---

## 🌍 IP 归属地查询配置

### 功能说明

系统会在记录访问日志时，自动查询访问者的 IP 归属地（国家、省份、城市）。

### 配置项说明

```json
{
  "ip_api": {
    "enabled": true,           // 是否启用 IP 查询
    "provider": "ip-api",      // 当前使用的提供商名称
    "providers": {             // 可用的提供商列表
      "ip-api": { ... },       // 提供商配置
      "ipinfo": { ... },
      "taobao": { ... }
    }
  }
}
```

---

### 内置提供商

#### 1. ip-api.com（推荐，免费）

```json
"ip-api": {
  "url": "http://ip-api.com/json/{ip}?lang=zh-CN",
  "method": "GET",
  "result_path": {
    "country": "country",
    "region": "regionName",
    "city": "city"
  },
  "success_field": "status",
  "success_value": "success"
}
```

**特点：**
- ✅ 免费使用
- ✅ 支持中文
- ✅ 每分钟 45 次请求限制
- ✅ 无需 API Key

**返回示例：**
```json
{
  "status": "success",
  "country": "中国",
  "regionName": "广东省",
  "city": "深圳市"
}
```

---

#### 2. ipinfo.io（需要注册）

```json
"ipinfo": {
  "url": "https://ipinfo.io/{ip}/json",
  "method": "GET",
  "result_path": {
    "country": "country",
    "region": "region",
    "city": "city"
  }
}
```

**特点：**
- ✅ 数据准确
- ⚠️ 免费版每月 50,000 次请求
- ⚠️ 需要注册获取 token（可选）

**带 Token 的 URL：**
```json
"url": "https://ipinfo.io/{ip}/json?token=你的token"
```

---

#### 3. 淘宝 IP 库（国内）

```json
"taobao": {
  "url": "https://ip.taobao.com/outGetIpInfo?ip={ip}&accessKey=alibaba-inc",
  "method": "GET",
  "result_path": {
    "country": "data.country",
    "region": "data.region",
    "city": "data.city"
  },
  "success_field": "code",
  "success_value": 0
}
```

**特点：**
- ✅ 国内 IP 准确度高
- ⚠️ 需要申请 accessKey
- ⚠️ 有请求频率限制

---

### 切换提供商

只需修改 `provider` 字段：

```json
{
  "ip_api": {
    "enabled": true,
    "provider": "ipinfo",    // 改成你想用的提供商
    "providers": { ... }
  }
}
```

---

### 添加自定义提供商

你可以添加任何支持 HTTP 请求的 IP 查询 API：

```json
"providers": {
  "my-custom-api": {
    "url": "https://api.example.com/ip/{ip}",
    "method": "GET",
    "result_path": {
      "country": "location.country",
      "region": "location.state",
      "city": "location.city"
    },
    "success_field": "success",
    "success_value": true
  }
}
```

**配置说明：**

| 字段 | 说明 | 示例 |
|------|------|------|
| `url` | API 地址，`{ip}` 会被替换为实际 IP | `https://api.example.com/ip/{ip}` |
| `method` | 请求方法 | `GET` 或 `POST` |
| `result_path` | 结果字段路径，支持嵌套（用 `.` 分隔） | `data.city` |
| `success_field` | 成功标识字段（可选） | `status` |
| `success_value` | 成功标识值（可选） | `success` 或 `0` |

---

## 🚫 IP 黑名单配置

### 功能说明

可以禁止指定的 IP 地址访问代理转发功能，支持三种方式：
1. **单个 IP** - 精确匹配
2. **IP 范围** - 起始 IP 到结束 IP
3. **CIDR 格式** - 网络地址块

### 完整配置

```json
{
  "ip_blacklist": {
    "enabled": false,                        // 是否启用黑名单
    "block_message": "您的IP已被禁止访问",    // 封禁提示信息
    "ips": [                                 // 单个 IP 列表
      "192.168.1.100",
      "10.0.0.50"
    ],
    "ip_ranges": [                           // IP 范围列表
      {
        "start": "192.168.2.1",
        "end": "192.168.2.255"
      },
      {
        "start": "10.10.0.0",
        "end": "10.10.255.255"
      }
    ],
    "cidrs": [                               // CIDR 格式列表
      "172.16.0.0/16",
      "192.168.100.0/24"
    ]
  }
}
```

---

### 使用方法

#### 1. 启用黑名单

```json
{
  "ip_blacklist": {
    "enabled": true    // 改为 true
  }
}
```

#### 2. 添加单个 IP

```json
{
  "ips": [
    "192.168.1.100",
    "203.0.113.50",
    "198.51.100.25"
  ]
}
```

#### 3. 添加 IP 范围

```json
{
  "ip_ranges": [
    {
      "start": "192.168.1.1",
      "end": "192.168.1.255"      // 封禁整个 192.168.1.x 段
    },
    {
      "start": "10.0.0.1",
      "end": "10.0.0.100"         // 封禁 10.0.0.1 到 10.0.0.100
    }
  ]
}
```

#### 4. 添加 CIDR 格式

```json
{
  "cidrs": [
    "192.168.0.0/16",    // 封禁整个 192.168.x.x 段
    "10.0.0.0/8",        // 封禁整个 10.x.x.x 段
    "172.16.0.0/12"      // 封禁 172.16.x.x 到 172.31.x.x
  ]
}
```

---

### CIDR 格式说明

CIDR（无类别域间路由）是一种 IP 地址表示方法：

| CIDR | IP 范围 | 说明 |
|------|---------|------|
| `192.168.1.0/24` | `192.168.1.0` - `192.168.1.255` | 256 个 IP |
| `192.168.0.0/16` | `192.168.0.0` - `192.168.255.255` | 65,536 个 IP |
| `10.0.0.0/8` | `10.0.0.0` - `10.255.255.255` | 16,777,216 个 IP |
| `172.16.0.0/12` | `172.16.0.0` - `172.31.255.255` | 1,048,576 个 IP |

**在线 CIDR 计算器：** https://www.ipaddressguide.com/cidr

---

### 封禁效果

当被封禁的 IP 访问代理路径时，会返回：

```json
{
  "error": "Access Denied",
  "message": "您的IP已被禁止访问",
  "ip": "192.168.1.100"
}
```

HTTP 状态码：`403 Forbidden`

---

## 📦 完整配置示例

```json
{
  "server": {
    "host": "0.0.0.0",
    "port": 9520
  },
  "routes": {
    "html_pages": {
      "/about": "pages/about.html"
    },
    "proxy_routes": [
      {
        "path": "/apiaaae",
        "upstream": "https://xiaoqian.com",
        "record_access": true
      }
    ]
  },
  "query_path": "/query-chaxun-qianye-steins-gate",
  
  "ip_api": {
    "enabled": true,
    "provider": "ip-api",
    "providers": {
      "ip-api": {
        "url": "http://ip-api.com/json/{ip}?lang=zh-CN",
        "method": "GET",
        "result_path": {
          "country": "country",
          "region": "regionName",
          "city": "city"
        },
        "success_field": "status",
        "success_value": "success"
      },
      "ipinfo": {
        "url": "https://ipinfo.io/{ip}/json",
        "method": "GET",
        "result_path": {
          "country": "country",
          "region": "region",
          "city": "city"
        }
      }
    }
  },
  
  "ip_blacklist": {
    "enabled": true,
    "block_message": "您的IP已被禁止访问",
    "ips": [
      "192.168.1.100"
    ],
    "ip_ranges": [
      {
        "start": "10.0.0.1",
        "end": "10.0.0.255"
      }
    ],
    "cidrs": [
      "172.16.0.0/16"
    ]
  }
}
```

---

## ❓ 常见问题

### Q1: IP 归属地显示"查询失败"？

**可能原因：**
1. API 请求超时（网络问题）
2. API 达到请求限制
3. API 返回格式不匹配

**解决方法：**
1. 检查网络连接
2. 切换到其他提供商
3. 查看终端错误信息

---

### Q2: 如何测试 IP 黑名单？

**方法 1：使用 curl 模拟**
```bash
curl -H "X-Real-IP: 192.168.1.100" http://localhost:9520/apiaaae/test123
```

**方法 2：临时添加自己的 IP**
1. 访问 http://localhost:9520/apiaaae/test 查看自己的 IP
2. 将自己的 IP 添加到黑名单
3. 刷新页面，应该看到封禁提示
4. 测试完成后删除

---

### Q3: 黑名单会影响 HTML 页面访问吗？

**不会。** 黑名单只对代理转发功能生效，不影响：
- 首页访问
- HTML 页面访问
- 查询记录访问

---

### Q4: 如何封禁所有内网 IP？

```json
{
  "cidrs": [
    "10.0.0.0/8",
    "172.16.0.0/12",
    "192.168.0.0/16"
  ]
}
```

---

### Q5: 可以同时使用多个 IP 查询提供商吗？

**不可以。** 系统同时只能使用一个提供商，但你可以：
1. 配置多个提供商
2. 通过修改 `provider` 字段快速切换

---

### Q6: IP 归属地查询会影响性能吗？

**影响很小。** 
- 查询是异步的，不会阻塞请求转发
- 超时时间设置为 5 秒
- 查询失败不会影响正常功能

---

### Q7: 如何查看被封禁的访问记录？

被封禁的 IP 访问会被拒绝，**不会记录到数据库**。

如果需要记录，可以修改代码在封禁检查前记录日志。

---

### Q8: 黑名单支持域名吗？

**不支持。** 只支持 IP 地址。

如果需要封禁域名，需要先解析域名获取 IP，然后添加到黑名单。

---

## 🚀 快速测试

### 测试 IP 归属地查询

```bash
# 启动服务器
python app.py

# 访问代理路径
curl http://localhost:9520/apiaaae/test123

# 查询记录（查看 IP 归属地）
curl http://localhost:9520/query-chaxun-qianye-steins-gate/test123
```

### 测试 IP 黑名单

```bash
# 1. 启用黑名单
# 编辑 config.json，设置 "enabled": true

# 2. 添加测试 IP
# 在 "ips" 中添加 "127.0.0.1"

# 3. 重启服务器
python app.py

# 4. 测试访问
curl http://localhost:9520/apiaaae/test123
# 应该返回 403 错误
```

---

## 💡 最佳实践

1. **生产环境建议：**
   - 启用 IP 归属地查询
   - 根据需要启用黑名单
   - 使用付费 API 获得更好的准确度和稳定性

2. **性能优化：**
   - 如果不需要 IP 归属地，可以禁用查询
   - 黑名单检查非常快，可以放心使用

3. **安全建议：**
   - 定期检查访问日志
   - 及时更新黑名单
   - 使用 CIDR 格式封禁整个恶意 IP 段

---

**最后更新：** 2024-01-15

