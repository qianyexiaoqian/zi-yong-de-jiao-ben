#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""测试admin.py的路由是否正确"""

import os
import sys

# 检查文件是否存在
print("=" * 60)
print("检查文件系统")
print("=" * 60)
print(f"当前工作目录: {os.getcwd()}")
print(f"pages目录存在: {os.path.exists('pages')}")
print(f"admin.html存在: {os.path.exists('pages/admin.html')}")
print(f"admin.html绝对路径: {os.path.abspath('pages/admin.html')}")
print()

# 导入admin模块
print("=" * 60)
print("导入admin模块")
print("=" * 60)
try:
    from admin import app
    print("✓ admin模块导入成功")
except Exception as e:
    print(f"✗ admin模块导入失败: {e}")
    sys.exit(1)

print()

# 检查路由
print("=" * 60)
print("检查Flask路由")
print("=" * 60)
for rule in app.url_map.iter_rules():
    print(f"  {rule.rule:40s} {list(rule.methods)}")

print()

# 测试主页路由
print("=" * 60)
print("测试主页路由")
print("=" * 60)
with app.test_client() as client:
    response = client.get('/')
    print(f"状态码: {response.status_code}")
    print(f"Content-Type: {response.content_type}")
    print(f"响应长度: {len(response.data)} bytes")
    
    if response.status_code == 200:
        print("✓ 主页路由正常工作")
        # 检查是否是HTML
        if b'<!DOCTYPE html>' in response.data or b'<html' in response.data:
            print("✓ 返回的是HTML内容")
        else:
            print("✗ 返回的不是HTML内容")
            print(f"前100个字符: {response.data[:100]}")
    else:
        print(f"✗ 主页路由返回错误: {response.status_code}")
        print(f"响应内容: {response.data.decode('utf-8')}")

print()
print("=" * 60)
print("测试完成")
print("=" * 60)

