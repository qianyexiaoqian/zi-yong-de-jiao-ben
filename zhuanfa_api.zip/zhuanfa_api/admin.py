from flask import Flask, request, jsonify, send_file, session, redirect, url_for
from flask_cors import CORS
from functools import wraps
import sqlite3
from datetime import datetime, timedelta
import os
import yaml
import logging
from logging.handlers import TimedRotatingFileHandler
import hashlib
import re
from collections import defaultdict

app = Flask(__name__)
CORS(app)

# 加载配置文件
def load_config():
    config_file = "admin_config.yaml"
    if not os.path.exists(config_file):
        raise FileNotFoundError(f"管理后台配置文件不存在: {config_file}")
    
    with open(config_file, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def load_main_config():
    """加载主服务器配置文件"""
    config_file = admin_config.get("main_config", {}).get("path", "config.yaml")
    if not os.path.exists(config_file):
        raise FileNotFoundError(f"主配置文件不存在: {config_file}")
    
    with open(config_file, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def save_main_config(config_data):
    """保存主服务器配置文件"""
    config_file = admin_config.get("main_config", {}).get("path", "config.yaml")
    with open(config_file, "w", encoding="utf-8") as f:
        # 使用 safe_dump 确保与 app.py 的 safe_load 兼容
        yaml.safe_dump(config_data, f, allow_unicode=True, default_flow_style=False, sort_keys=False)

def save_admin_config(config_data):
    """保存管理后台配置文件"""
    config_file = "admin_config.yaml"
    with open(config_file, "w", encoding="utf-8") as f:
        # 使用 safe_dump 确保 YAML 格式标准化
        yaml.safe_dump(config_data, f, allow_unicode=True, default_flow_style=False, sort_keys=False)

admin_config = load_config()

# 设置会话密钥
app.secret_key = admin_config.get("admin", {}).get("session_secret", "default-secret-key")

# ==================== 日志配置 ====================
def setup_logging():
    """配置日志系统（按日期分文件）"""
    log_config = admin_config.get("logging", {})

    if not log_config.get("enabled", True):
        return

    log_dir = log_config.get("log_dir", "logs")
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    log_file = os.path.join(log_dir, "admin.log")
    level_str = log_config.get("level", "INFO").upper()
    level = getattr(logging, level_str, logging.INFO)

    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")

    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    root_logger.handlers.clear()

    # 按日期轮转的文件处理器
    retention_days = log_config.get("retention_days", 30)
    file_handler = TimedRotatingFileHandler(
        log_file,
        when='midnight',  # 每天午夜轮转
        interval=1,  # 每1天
        backupCount=retention_days,  # 保留天数
        encoding='utf-8'
    )
    # 设置日志文件命名格式：admin.2026-01-30.log
    file_handler.suffix = "%Y-%m-%d.log"
    # 自定义文件命名函数
    def custom_namer(default_name):
        # default_name 格式: logs/admin.log.2026-01-30.log
        # 需要转换为: logs/admin.2026-01-30.log
        base_name = default_name.replace('.log.', '.')
        return base_name
    file_handler.namer = custom_namer
    file_handler.setLevel(level)
    file_handler.setFormatter(formatter)
    root_logger.addHandler(file_handler)

    console_handler = logging.StreamHandler()
    console_handler.setLevel(level)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)

    logging.info("管理后台日志系统初始化完成（按日期分文件存储）")

setup_logging()
logging.info("=" * 60)
logging.info("管理后台启动")
logging.info(f"监听地址: {admin_config['server']['host']}:{admin_config['server']['port']}")
logging.info("=" * 60)

# ==================== 登录失败记录 ====================
login_attempts = defaultdict(lambda: {"count": 0, "lockout_until": None})

# ==================== 认证装饰器 ====================
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get("logged_in"):
            return jsonify({"success": False, "message": "未登录"}), 401
        return f(*args, **kwargs)
    return decorated_function

# ==================== 辅助函数 ====================
def get_db_connection():
    """获取数据库连接"""
    db_path = admin_config.get("database", {}).get("path", "access_logs.db")
    return sqlite3.connect(db_path)

def hash_password(password):
    """密码哈希"""
    return hashlib.sha256(password.encode()).hexdigest()

# ==================== 页面路由 ====================

# 主页
@app.route("/")
def index():
    """返回管理后台主页"""
    try:
        admin_html_path = os.path.join("pages", "admin.html")
        admin_html_path = os.path.abspath(admin_html_path)  # 转换为绝对路径

        if not os.path.exists(admin_html_path):
            logging.error(f"管理后台页面不存在: {admin_html_path}")
            return f"管理后台页面不存在: {admin_html_path}", 404

        logging.info(f"返回管理后台页面: {admin_html_path}")
        return send_file(admin_html_path, mimetype='text/html')
    except Exception as e:
        logging.error(f"返回管理后台页面失败: {e}")
        return f"返回管理后台页面失败: {str(e)}", 500

# ==================== API路由 ====================

# 登录
@app.route("/api/login", methods=["POST"])
def login():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")
    
    client_ip = request.remote_addr
    
    # 检查是否被锁定
    if login_attempts[client_ip]["lockout_until"]:
        if datetime.now() < login_attempts[client_ip]["lockout_until"]:
            remaining = (login_attempts[client_ip]["lockout_until"] - datetime.now()).seconds
            return jsonify({
                "success": False,
                "message": f"登录已锁定，请在 {remaining} 秒后重试"
            }), 429
        else:
            # 锁定时间已过，重置
            login_attempts[client_ip] = {"count": 0, "lockout_until": None}

    # 验证用户名和密码
    admin_username = admin_config.get("admin", {}).get("username", "admin")
    admin_password = admin_config.get("admin", {}).get("password", "qianye114514")

    if username == admin_username and password == admin_password:
        # 登录成功
        session["logged_in"] = True
        session["username"] = username
        session.permanent = True
        app.permanent_session_lifetime = timedelta(
            seconds=admin_config.get("admin", {}).get("session_timeout", 3600)
        )

        # 重置登录失败计数
        login_attempts[client_ip] = {"count": 0, "lockout_until": None}

        logging.info(f"管理员登录成功 - IP: {client_ip}")
        return jsonify({"success": True, "message": "登录成功"})
    else:
        # 登录失败
        login_attempts[client_ip]["count"] += 1
        max_attempts = admin_config.get("security", {}).get("max_login_attempts", 5)

        if login_attempts[client_ip]["count"] >= max_attempts:
            # 锁定账户
            lockout_duration = admin_config.get("security", {}).get("lockout_duration", 300)
            login_attempts[client_ip]["lockout_until"] = datetime.now() + timedelta(seconds=lockout_duration)
            logging.warning(f"登录失败次数过多，账户已锁定 - IP: {client_ip}")
            return jsonify({
                "success": False,
                "message": f"登录失败次数过多，账户已锁定 {lockout_duration} 秒"
            }), 429

        remaining_attempts = max_attempts - login_attempts[client_ip]["count"]
        logging.warning(f"登录失败 - IP: {client_ip}, 剩余尝试次数: {remaining_attempts}")
        return jsonify({
            "success": False,
            "message": f"用户名或密码错误，剩余尝试次数: {remaining_attempts}"
        }), 401

# 登出
@app.route("/api/logout", methods=["POST"])
@login_required
def logout():
    username = session.get("username")
    session.clear()
    logging.info(f"管理员登出 - 用户: {username}")
    return jsonify({"success": True, "message": "登出成功"})

# 检查登录状态
@app.route("/api/check-auth", methods=["GET"])
def check_auth():
    if session.get("logged_in"):
        return jsonify({"success": True, "logged_in": True, "username": session.get("username")})
    return jsonify({"success": True, "logged_in": False})

# 获取统计数据
@app.route("/api/statistics", methods=["GET"])
@login_required
def get_statistics():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        today = datetime.now().strftime("%Y-%m-%d")

        # ========== 今日统计 ==========
        # 今日总访问量（所有类型）
        cursor.execute("""
            SELECT COUNT(*) FROM access_logs
            WHERE DATE(access_time) = ?
        """, (today,))
        today_visits = cursor.fetchone()[0]

        # 今日代理数量
        cursor.execute("""
            SELECT COUNT(*) FROM access_logs
            WHERE DATE(access_time) = ? AND access_type = 'proxy'
        """, (today,))
        today_proxy_count = cursor.fetchone()[0]

        # 今日页面访问量
        cursor.execute("""
            SELECT COUNT(*) FROM access_logs
            WHERE DATE(access_time) = ? AND access_type = 'page'
        """, (today,))
        today_page_views = cursor.fetchone()[0]

        # 今日文件下载量
        cursor.execute("""
            SELECT COUNT(*) FROM access_logs
            WHERE DATE(access_time) = ? AND access_type = 'download'
        """, (today,))
        today_download_count = cursor.fetchone()[0]

        # 今日404错误数量
        cursor.execute("""
            SELECT COUNT(*) FROM access_logs
            WHERE DATE(access_time) = ? AND access_type = '404'
        """, (today,))
        today_404_count = cursor.fetchone()[0]

        # 今日黑名单拦截数量
        cursor.execute("""
            SELECT COUNT(*) FROM access_logs
            WHERE DATE(access_time) = ? AND access_type = 'blacklist'
        """, (today,))
        today_blacklist_count = cursor.fetchone()[0]

        # ========== 历史总量统计 ==========
        # 总访问量（所有类型）
        cursor.execute("SELECT COUNT(*) FROM access_logs")
        total_visits = cursor.fetchone()[0]

        # 总代理数量
        cursor.execute("""
            SELECT COUNT(*) FROM access_logs
            WHERE access_type = 'proxy'
        """)
        total_proxy_count = cursor.fetchone()[0]

        # 总页面访问量
        cursor.execute("""
            SELECT COUNT(*) FROM access_logs
            WHERE access_type = 'page'
        """)
        total_page_views = cursor.fetchone()[0]

        # 总文件下载量
        cursor.execute("""
            SELECT COUNT(*) FROM access_logs
            WHERE access_type = 'download'
        """)
        total_download_count = cursor.fetchone()[0]

        # 总404错误数量
        cursor.execute("""
            SELECT COUNT(*) FROM access_logs
            WHERE access_type = '404'
        """)
        total_404_count = cursor.fetchone()[0]

        # 总黑名单拦截数量
        cursor.execute("""
            SELECT COUNT(*) FROM access_logs
            WHERE access_type = 'blacklist'
        """)
        total_blacklist_count = cursor.fetchone()[0]

        conn.close()

        stats = {
            # 今日统计
            "today_visits": today_visits,
            "today_proxy_count": today_proxy_count,
            "today_page_views": today_page_views,
            "today_download_count": today_download_count,
            "today_404_count": today_404_count,
            "today_blacklist_count": today_blacklist_count,

            # 历史总量统计
            "total_visits": total_visits,
            "total_proxy_count": total_proxy_count,
            "total_page_views": total_page_views,
            "total_download_count": total_download_count,
            "total_404_count": total_404_count,
            "total_blacklist_count": total_blacklist_count
        }

        return jsonify({"success": True, "data": stats})
    except Exception as e:
        logging.error(f"获取统计数据失败: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

# 查询所有访问记录
@app.route("/api/records", methods=["GET"])
@login_required
def get_all_records():
    try:
        page = int(request.args.get("page", 1))
        page_size = int(request.args.get("page_size", 50))
        offset = (page - 1) * page_size

        conn = get_db_connection()
        cursor = conn.cursor()

        # 获取总数
        cursor.execute("SELECT COUNT(*) FROM access_logs")
        total = cursor.fetchone()[0]

        # 获取分页数据
        cursor.execute("""
            SELECT id, uuid, ip, ip_location, access_time, full_path, proxy_path, upstream_url, user_agent
            FROM access_logs
            ORDER BY access_time DESC
            LIMIT ? OFFSET ?
        """, (page_size, offset))

        results = cursor.fetchall()
        conn.close()

        records = []
        for row in results:
            records.append({
                "id": row[0],
                "uuid": row[1],
                "ip": row[2],
                "ip_location": row[3],
                "access_time": row[4],
                "full_path": row[5],
                "proxy_path": row[6],
                "upstream_url": row[7],
                "user_agent": row[8]
            })

        return jsonify({
            "success": True,
            "data": records,
            "total": total,
            "page": page,
            "page_size": page_size,
            "total_pages": (total + page_size - 1) // page_size
        })
    except Exception as e:
        logging.error(f"查询访问记录失败: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

# 查询单条访问记录（通过ID）
@app.route("/api/records/id/<int:record_id>", methods=["GET"])
@login_required
def get_record_by_id(record_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT id, uuid, ip, ip_location, access_time, full_path, proxy_path, upstream_url, user_agent
            FROM access_logs
            WHERE id = ?
        """, (record_id,))

        row = cursor.fetchone()
        conn.close()

        if not row:
            return jsonify({"success": False, "message": "未找到该记录"}), 404

        record = {
            "id": row[0],
            "uuid": row[1],
            "ip": row[2],
            "ip_location": row[3],
            "access_time": row[4],
            "full_path": row[5],
            "proxy_path": row[6],
            "upstream_url": row[7],
            "user_agent": row[8]
        }

        return jsonify({"success": True, "data": record})
    except Exception as e:
        logging.error(f"查询单条记录失败: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

# 查询指定UUID的访问记录
@app.route("/api/records/uuid/<uuid_str>", methods=["GET"])
@login_required
def get_records_by_uuid(uuid_str):
    try:
        page = int(request.args.get("page", 1))
        page_size = int(request.args.get("page_size", 50))
        offset = (page - 1) * page_size

        conn = get_db_connection()
        cursor = conn.cursor()

        # 获取总数
        cursor.execute("""
            SELECT COUNT(*) FROM access_logs
            WHERE uuid = ?
        """, (uuid_str,))
        total = cursor.fetchone()[0]

        if total == 0:
            conn.close()
            return jsonify({"success": False, "message": "未找到该UUID的访问记录"}), 404

        # 获取分页数据
        cursor.execute("""
            SELECT id, uuid, ip, ip_location, access_time, full_path, proxy_path, upstream_url, user_agent
            FROM access_logs
            WHERE uuid = ?
            ORDER BY access_time DESC
            LIMIT ? OFFSET ?
        """, (uuid_str, page_size, offset))

        results = cursor.fetchall()
        conn.close()

        records = []
        for row in results:
            records.append({
                "id": row[0],
                "uuid": row[1],
                "ip": row[2],
                "ip_location": row[3],
                "access_time": row[4],
                "full_path": row[5],
                "proxy_path": row[6],
                "upstream_url": row[7],
                "user_agent": row[8]
            })

        return jsonify({
            "success": True,
            "data": records,
            "total": total,
            "page": page,
            "page_size": page_size,
            "total_pages": (total + page_size - 1) // page_size
        })
    except Exception as e:
        logging.error(f"查询UUID访问记录失败: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

# 删除访问记录
@app.route("/api/records/<int:record_id>", methods=["DELETE"])
@login_required
def delete_record(record_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute("DELETE FROM access_logs WHERE id = ?", (record_id,))
        conn.commit()

        if cursor.rowcount == 0:
            conn.close()
            return jsonify({"success": False, "message": "记录不存在"}), 404

        conn.close()
        logging.info(f"删除访问记录 - ID: {record_id}, 操作者: {session.get('username')}")
        return jsonify({"success": True, "message": "删除成功"})
    except Exception as e:
        logging.error(f"删除访问记录失败: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

# 修改访问记录
@app.route("/api/records/<int:record_id>", methods=["PUT"])
@login_required
def update_record(record_id):
    try:
        data = request.get_json()

        conn = get_db_connection()
        cursor = conn.cursor()

        # 构建更新语句
        update_fields = []
        update_values = []

        allowed_fields = ["uuid", "ip", "ip_location", "full_path", "proxy_path", "upstream_url", "user_agent"]
        for field in allowed_fields:
            if field in data:
                update_fields.append(f"{field} = ?")
                update_values.append(data[field])

        if not update_fields:
            return jsonify({"success": False, "message": "没有要更新的字段"}), 400

        update_values.append(record_id)
        sql = f"UPDATE access_logs SET {', '.join(update_fields)} WHERE id = ?"

        cursor.execute(sql, update_values)
        conn.commit()

        if cursor.rowcount == 0:
            conn.close()
            return jsonify({"success": False, "message": "记录不存在"}), 404

        conn.close()
        logging.info(f"修改访问记录 - ID: {record_id}, 操作者: {session.get('username')}")
        return jsonify({"success": True, "message": "修改成功"})
    except Exception as e:
        logging.error(f"修改访问记录失败: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

# 获取主配置
@app.route("/api/config", methods=["GET"])
@login_required
def get_config():
    try:
        config = load_main_config()
        return jsonify({"success": True, "data": config})
    except Exception as e:
        logging.error(f"获取配置失败: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

# 更新主配置
@app.route("/api/config", methods=["PUT"])
@login_required
def update_config():
    try:
        data = request.get_json()
        save_main_config(data)
        logging.info(f"更新配置成功 - 操作者: {session.get('username')}")
        return jsonify({"success": True, "message": "配置已更新，主服务器将在5秒内自动应用更改"})
    except Exception as e:
        logging.error(f"更新配置失败: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

# 获取管理端配置
@app.route("/api/admin-config", methods=["GET"])
@login_required
def get_admin_config():
    try:
        config = load_config()
        return jsonify({"success": True, "data": config})
    except Exception as e:
        logging.error(f"获取管理端配置失败: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

# 更新管理端配置
@app.route("/api/admin-config", methods=["PUT"])
@login_required
def update_admin_config():
    try:
        data = request.get_json()
        save_admin_config(data)

        # 重新加载全局配置
        global admin_config
        admin_config = load_config()

        logging.info(f"更新管理端配置成功 - 操作者: {session.get('username')}")
        return jsonify({"success": True, "message": "管理端配置已更新，请重启管理后台以应用更改"})
    except Exception as e:
        logging.error(f"更新管理端配置失败: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

# 添加代理路由
@app.route("/api/config/proxy-routes", methods=["POST"])
@login_required
def add_proxy_route():
    try:
        data = request.get_json()

        if not data.get("path") or not data.get("upstream"):
            return jsonify({"success": False, "message": "路径和上游地址不能为空"}), 400

        config = load_main_config()

        if "routes" not in config:
            config["routes"] = {}
        if "proxy_routes" not in config["routes"]:
            config["routes"]["proxy_routes"] = []

        new_route = {
            "path": data["path"],
            "upstream": data["upstream"],
            "record_access": data.get("record_access", True)
        }

        config["routes"]["proxy_routes"].append(new_route)
        save_main_config(config)

        logging.info(f"添加代理路由 - 路径: {data['path']}, 操作者: {session.get('username')}")
        return jsonify({"success": True, "message": "代理路由已添加，请重启主服务器以应用更改"})
    except Exception as e:
        logging.error(f"添加代理路由失败: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

# 删除代理路由
@app.route("/api/config/proxy-routes/<int:index>", methods=["DELETE"])
@login_required
def delete_proxy_route(index):
    try:
        config = load_main_config()

        if "routes" not in config or "proxy_routes" not in config["routes"]:
            return jsonify({"success": False, "message": "没有代理路由配置"}), 404

        if index < 0 or index >= len(config["routes"]["proxy_routes"]):
            return jsonify({"success": False, "message": "索引超出范围"}), 404

        deleted_route = config["routes"]["proxy_routes"].pop(index)
        save_main_config(config)

        logging.info(f"删除代理路由 - 路径: {deleted_route['path']}, 操作者: {session.get('username')}")
        return jsonify({"success": True, "message": "代理路由已删除，请重启主服务器以应用更改"})
    except Exception as e:
        logging.error(f"删除代理路由失败: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

# 更新代理路由
@app.route("/api/config/proxy-routes/<int:index>", methods=["PUT"])
@login_required
def update_proxy_route(index):
    try:
        data = request.get_json()
        config = load_main_config()

        if "routes" not in config or "proxy_routes" not in config["routes"]:
            return jsonify({"success": False, "message": "没有代理路由配置"}), 404

        if index < 0 or index >= len(config["routes"]["proxy_routes"]):
            return jsonify({"success": False, "message": "索引超出范围"}), 404

        if "path" in data:
            config["routes"]["proxy_routes"][index]["path"] = data["path"]
        if "upstream" in data:
            config["routes"]["proxy_routes"][index]["upstream"] = data["upstream"]
        if "record_access" in data:
            config["routes"]["proxy_routes"][index]["record_access"] = data["record_access"]

        save_main_config(config)

        logging.info(f"更新代理路由 - 索引: {index}, 操作者: {session.get('username')}")
        return jsonify({"success": True, "message": "代理路由已更新，请重启主服务器以应用更改"})
    except Exception as e:
        logging.error(f"更新代理路由失败: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

# 添加HTML页面/文件路由
@app.route("/api/config/html-pages", methods=["POST"])
@login_required
def add_html_page():
    try:
        data = request.get_json()

        if not data.get("path") or not data.get("file"):
            return jsonify({"success": False, "message": "路径和文件不能为空"}), 400

        config = load_main_config()

        if "routes" not in config:
            config["routes"] = {}
        if "html_pages" not in config["routes"]:
            config["routes"]["html_pages"] = {}

        # 新格式：存储为字典，包含file和type
        page_config = {
            "file": data["file"],
            "type": data.get("type", "display")  # 默认为display
        }

        config["routes"]["html_pages"][data["path"]] = page_config
        save_main_config(config)

        logging.info(f"添加页面路由 - 路径: {data['path']}, 类型: {page_config['type']}, 操作者: {session.get('username')}")
        return jsonify({"success": True, "message": "页面路由已添加，主服务器将在5秒内自动应用更改"})
    except Exception as e:
        logging.error(f"添加页面路由失败: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

# 删除HTML页面/文件路由
@app.route("/api/config/html-pages", methods=["DELETE"])
@login_required
def delete_html_page():
    try:
        data = request.get_json()
        path = data.get("path")

        if not path:
            return jsonify({"success": False, "message": "路径不能为空"}), 400

        config = load_main_config()

        if "routes" not in config or "html_pages" not in config["routes"]:
            return jsonify({"success": False, "message": "没有页面配置"}), 404

        if path not in config["routes"]["html_pages"]:
            return jsonify({"success": False, "message": "页面不存在"}), 404

        del config["routes"]["html_pages"][path]
        save_main_config(config)

        logging.info(f"删除页面路由 - 路径: {path}, 操作者: {session.get('username')}")
        return jsonify({"success": True, "message": "页面路由已删除，主服务器将在5秒内自动应用更改"})
    except Exception as e:
        logging.error(f"删除HTML页面失败: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

# 获取指定目录下的所有文件
@app.route("/api/pages-files", methods=["GET"])
@login_required
def get_pages_files():
    try:
        # 根据type参数决定从哪个目录加载文件
        file_type = request.args.get("type", "display")

        if file_type == "download":
            target_dir = "files"  # 下载文件目录
        else:
            target_dir = "pages"  # HTML页面目录

        if not os.path.exists(target_dir):
            # 如果目录不存在，创建它
            os.makedirs(target_dir, exist_ok=True)
            return jsonify({"success": True, "data": []})

        files = []
        for filename in os.listdir(target_dir):
            file_path = os.path.join(target_dir, filename)
            if os.path.isfile(file_path):
                # 获取文件扩展名
                _, ext = os.path.splitext(filename)
                files.append({
                    "name": filename,
                    "path": file_path,
                    "size": os.path.getsize(file_path),
                    "ext": ext.lower()
                })

        return jsonify({"success": True, "data": files})
    except Exception as e:
        logging.error(f"获取文件列表失败: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

# 获取IP黑名单
@app.route("/api/blacklist", methods=["GET"])
@login_required
def get_blacklist():
    try:
        cfg = load_main_config()  # 修改：读取转发端配置
        blacklist_config = cfg.get("ip_blacklist", {})

        blacklist_data = {
            "enabled": blacklist_config.get("enabled", False),
            "block_message": blacklist_config.get("block_message", "您的IP已被禁止访问"),
            "ips": blacklist_config.get("ips", []),
            "ip_ranges": blacklist_config.get("ip_ranges", []),
            "cidrs": blacklist_config.get("cidrs", [])
        }

        return jsonify({"success": True, "data": blacklist_data})
    except Exception as e:
        logging.error(f"获取黑名单失败: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

# 添加IP到黑名单
@app.route("/api/blacklist/add-ip", methods=["POST"])
@login_required
def add_ip_to_blacklist():
    try:
        data = request.json
        ip = data.get("ip", "").strip()

        if not ip:
            return jsonify({"success": False, "message": "IP不能为空"}), 400

        cfg = load_main_config()  # 修改：读取转发端配置
        blacklist_config = cfg.get("ip_blacklist", {})

        if "ips" not in blacklist_config:
            blacklist_config["ips"] = []

        if ip in blacklist_config["ips"]:
            return jsonify({"success": False, "message": "该IP已存在"}), 400

        blacklist_config["ips"].append(ip)
        cfg["ip_blacklist"] = blacklist_config

        # 保存配置
        save_main_config(cfg)  # 修改：使用统一的保存函数

        logging.info(f"添加IP到黑名单: {ip}")
        return jsonify({"success": True, "message": f"已添加IP: {ip}"})
    except Exception as e:
        logging.error(f"添加IP到黑名单失败: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

# 从黑名单删除IP
@app.route("/api/blacklist/remove-ip", methods=["POST"])
@login_required
def remove_ip_from_blacklist():
    try:
        data = request.json
        ip = data.get("ip", "").strip()

        if not ip:
            return jsonify({"success": False, "message": "IP不能为空"}), 400

        cfg = load_main_config()  # 修改：读取转发端配置
        blacklist_config = cfg.get("ip_blacklist", {})

        if "ips" not in blacklist_config or ip not in blacklist_config["ips"]:
            return jsonify({"success": False, "message": "该IP不存在"}), 400

        blacklist_config["ips"].remove(ip)
        cfg["ip_blacklist"] = blacklist_config

        # 保存配置
        save_main_config(cfg)  # 修改：使用统一的保存函数

        logging.info(f"从黑名单删除IP: {ip}")
        return jsonify({"success": True, "message": f"已删除IP: {ip}"})
    except Exception as e:
        logging.error(f"删除IP失败: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

# 添加IP段到黑名单
@app.route("/api/blacklist/add-range", methods=["POST"])
@login_required
def add_range_to_blacklist():
    try:
        data = request.json
        start_ip = data.get("start_ip", "").strip()
        end_ip = data.get("end_ip", "").strip()

        if not start_ip or not end_ip:
            return jsonify({"success": False, "message": "起始IP和结束IP不能为空"}), 400

        cfg = load_main_config()  # 修改：读取转发端配置
        blacklist_config = cfg.get("ip_blacklist", {})

        if "ip_ranges" not in blacklist_config:
            blacklist_config["ip_ranges"] = []

        new_range = {"start": start_ip, "end": end_ip}

        # 检查是否已存在
        for ip_range in blacklist_config["ip_ranges"]:
            if ip_range["start"] == start_ip and ip_range["end"] == end_ip:
                return jsonify({"success": False, "message": "该IP段已存在"}), 400

        blacklist_config["ip_ranges"].append(new_range)
        cfg["ip_blacklist"] = blacklist_config

        # 保存配置
        save_main_config(cfg)  # 修改：使用统一的保存函数

        logging.info(f"添加IP段到黑名单: {start_ip} - {end_ip}")
        return jsonify({"success": True, "message": f"已添加IP段: {start_ip} - {end_ip}"})
    except Exception as e:
        logging.error(f"添加IP段失败: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

# 从黑名单删除IP段
@app.route("/api/blacklist/remove-range", methods=["POST"])
@login_required
def remove_range_from_blacklist():
    try:
        data = request.json
        start_ip = data.get("start_ip", "").strip()
        end_ip = data.get("end_ip", "").strip()

        if not start_ip or not end_ip:
            return jsonify({"success": False, "message": "起始IP和结束IP不能为空"}), 400

        cfg = load_main_config()  # 修改：读取转发端配置
        blacklist_config = cfg.get("ip_blacklist", {})

        if "ip_ranges" not in blacklist_config:
            return jsonify({"success": False, "message": "该IP段不存在"}), 400

        # 查找并删除
        found = False
        for i, ip_range in enumerate(blacklist_config["ip_ranges"]):
            if ip_range["start"] == start_ip and ip_range["end"] == end_ip:
                blacklist_config["ip_ranges"].pop(i)
                found = True
                break

        if not found:
            return jsonify({"success": False, "message": "该IP段不存在"}), 400

        cfg["ip_blacklist"] = blacklist_config

        # 保存配置
        save_main_config(cfg)  # 修改：使用统一的保存函数

        logging.info(f"从黑名单删除IP段: {start_ip} - {end_ip}")
        return jsonify({"success": True, "message": f"已删除IP段: {start_ip} - {end_ip}"})
    except Exception as e:
        logging.error(f"删除IP段失败: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

# ==================== UUID拉取记录统计 ====================

# 获取今日UUID拉取排行
@app.route("/api/uuid-stats/today", methods=["GET"])
@login_required
def get_today_uuid_stats():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        today = datetime.now().strftime("%Y-%m-%d")

        # 查询今日每个UUID的拉取次数（只统计proxy类型）
        cursor.execute("""
            SELECT uuid, COUNT(*) as count
            FROM access_logs
            WHERE DATE(access_time) = ? AND access_type = 'proxy'
            GROUP BY uuid
            ORDER BY count DESC
        """, (today,))

        results = cursor.fetchall()
        conn.close()

        stats = []
        for row in results:
            stats.append({
                "uuid": row[0],
                "count": row[1]
            })

        return jsonify({
            "success": True,
            "date": today,
            "total_uuids": len(stats),
            "data": stats
        })
    except Exception as e:
        logging.error(f"获取今日UUID统计失败: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

# 获取总UUID拉取排行
@app.route("/api/uuid-stats/total", methods=["GET"])
@login_required
def get_total_uuid_stats():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # 查询所有UUID的总拉取次数（只统计proxy类型）
        cursor.execute("""
            SELECT uuid, COUNT(*) as count
            FROM access_logs
            WHERE access_type = 'proxy'
            GROUP BY uuid
            ORDER BY count DESC
        """)

        results = cursor.fetchall()
        conn.close()

        stats = []
        for row in results:
            stats.append({
                "uuid": row[0],
                "count": row[1]
            })

        return jsonify({
            "success": True,
            "total_uuids": len(stats),
            "data": stats
        })
    except Exception as e:
        logging.error(f"获取总UUID统计失败: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

if __name__ == "__main__":
    app.run(
        host=admin_config["server"]["host"],
        port=admin_config["server"]["port"],
        debug=admin_config["server"].get("debug", False)
    )


