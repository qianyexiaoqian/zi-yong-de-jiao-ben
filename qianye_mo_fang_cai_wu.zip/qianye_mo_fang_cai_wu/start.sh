#!/bin/bash
# ============================================
# 魔方财务平台聚合系统 - 一键部署脚本
# ============================================

# 不使用 set -e，菜单驱动脚本中函数 return 1 会导致整个脚本退出

# 全局变量 — start.sh 与 app.py 等文件同级，直接在项目根目录运行
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="$SCRIPT_DIR"
CONFIG_FILE="$APP_DIR/config.yaml"
PID_FILE="$APP_DIR/.mofang.pid"
LOG_FILE="$APP_DIR/mofang.log"
VENV_DIR="$APP_DIR/.venv"

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 输出函数
info() { echo -e "${BLUE}[INFO]${NC} $1"; }
success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; }

# 检测系统类型
detect_system() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS=$ID
        VER=$VERSION_ID
    else
        error "无法检测系统类型"
        exit 1
    fi
    info "检测到系统: $OS $VER"
}

# 检查命令是否存在
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# 安装 Python
install_python() {
    info "检查 Python 安装..."
    if command_exists python3; then
        PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
        success "Python 已安装: $PYTHON_VERSION"
        return 0
    fi

    warn "Python 未安装，开始安装..."
    detect_system
    
    case $OS in
        ubuntu|debian)
            sudo apt-get update
            sudo apt-get install -y python3 python3-pip python3-venv
            ;;
        centos|rhel|fedora)
            sudo yum install -y python3 python3-pip
            ;;
        *)
            error "不支持的系统: $OS"
            exit 1
            ;;
    esac
    
    if command_exists python3; then
        success "Python 安装成功"
    else
        error "Python 安装失败"
        exit 1
    fi
}

# 安装 uv
install_uv() {
    info "检查 uv 安装..."
    if command_exists uv; then
        UV_VERSION=$(uv --version 2>&1 | awk '{print $2}')
        success "uv 已安装: $UV_VERSION"
        return 0
    fi

    warn "uv 未安装，开始安装..."
    curl -LsSf https://astral.sh/uv/install.sh | sh
    
    # 添加到当前会话（新版 uv 安装到 ~/.local/bin，旧版在 ~/.cargo/bin）
    export PATH="$HOME/.local/bin:$HOME/.cargo/bin:$PATH"
    
    if command_exists uv; then
        success "uv 安装成功"
    else
        error "uv 安装失败，请手动安装: curl -LsSf https://astral.sh/uv/install.sh | sh"
        exit 1
    fi
}

# 安装依赖
install_deps() {
    info "安装项目依赖..."
    pushd "$APP_DIR" > /dev/null

    if [ ! -d "$VENV_DIR" ]; then
        info "创建虚拟环境..."
        uv venv "$VENV_DIR"
    fi

    info "安装依赖包..."
    # 显式指定虚拟环境，避免 uv 找不到目标 venv
    VIRTUAL_ENV="$VENV_DIR" uv pip install -r requirements.txt

    popd > /dev/null
    success "依赖安装完成"
}

# 获取配置值
get_config_value() {
    local key=$1
    if [ ! -f "$CONFIG_FILE" ]; then
        echo ""
        return
    fi
    grep "^  $key:" "$CONFIG_FILE" | sed 's/.*: *"\?\([^"]*\)"\?.*/\1/' | tr -d '"' | xargs
}

# 更新 YAML 配置
update_yaml_value() {
    local section=$1
    local key=$2
    local value=$3
    
    if [ ! -f "$CONFIG_FILE" ]; then
        error "配置文件不存在: $CONFIG_FILE"
        return 1
    fi
    
    # 使用 sed 更新配置
    sed -i "/^$section:/,/^[a-z]/ s/^  $key: .*$/  $key: \"$value\"/" "$CONFIG_FILE"
    success "配置已更新: $section.$key = $value"
}

# 检查进程状态
check_process() {
    if [ -f "$PID_FILE" ]; then
        PID=$(cat "$PID_FILE")
        if ps -p "$PID" > /dev/null 2>&1; then
            return 0
        fi
    fi
    return 1
}

# 启动服务
start_service() {
    info "启动魔方财务平台聚合系统..."

    if check_process; then
        warn "服务已在运行中 (PID: $(cat $PID_FILE))"
        return 0
    fi

    # 检查虚拟环境
    if [ ! -d "$VENV_DIR" ]; then
        error "虚拟环境不存在，请先执行安装 (选项 9)"
        return 1
    fi

    # 在 subshell 中 cd 并启动，不污染主 shell 工作目录
    (
        cd "$APP_DIR"
        nohup "$VENV_DIR/bin/python3" app.py > "$LOG_FILE" 2>&1 &
        echo $! > "$PID_FILE"
    )

    sleep 2

    if check_process; then
        success "服务启动成功 (PID: $(cat $PID_FILE))"
        info "日志文件: $LOG_FILE"
    else
        error "服务启动失败，请查看日志: $LOG_FILE"
        return 1
    fi
}

# 停止服务
stop_service() {
    info "停止魔方财务平台聚合系统..."

    if ! check_process; then
        warn "服务未运行"
        return 0
    fi

    PID=$(cat "$PID_FILE")
    kill "$PID" 2>/dev/null || true

    # 等待进程结束
    for i in {1..10}; do
        if ! ps -p "$PID" > /dev/null 2>&1; then
            rm -f "$PID_FILE"
            success "服务已停止"
            return 0
        fi
        sleep 1
    done

    # 强制结束
    warn "进程未响应，强制结束..."
    kill -9 "$PID" 2>/dev/null || true
    rm -f "$PID_FILE"
    success "服务已强制停止"
}

# 重启服务
restart_service() {
    info "重启魔方财务平台聚合系统..."
    stop_service
    sleep 1
    start_service
}

# 查看系统状态
show_status() {
    echo ""
    echo "=========================================="
    echo "  魔方财务平台聚合系统 - 状态信息"
    echo "=========================================="

    # 运行状态
    if check_process; then
        echo -e "运行状态: ${GREEN}运行中${NC} (PID: $(cat $PID_FILE))"
    else
        echo -e "运行状态: ${RED}已停止${NC}"
    fi

    # 读取配置
    HOST=$(get_config_value "host")
    PORT=$(get_config_value "port")
    ADMIN_PATH=$(get_config_value "path")
    ADMIN_USER=$(get_config_value "username")
    ADMIN_PASS=$(get_config_value "password")

    # 显示配置
    echo "监听地址: $HOST"
    echo "监听端口: $PORT"

    # 访问地址
    if [ "$HOST" = "0.0.0.0" ]; then
        DISPLAY_HOST="127.0.0.1"
    else
        DISPLAY_HOST="$HOST"
    fi

    echo "用户访问: http://$DISPLAY_HOST:$PORT/share/"
    echo "管理后台: http://$DISPLAY_HOST:$PORT$ADMIN_PATH/login"
    echo "管理账户: $ADMIN_USER"
    echo "管理密码: $ADMIN_PASS"
    echo "=========================================="
    echo ""
}

# 更改监听地址和端口
change_host_port() {
    echo ""
    echo "=========================================="
    echo "  更改系统监听地址和端口"
    echo "=========================================="

    # 当前配置
    CURRENT_HOST=$(get_config_value "host")
    CURRENT_PORT=$(get_config_value "port")
    echo "当前监听地址: $CURRENT_HOST"
    echo "当前监听端口: $CURRENT_PORT"
    echo ""

    # 输入新地址
    read -p "请输入新的监听地址 (127.0.0.1 或 0.0.0.0，回车保持不变): " NEW_HOST
    if [ -z "$NEW_HOST" ]; then
        NEW_HOST=$CURRENT_HOST
    fi

    # 输入新端口
    read -p "请输入新的监听端口 (1-65535，回车保持不变): " NEW_PORT
    if [ -z "$NEW_PORT" ]; then
        NEW_PORT=$CURRENT_PORT
    fi

    # 验证端口
    if ! [[ "$NEW_PORT" =~ ^[0-9]+$ ]] || [ "$NEW_PORT" -lt 1 ] || [ "$NEW_PORT" -gt 65535 ]; then
        error "无效的端口号: $NEW_PORT"
        return 1
    fi

    # 更新配置
    update_yaml_value "server" "host" "$NEW_HOST"
    update_yaml_value "server" "port" "$NEW_PORT"

    success "监听地址和端口已更新"
    warn "请重启服务使配置生效"
    echo ""
}

# 更改管理员账户
change_admin_user() {
    echo ""
    echo "=========================================="
    echo "  更改管理员账户"
    echo "=========================================="

    CURRENT_USER=$(get_config_value "username")
    echo "当前管理员账户: $CURRENT_USER"
    echo ""

    read -p "请输入新的管理员账户: " NEW_USER
    if [ -z "$NEW_USER" ]; then
        warn "账户不能为空"
        return 1
    fi

    update_yaml_value "admin" "username" "$NEW_USER"
    success "管理员账户已更新"
    warn "请重启服务使配置生效"
    echo ""
}

# 更改管理员密码
change_admin_pass() {
    echo ""
    echo "=========================================="
    echo "  更改管理员密码"
    echo "=========================================="

    CURRENT_PASS=$(get_config_value "password")
    echo "当前管理员密码: $CURRENT_PASS"
    echo ""

    read -p "请输入新的管理员密码: " NEW_PASS
    if [ -z "$NEW_PASS" ]; then
        warn "密码不能为空"
        return 1
    fi

    update_yaml_value "admin" "password" "$NEW_PASS"
    success "管理员密码已更新"
    warn "请重启服务使配置生效"
    echo ""
}

# 更改管理员后台路径
change_admin_path() {
    echo ""
    echo "=========================================="
    echo "  更改管理员后台路径"
    echo "=========================================="

    CURRENT_PATH=$(get_config_value "path")
    echo "当前后台路径: $CURRENT_PATH"
    echo ""

    read -p "请输入新的后台路径 (如 /admin): " NEW_PATH
    if [ -z "$NEW_PATH" ]; then
        warn "路径不能为空"
        return 1
    fi

    # 确保路径以 / 开头
    if [[ ! "$NEW_PATH" =~ ^/ ]]; then
        NEW_PATH="/$NEW_PATH"
    fi

    update_yaml_value "admin" "path" "$NEW_PATH"
    success "管理员后台路径已更新"
    warn "请重启服务使配置生效"
    echo ""
}

# 安装系统
install_system() {
    echo ""
    echo "=========================================="
    echo "  安装魔方财务平台聚合系统"
    echo "=========================================="

    # 检查关键文件
    if [ ! -f "$APP_DIR/app.py" ]; then
        error "未找到 app.py: $APP_DIR/app.py"
        exit 1
    fi

    # 安装 Python
    install_python

    # 安装 uv
    install_uv

    # 安装依赖
    install_deps

    success "系统安装完成！"
    info "您现在可以使用选项 1 启动服务"
    echo ""
}

# 显示菜单
show_menu() {
    echo ""
    echo "=========================================="
    echo "  魔方财务平台聚合系统 - 管理菜单"
    echo "=========================================="
    echo "  1. 启动服务"
    echo "  2. 停止服务"
    echo "  3. 重启服务"
    echo "  4. 查看系统状态"
    echo "  5. 更改监听地址和端口"
    echo "  6. 更改管理员账户"
    echo "  7. 更改管理员密码"
    echo "  8. 更改管理员后台路径"
    echo "  9. 安装系统"
    echo "  0. 退出"
    echo "=========================================="
    echo ""
}

# 主函数
main() {
    # 切换到脚本所在目录，确保相对路径正确
    cd "$SCRIPT_DIR"

    # 检查关键文件是否存在
    if [ ! -f "$APP_DIR/app.py" ]; then
        error "未找到 app.py，请在项目根目录运行此脚本"
        exit 1
    fi

    while true; do
        show_menu
        read -p "请选择操作 [0-9]: " choice

        case $choice in
            1)
                start_service
                ;;
            2)
                stop_service
                ;;
            3)
                restart_service
                ;;
            4)
                show_status
                ;;
            5)
                change_host_port
                ;;
            6)
                change_admin_user
                ;;
            7)
                change_admin_pass
                ;;
            8)
                change_admin_path
                ;;
            9)
                install_system
                ;;
            0)
                info "退出管理菜单"
                exit 0
                ;;
            *)
                error "无效的选项: $choice"
                ;;
        esac

        read -p "按回车键继续..."
    done
}

# 运行主函数
main

