import sqlite3
import os
import time
import secrets
from config import DATABASE, encrypt_password, decrypt_password


def get_db():
    db = sqlite3.connect(DATABASE)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    return db


def init_db():
    db = get_db()
    db.executescript("""
    CREATE TABLE IF NOT EXISTS platforms (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        url TEXT NOT NULL,
        platform_type TEXT NOT NULL DEFAULT 'mofang',
        auth_method TEXT NOT NULL DEFAULT 'password',
        account TEXT NOT NULL,
        password TEXT NOT NULL,
        jwt TEXT DEFAULT '',
        jwt_expire INTEGER DEFAULT 0,
        created_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS share_tokens (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        token TEXT NOT NULL UNIQUE,
        platform_id INTEGER NOT NULL,
        host_id INTEGER NOT NULL,
        note TEXT DEFAULT '',
        created_at INTEGER NOT NULL,
        FOREIGN KEY (platform_id) REFERENCES platforms(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS captcha_sessions (
        id TEXT PRIMARY KEY,
        platform_id INTEGER NOT NULL,
        idtoken TEXT NOT NULL,
        captcha_image_url TEXT DEFAULT '',
        captcha_value TEXT DEFAULT '',
        status TEXT DEFAULT 'pending',
        created_at INTEGER NOT NULL
    );
    """)
    db.commit()
    db.close()


# --- Platform CRUD ---

def platform_create(name, url, platform_type, auth_method, account, password):
    db = get_db()
    db.execute(
        "INSERT INTO platforms (name, url, platform_type, auth_method, account, password, created_at) VALUES (?,?,?,?,?,?,?)",
        (name, url.rstrip("/"), platform_type, auth_method, account, encrypt_password(password), int(time.time()))
    )
    db.commit()
    db.close()


def platform_list():
    db = get_db()
    rows = db.execute("SELECT * FROM platforms ORDER BY id DESC").fetchall()
    db.close()
    result = []
    for r in rows:
        d = dict(r)
        d["password"] = decrypt_password(d.get("password", ""))
        result.append(d)
    return result


def platform_get(pid):
    db = get_db()
    row = db.execute("SELECT * FROM platforms WHERE id=?", (pid,)).fetchone()
    db.close()
    if not row:
        return None
    d = dict(row)
    d["password"] = decrypt_password(d.get("password", ""))
    return d


def platform_update(pid, **kwargs):
    if "password" in kwargs and kwargs["password"]:
        kwargs["password"] = encrypt_password(kwargs["password"])
    db = get_db()
    sets = ", ".join(f"{k}=?" for k in kwargs)
    vals = list(kwargs.values()) + [pid]
    db.execute(f"UPDATE platforms SET {sets} WHERE id=?", vals)
    db.commit()
    db.close()


def platform_delete(pid):
    db = get_db()
    db.execute("DELETE FROM platforms WHERE id=?", (pid,))
    db.execute("DELETE FROM share_tokens WHERE platform_id=?", (pid,))
    db.commit()
    db.close()


def platform_update_jwt(pid, jwt, expire=0):
    db = get_db()
    db.execute("UPDATE platforms SET jwt=?, jwt_expire=? WHERE id=?", (jwt, expire, pid))
    db.commit()
    db.close()


# --- Share Token CRUD ---

def share_token_create(platform_id, host_id, note=""):
    token = secrets.token_urlsafe(32)
    db = get_db()
    # 同一 platform_id + host_id 只保留最新token，旧的立即作废
    db.execute(
        "DELETE FROM share_tokens WHERE platform_id=? AND host_id=?",
        (platform_id, host_id)
    )
    db.execute(
        "INSERT INTO share_tokens (token, platform_id, host_id, note, created_at) VALUES (?,?,?,?,?)",
        (token, platform_id, host_id, note, int(time.time()))
    )
    db.commit()
    db.close()
    return token


def share_token_get(token):
    db = get_db()
    row = db.execute("SELECT * FROM share_tokens WHERE token=?", (token,)).fetchone()
    db.close()
    return dict(row) if row else None


def share_token_list(platform_id=None):
    db = get_db()
    if platform_id:
        rows = db.execute("SELECT * FROM share_tokens WHERE platform_id=? ORDER BY id DESC", (platform_id,)).fetchall()
    else:
        rows = db.execute("SELECT * FROM share_tokens ORDER BY id DESC").fetchall()
    db.close()
    return [dict(r) for r in rows]


def share_token_delete(token_id):
    db = get_db()
    db.execute("DELETE FROM share_tokens WHERE id=?", (token_id,))
    db.commit()
    db.close()


def share_token_update_note(token_id, note):
    db = get_db()
    db.execute("UPDATE share_tokens SET note=? WHERE id=?", (note, token_id))
    db.commit()
    db.close()


def share_token_get_by_host(platform_id, host_id):
    db = get_db()
    row = db.execute(
        "SELECT * FROM share_tokens WHERE platform_id=? AND host_id=?",
        (platform_id, host_id)
    ).fetchone()
    db.close()
    return dict(row) if row else None


# --- Captcha Session ---

def captcha_session_create(platform_id, idtoken, image_url=""):
    sid = secrets.token_hex(16)
    db = get_db()
    db.execute(
        "INSERT INTO captcha_sessions (id, platform_id, idtoken, captcha_image_url, status, created_at) VALUES (?,?,?,?,?,?)",
        (sid, platform_id, idtoken, image_url, "pending", int(time.time()))
    )
    db.commit()
    db.close()
    return sid


def captcha_session_get(sid):
    db = get_db()
    row = db.execute("SELECT * FROM captcha_sessions WHERE id=?", (sid,)).fetchone()
    db.close()
    return dict(row) if row else None


def captcha_session_update(sid, **kwargs):
    db = get_db()
    sets = ", ".join(f"{k}=?" for k in kwargs)
    vals = list(kwargs.values()) + [sid]
    db.execute(f"UPDATE captcha_sessions SET {sets} WHERE id=?", vals)
    db.commit()
    db.close()


def captcha_session_cleanup(max_age=300):
    db = get_db()
    db.execute("DELETE FROM captcha_sessions WHERE created_at < ?", (int(time.time()) - max_age,))
    db.commit()
    db.close()

