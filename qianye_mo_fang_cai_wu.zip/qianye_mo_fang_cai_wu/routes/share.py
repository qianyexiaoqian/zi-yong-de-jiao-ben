from flask import Blueprint, render_template, request, jsonify, session
from models import share_token_get, platform_get, captcha_session_get
from mofang_client import get_client

share_bp = Blueprint("share", __name__, url_prefix="/share")


@share_bp.route("/", methods=["GET", "POST"])
def token_input():
    if request.method == "POST":
        token = request.form.get("token", "").strip()
        if token:
            st = share_token_get(token)
            if st:
                session["share_token"] = token
                return jsonify({"status": 1, "redirect": f"/share/manage"})
            return jsonify({"status": 0, "msg": "无效的访问令牌"})
    return render_template("share/token.html")


@share_bp.route("/manage")
def manage():
    token = session.get("share_token") or request.args.get("token", "")
    if not token:
        return render_template("share/token.html")
    st = share_token_get(token)
    if not st:
        return render_template("share/token.html", error="无效的访问令牌")
    session["share_token"] = token
    return render_template("share/manage.html", share=st)


@share_bp.route("/api/detail")
def api_detail():
    token = session.get("share_token", "")
    st = share_token_get(token)
    if not st:
        return jsonify({"status": 0, "msg": "无效令牌"})

    client = get_client(st["platform_id"])
    if not client:
        return jsonify({"status": 0, "msg": "平台不存在"})

    auth = client.ensure_jwt()
    if auth.get("status") == -2:
        return jsonify(auth)
    if auth.get("status") != 1:
        return jsonify(auth)

    result = client.get_host(st["host_id"])
    if result.get("status") == -1:
        auth = client.login()
        if auth.get("status") == -2:
            return jsonify(auth)
        result = client.get_host(st["host_id"])
    return jsonify(result)


@share_bp.route("/api/status")
def api_status():
    token = session.get("share_token", "")
    st = share_token_get(token)
    if not st:
        return jsonify({"status": 0, "msg": "无效令牌"})

    client = get_client(st["platform_id"])
    if not client:
        return jsonify({"status": 0, "msg": "平台不存在"})

    auth = client.ensure_jwt()
    if auth.get("status") != 1:
        return jsonify(auth)
    return jsonify(client.get_status(st["host_id"]))


@share_bp.route("/api/action", methods=["POST"])
def api_action():
    token = session.get("share_token", "")
    st = share_token_get(token)
    if not st:
        return jsonify({"status": 0, "msg": "无效令牌"})

    client = get_client(st["platform_id"])
    if not client:
        return jsonify({"status": 0, "msg": "平台不存在"})

    auth = client.ensure_jwt()
    if auth.get("status") == -2:
        return jsonify(auth)
    if auth.get("status") != 1:
        return jsonify(auth)

    action = request.json.get("action", "")
    host_id = st["host_id"]
    action_map = {
        "on": client.power_on,
        "off": client.power_off,
        "reboot": client.reboot,
        "hard_off": client.hard_off,
        "hard_reboot": client.hard_reboot,
    }

    if action == "vnc":
        result = client.vnc(host_id)
        if result.get("status") == -1:
            auth = client.login()
            if auth.get("status") == -2:
                return jsonify(auth)
            if auth.get("status") != 1:
                return jsonify({"status": 0, "msg": "平台登录失败，请联系管理员"})
            result = client.vnc(host_id)
            if result.get("status") == -1:
                return jsonify({"status": 0, "msg": "操作失败，平台token持续无效，请联系管理员"})
        return jsonify(result)
    elif action == "get_reinstall_os":
        result = client.get_reinstall_os(host_id)
        if result.get("status") == -1:
            auth = client.login()
            if auth.get("status") == -2:
                return jsonify(auth)
            if auth.get("status") != 1:
                return jsonify({"status": 0, "msg": "平台登录失败，请联系管理员"})
            result = client.get_reinstall_os(host_id)
            if result.get("status") == -1:
                return jsonify({"status": 0, "msg": "操作失败，平台token持续无效，请联系管理员"})
        return jsonify(result)
    elif action == "reinstall":
        os_id = request.json.get("os_id", "")
        pwd = request.json.get("password", "")
        result = client.reinstall(host_id, os_id, password=pwd)
        if result.get("status") == -1:
            auth = client.login()
            if auth.get("status") == -2:
                return jsonify(auth)
            if auth.get("status") != 1:
                return jsonify({"status": 0, "msg": "平台登录失败，请联系管理员"})
            result = client.reinstall(host_id, os_id, password=pwd)
            if result.get("status") == -1:
                return jsonify({"status": 0, "msg": "操作失败，平台token持续无效，请联系管理员"})
        return jsonify(result)
    elif action == "rescue":
        rescue_id = request.json.get("rescue_id", "1")
        system = request.json.get("system", "2")
        temp_pass = request.json.get("temp_pass", "")
        force = request.json.get("force", "on")
        result = client.rescue(host_id, rescue_id=rescue_id, system=system, temp_pass=temp_pass, force=force)
        if result.get("status") == -1:
            auth = client.login()
            if auth.get("status") == -2:
                return jsonify(auth)
            if auth.get("status") != 1:
                return jsonify({"status": 0, "msg": "平台登录失败，请联系管理员"})
            result = client.rescue(host_id, rescue_id=rescue_id, system=system, temp_pass=temp_pass, force=force)
            if result.get("status") == -1:
                return jsonify({"status": 0, "msg": "操作失败，平台token持续无效，请联系管理员"})
        return jsonify(result)
    elif action == "exit_rescue":
        result = client.exit_rescue(host_id)
        if result.get("status") == -1:
            auth = client.login()
            if auth.get("status") == -2:
                return jsonify(auth)
            if auth.get("status") != 1:
                return jsonify({"status": 0, "msg": "平台登录失败，请联系管理员"})
            result = client.exit_rescue(host_id)
            if result.get("status") == -1:
                return jsonify({"status": 0, "msg": "操作失败，平台token持续无效，请联系管理员"})
        return jsonify(result)
    elif action == "repassword":
        pwd = request.json.get("password", "")
        result = client.repassword(host_id, pwd)
        if result.get("status") == -1:
            auth = client.login()
            if auth.get("status") == -2:
                return jsonify(auth)
            if auth.get("status") != 1:
                return jsonify({"status": 0, "msg": "平台登录失败，请联系管理员"})
            result = client.repassword(host_id, pwd)
            if result.get("status") == -1:
                return jsonify({"status": 0, "msg": "操作失败，平台token持续无效，请联系管理员"})
        return jsonify(result)
    elif action in action_map:
        result = action_map[action](host_id)
        if result.get("status") == -1:
            auth = client.login()
            if auth.get("status") == -2:
                return jsonify(auth)
            if auth.get("status") != 1:
                return jsonify({"status": 0, "msg": "平台登录失败，请联系管理员"})
            result = action_map[action](host_id)
            if result.get("status") == -1:
                return jsonify({"status": 0, "msg": "操作失败，平台token持续无效，请联系管理员"})
        return jsonify(result)
    return jsonify({"status": 0, "msg": "未知操作"})


@share_bp.route("/api/captcha/submit", methods=["POST"])
def api_captcha_submit():
    sid = request.json.get("captcha_session", "")
    captcha = request.json.get("captcha", "")
    cs = captcha_session_get(sid)
    if not cs:
        return jsonify({"status": 0, "msg": "验证码会话不存在"})

    client = get_client(cs["platform_id"])
    if not client:
        return jsonify({"status": 0, "msg": "平台不存在"})

    result = client.login(captcha=captcha, idtoken=cs["idtoken"])
    return jsonify(result)


@share_bp.route("/api/geetest/verify", methods=["POST"])
def api_geetest_verify():
    """接收极验验证参数并重新登录"""
    token = session.get("share_token")
    if not token:
        return jsonify({"status": 0, "msg": "未登录"})

    st = share_token_get(token)
    if not st:
        return jsonify({"status": 0, "msg": "无效的访问令牌"})

    data = request.get_json()
    lot_number = data.get("lot_number", "")
    pass_token = data.get("pass_token", "")
    gen_time = data.get("gen_time", "")
    captcha_output = data.get("captcha_output", "")

    client = get_client(st["platform_id"])
    if not client:
        return jsonify({"status": 0, "msg": "平台不存在"})

    # 检查是否是狐蒂云平台
    platform = platform_get(st["platform_id"])
    if platform.get("platform_type") != "hudi":
        return jsonify({"status": 0, "msg": "该平台不支持极验验证"})

    # 调用登录接口，传递极验4.0验证参数
    result = client.login(
        lot_number=lot_number,
        pass_token=pass_token,
        gen_time=gen_time,
        captcha_output=captcha_output
    )

    return jsonify(result)


@share_bp.route("/logout")
def logout():
    session.pop("share_token", None)
    return render_template("share/token.html")

