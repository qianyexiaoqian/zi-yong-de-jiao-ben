from flask import Blueprint, render_template, request, redirect, url_for, jsonify, session
from routes import admin_required
from models import (
    platform_create, platform_list, platform_get, platform_update, platform_delete,
    share_token_create, share_token_list, share_token_delete,
    share_token_update_note, share_token_get_by_host
)
from mofang_client import get_client, MofangClient
from models import captcha_session_get, captcha_session_update

admin_bp = Blueprint("admin", __name__)


@admin_bp.before_request
def check_admin():
    # 排除静态资源
    if not session.get("admin"):
        return redirect(url_for("auth.login"))


# --- 平台管理 ---

@admin_bp.route("/platforms")
def platforms():
    plist = platform_list()
    return render_template("admin/platforms.html", platforms=plist)


@admin_bp.route("/platforms/add", methods=["GET", "POST"])
def platform_add():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        url = request.form.get("url", "").strip()
        platform_type = request.form.get("platform_type", "mofang")
        auth_method = request.form.get("auth_method", "api")
        account = request.form.get("account", "").strip()
        password = request.form.get("password", "").strip()

        if not (name and url and account and password):
            return jsonify({"status": 0, "msg": "请填写完整信息"})

        # 只创建平台记录，不立即登录；JWT会在实际使用时按需获取
        platform_create(name, url, platform_type, auth_method, account, password)
        return jsonify({"status": 1, "msg": "平台添加成功"})

    return render_template("admin/platform_add.html")


@admin_bp.route("/platforms/<int:pid>/edit", methods=["GET", "POST"])
def platform_edit(pid):
    p = platform_get(pid)
    if not p:
        return redirect(url_for("admin.platforms"))
    if request.method == "POST":
        updates = {}
        for field in ["name", "url", "platform_type", "auth_method", "account", "password"]:
            val = request.form.get(field, "").strip()
            if val:
                updates[field] = val
        if updates:
            platform_update(pid, **updates)
        return redirect(url_for("admin.platforms"))
    return render_template("admin/platform_edit.html", platform=p)


@admin_bp.route("/platforms/<int:pid>/delete", methods=["POST"])
def platform_del(pid):
    platform_delete(pid)
    return redirect(url_for("admin.platforms"))


# --- 服务器管理 ---

@admin_bp.route("/servers")
def servers():
    plist = platform_list()
    pid = request.args.get("platform_id", type=int)
    return render_template("admin/servers.html", platforms=plist, current_pid=pid)


@admin_bp.route("/api/servers/<int:pid>")
def api_servers(pid):
    """AJAX: 获取平台下的服务器列表"""
    client = get_client(pid)
    if not client:
        return jsonify({"status": 0, "msg": "平台不存在"})

    auth = client.ensure_jwt()
    if auth.get("status") == -2:
        return jsonify(auth)
    if auth.get("status") != 1:
        return jsonify(auth)

    page = request.args.get("page", 1, type=int)
    result = client.get_hosts(page=page, limit=50)

    if result.get("status") == -1:
        # token过期，尝试重新登录
        auth = client.login()
        if auth.get("status") == -2:
            return jsonify(auth)
        if auth.get("status") != 1:
            return jsonify({"status": 0, "msg": "登录失败"})
        result = client.get_hosts(page=page, limit=50)

    return jsonify(result)


@admin_bp.route("/api/server/<int:pid>/<int:host_id>")
def api_server_detail(pid, host_id):
    """AJAX: 获取服务器详情"""
    client = get_client(pid)
    if not client:
        return jsonify({"status": 0, "msg": "平台不存在"})

    auth = client.ensure_jwt()
    if auth.get("status") == -2:
        return jsonify(auth)
    if auth.get("status") != 1:
        return jsonify(auth)

    result = client.get_host(host_id)
    if result.get("status") == -1:
        auth = client.login()
        if auth.get("status") == -2:
            return jsonify(auth)
        result = client.get_host(host_id)
    return jsonify(result)


@admin_bp.route("/api/server/<int:pid>/<int:host_id>/status")
def api_server_status(pid, host_id):
    client = get_client(pid)
    if not client:
        return jsonify({"status": 0, "msg": "平台不存在"})
    auth = client.ensure_jwt()
    if auth.get("status") != 1:
        return jsonify(auth)
    return jsonify(client.get_status(host_id))


@admin_bp.route("/api/server/<int:pid>/<int:host_id>/action", methods=["POST"])
def api_server_action(pid, host_id):
    """AJAX: 执行服务器操作"""
    client = get_client(pid)
    if not client:
        return jsonify({"status": 0, "msg": "平台不存在"})

    auth = client.ensure_jwt()
    if auth.get("status") == -2:
        return jsonify(auth)
    if auth.get("status") != 1:
        return jsonify(auth)

    action = request.json.get("action", "")
    action_map = {
        "on": client.power_on,
        "off": client.power_off,
        "reboot": client.reboot,
        "hard_off": client.hard_off,
        "hard_reboot": client.hard_reboot,
    }

    if action == "vnc":
        result = client.vnc(host_id)
        if result.get("status") == -1:
            auth = client.login()
            if auth.get("status") == -2:
                return jsonify(auth)
            if auth.get("status") != 1:
                return jsonify({"status": 0, "msg": "平台登录失败，请检查平台账密配置"})
            result = client.vnc(host_id)
            if result.get("status") == -1:
                return jsonify({"status": 0, "msg": "操作失败，平台token持续无效，请稍后重试"})
        return jsonify(result)
    elif action == "get_reinstall_os":
        result = client.get_reinstall_os(host_id)
        if result.get("status") == -1:
            auth = client.login()
            if auth.get("status") == -2:
                return jsonify(auth)
            if auth.get("status") != 1:
                return jsonify({"status": 0, "msg": "平台登录失败，请检查平台账密配置"})
            result = client.get_reinstall_os(host_id)
            if result.get("status") == -1:
                return jsonify({"status": 0, "msg": "操作失败，平台token持续无效，请稍后重试"})
        return jsonify(result)
    elif action == "reinstall":
        os_id = request.json.get("os_id", "")
        pwd = request.json.get("password", "")
        result = client.reinstall(host_id, os_id, password=pwd)
        if result.get("status") == -1:
            auth = client.login()
            if auth.get("status") == -2:
                return jsonify(auth)
            if auth.get("status") != 1:
                return jsonify({"status": 0, "msg": "平台登录失败，请检查平台账密配置"})
            result = client.reinstall(host_id, os_id, password=pwd)
            if result.get("status") == -1:
                return jsonify({"status": 0, "msg": "操作失败，平台token持续无效，请稍后重试"})
        return jsonify(result)
    elif action == "rescue":
        rescue_id = request.json.get("rescue_id", "1")
        system = request.json.get("system", "2")
        temp_pass = request.json.get("temp_pass", "")
        force = request.json.get("force", "on")
        result = client.rescue(host_id, rescue_id=rescue_id, system=system, temp_pass=temp_pass, force=force)
        if result.get("status") == -1:
            auth = client.login()
            if auth.get("status") == -2:
                return jsonify(auth)
            if auth.get("status") != 1:
                return jsonify({"status": 0, "msg": "平台登录失败，请检查平台账密配置"})
            result = client.rescue(host_id, rescue_id=rescue_id, system=system, temp_pass=temp_pass, force=force)
            if result.get("status") == -1:
                return jsonify({"status": 0, "msg": "操作失败，平台token持续无效，请稍后重试"})
        return jsonify(result)
    elif action == "exit_rescue":
        result = client.exit_rescue(host_id)
        if result.get("status") == -1:
            auth = client.login()
            if auth.get("status") == -2:
                return jsonify(auth)
            if auth.get("status") != 1:
                return jsonify({"status": 0, "msg": "平台登录失败，请检查平台账密配置"})
            result = client.exit_rescue(host_id)
            if result.get("status") == -1:
                return jsonify({"status": 0, "msg": "操作失败，平台token持续无效，请稍后重试"})
        return jsonify(result)
    elif action == "repassword":
        pwd = request.json.get("password", "")
        result = client.repassword(host_id, pwd)
        if result.get("status") == -1:
            auth = client.login()
            if auth.get("status") == -2:
                return jsonify(auth)
            if auth.get("status") != 1:
                return jsonify({"status": 0, "msg": "平台登录失败，请检查平台账密配置"})
            result = client.repassword(host_id, pwd)
            if result.get("status") == -1:
                return jsonify({"status": 0, "msg": "操作失败，平台token持续无效，请稍后重试"})
        return jsonify(result)
    elif action in action_map:
        result = action_map[action](host_id)
        if result.get("status") == -1:
            auth = client.login()
            if auth.get("status") == -2:
                return jsonify(auth)
            if auth.get("status") != 1:
                return jsonify({"status": 0, "msg": "平台登录失败，请检查平台账密配置"})
            result = action_map[action](host_id)
            if result.get("status") == -1:
                return jsonify({"status": 0, "msg": "操作失败，平台token持续无效，请稍后重试"})
        return jsonify(result)
    return jsonify({"status": 0, "msg": "未知操作"})


# --- 服务器备注管理 ---

@admin_bp.route("/api/server/<int:pid>/<int:host_id>/remark", methods=["POST"])
def api_server_remark(pid, host_id):
    """AJAX: 更新服务器备注"""
    client = get_client(pid)
    if not client:
        return jsonify({"status": 0, "msg": "平台不存在"})

    auth = client.ensure_jwt()
    if auth.get("status") == -2:
        return jsonify(auth)
    if auth.get("status") != 1:
        return jsonify(auth)

    remark = request.json.get("remark", "")
    result = client.update_host_remark(host_id, remark)

    if result.get("status") == -1:
        auth = client.login()
        if auth.get("status") == -2:
            return jsonify(auth)
        if auth.get("status") != 1:
            return jsonify({"status": 0, "msg": "平台登录失败，请检查平台账密配置"})
        result = client.update_host_remark(host_id, remark)
        if result.get("status") == -1:
            return jsonify({"status": 0, "msg": "操作失败，平台token持续无效，请稍后重试"})
    return jsonify(result)


# --- 验证码处理 ---

@admin_bp.route("/api/captcha/submit", methods=["POST"])
def api_captcha_submit():
    """提交验证码完成登录"""
    sid = request.json.get("captcha_session", "")
    captcha = request.json.get("captcha", "")
    cs = captcha_session_get(sid)
    if not cs:
        return jsonify({"status": 0, "msg": "验证码会话不存在"})

    client = get_client(cs["platform_id"])
    if not client:
        return jsonify({"status": 0, "msg": "平台不存在"})

    result = client.login(captcha=captcha, idtoken=cs["idtoken"])
    return jsonify(result)


# --- 分享Token管理 ---

@admin_bp.route("/api/share/create", methods=["POST"])
def api_share_create():
    pid = request.json.get("platform_id")
    host_id = request.json.get("host_id")
    note = request.json.get("note", "")
    if not pid or not host_id:
        return jsonify({"status": 0, "msg": "参数缺失"})
    token = share_token_create(pid, host_id, note)
    return jsonify({"status": 1, "token": token})


@admin_bp.route("/api/share/check", methods=["POST"])
def api_share_check():
    """检查指定服务器是否已有分享链接"""
    pid = request.json.get("platform_id")
    host_id = request.json.get("host_id")
    if not pid or not host_id:
        return jsonify({"status": 0, "msg": "参数缺失"})
    existing = share_token_get_by_host(pid, host_id)
    if existing:
        return jsonify({"status": 1, "exists": True, "token_id": existing["id"], "token": existing["token"], "note": existing.get("note", "")})
    return jsonify({"status": 1, "exists": False})


@admin_bp.route("/api/share/<int:token_id>/note", methods=["POST"])
def api_share_update_note(token_id):
    """更新分享备注"""
    note = request.json.get("note", "")
    share_token_update_note(token_id, note)
    return jsonify({"status": 1, "msg": "备注已保存"})


@admin_bp.route("/api/share/list")
def api_share_list():
    pid = request.args.get("platform_id", type=int)
    tokens = share_token_list(pid)
    return jsonify({"status": 1, "data": tokens})


@admin_bp.route("/api/share/<int:token_id>/delete", methods=["POST"])
def api_share_delete(token_id):
    share_token_delete(token_id)
    return jsonify({"status": 1, "msg": "已删除"})


@admin_bp.route("/api/geetest/verify", methods=["POST"])
def api_geetest_verify():
    """接收极验验证参数并重新登录"""
    data = request.get_json()
    pid = data.get("platform_id")
    lot_number = data.get("lot_number", "")
    pass_token = data.get("pass_token", "")
    gen_time = data.get("gen_time", "")
    captcha_output = data.get("captcha_output", "")

    if not pid:
        return jsonify({"status": 0, "msg": "缺少平台ID"})

    client = get_client(pid)
    if not client:
        return jsonify({"status": 0, "msg": "平台不存在"})

    # 检查是否是狐蒂云平台
    platform = platform_get(pid)
    if platform.get("platform_type") != "hudi":
        return jsonify({"status": 0, "msg": "该平台不支持极验验证"})

    # 调用登录接口，传递极验4.0验证参数
    result = client.login(
        lot_number=lot_number,
        pass_token=pass_token,
        gen_time=gen_time,
        captcha_output=captcha_output
    )

    return jsonify(result)

