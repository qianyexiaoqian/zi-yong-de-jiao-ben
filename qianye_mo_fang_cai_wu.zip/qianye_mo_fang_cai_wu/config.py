import os
import secrets
import yaml
from cryptography.fernet import Fernet

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
_YAML_PATH = os.path.join(BASE_DIR, "config.yaml")

# 读取 yaml 配置
_cfg = {}
if os.path.exists(_YAML_PATH):
    with open(_YAML_PATH, "r", encoding="utf-8") as f:
        _cfg = yaml.safe_load(f) or {}

_server = _cfg.get("server", {})
_admin = _cfg.get("admin", {})
_security = _cfg.get("security", {})

# --- 服务器 ---
HOST = _server.get("host", "0.0.0.0")
PORT = int(_server.get("port", 5000))
DEBUG = bool(_server.get("debug", True))
DOMAIN = _server.get("domain", "").strip()

# --- 管理后台 ---
ADMIN_PATH = _admin.get("path", "/mofang-admin")
ADMIN_USERNAME = _admin.get("username", "admin")
ADMIN_PASSWORD = _admin.get("password", "admin123")

# --- 安全 ---
_sk = _security.get("secret_key", "")
SECRET_KEY = _sk if _sk else secrets.token_hex(32)

# Fernet 密钥：为空时自动生成并回写 config.yaml
_fernet_key_str = _security.get("fernet_key", "")
if not _fernet_key_str:
    _fernet_key_str = Fernet.generate_key().decode()
    # 回写到 config.yaml
    _cfg.setdefault("security", {})["fernet_key"] = _fernet_key_str
    with open(_YAML_PATH, "w", encoding="utf-8") as f:
        yaml.dump(_cfg, f, default_flow_style=False, allow_unicode=True)
    print(f"[安全] 已自动生成 fernet_key 并写入 config.yaml，请妥善保管此密钥")

FERNET_KEY = _fernet_key_str
_fernet = Fernet(FERNET_KEY.encode())

DATABASE = os.path.join(BASE_DIR, "data.db")


def encrypt_password(plain: str) -> str:
    if not plain:
        return plain
    return _fernet.encrypt(plain.encode()).decode()


def decrypt_password(stored: str) -> str:
    if not stored:
        return stored
    return _fernet.decrypt(stored.encode()).decode()

