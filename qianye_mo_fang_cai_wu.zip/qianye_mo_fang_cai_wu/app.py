import os
import sys
sys.path.insert(0, os.path.dirname(__file__))

from flask import Flask, redirect, url_for
from config import SECRET_KEY, ADMIN_PATH, HOST, PORT, DEBUG, DOMAIN
from models import init_db
from routes import auth_bp
from routes.admin import admin_bp
from routes.share import share_bp

app = Flask(__name__)
app.secret_key = SECRET_KEY

# 管理后台蓝图挂载到可配置路径（config.yaml 中 admin.path）
app.register_blueprint(auth_bp, url_prefix=ADMIN_PATH)
app.register_blueprint(admin_bp, url_prefix=ADMIN_PATH)
app.register_blueprint(share_bp)


@app.route("/")
def index():
    return redirect(url_for("share.token_input"))


if __name__ == "__main__":
    init_db()

    # 启动日志
    display_host = "127.0.0.1" if HOST == "0.0.0.0" else HOST
    if DOMAIN:
        base = f"http://{DOMAIN}" if "://" not in DOMAIN else DOMAIN
    else:
        base = f"http://{display_host}:{PORT}"

    print()
    print("=" * 50)
    print("  魔方财务平台聚合系统 启动成功")
    print("=" * 50)
    print(f"  用户访问地址:   {base}/share/")
    print(f"  管理后台地址:   {base}{ADMIN_PATH}/login")
    print("=" * 50)
    print()

    app.run(host=HOST, port=PORT, debug=DEBUG)

