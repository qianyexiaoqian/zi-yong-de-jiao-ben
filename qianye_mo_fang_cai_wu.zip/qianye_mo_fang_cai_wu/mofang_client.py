import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import time
import logging
from models import platform_get, platform_update_jwt, captcha_session_create, captcha_session_get

logger = logging.getLogger(__name__)

# 与 idcsmart-main 例程对齐的 User-Agent
_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"

# 重试策略：应对 ConnectionAbortedError / ConnectionResetError 等网络抖动
_retry = Retry(total=3, backoff_factor=0.5, status_forcelist=[502, 503, 504])
_adapter = HTTPAdapter(max_retries=_retry)


# 全局JWT缓存: {platform_id: {"jwt": str, "expire": int}}
_jwt_cache = {}


class MofangClient:
    """魔方财务API客户端 - 所有调用在服务端完成，保护账密安全"""

    def __init__(self, platform):
        self.platform = platform
        self.base_url = platform["url"].rstrip("/")
        self.jwt = platform.get("jwt", "")
        self.jwt_expire = platform.get("jwt_expire", 0)
        self.session = requests.Session()
        self.session.mount("http://", _adapter)
        self.session.mount("https://", _adapter)
        self.session.headers.update({"User-Agent": _UA})
        if self.jwt:
            self.session.headers["authorization"] = f"JWT {self.jwt}"
        self._login_in_progress = False  # 防止递归登录

    def _url(self, path):
        return f"{self.base_url}{path}"

    def _request(self, method, path, **kwargs):
        """发起请求，自动处理JWT过期并重试（集成retry逻辑，参考idcsmart.py）"""
        if self.jwt:
            self.session.headers["authorization"] = f"JWT {self.jwt}"
        kwargs.setdefault("timeout", 30)

        try:
            resp = self.session.request(method, self._url(path), **kwargs)
        except Exception as e:
            logger.error(f"API request failed: {e}")
            return {"status": 0, "msg": f"请求失败: {str(e)}"}

        # 尝试解析JSON
        try:
            data = resp.json()
        except (ValueError, Exception):
            # 非JSON响应
            text = resp.text.strip()
            if text.startswith("http"):
                return {"status": 200, "url": text}
            # 非JSON响应视为token过期（平台可能返回HTML 404页面）
            data = {}

        # 检测token过期
        is_token_expired = False
        if data.get("status") == 405:
            is_token_expired = True
        elif resp.status_code == 405:
            is_token_expired = True
        elif not data and resp.status_code in [404, 302, 401]:
            # 非JSON响应且HTTP状态码异常 → token过期
            is_token_expired = True

        # 如果token过期，尝试重新登录并重试（参考idcsmart.py的_send_request）
        if is_token_expired and not self._login_in_progress:
            logger.info(f"Token expired for platform {self.platform['id']}, attempting re-login...")
            pid = self.platform.get("id")
            if pid and pid in _jwt_cache:
                del _jwt_cache[pid]

            login_result = self.login()
            if login_result.get("status") == 1:
                # 登录成功，重试原请求
                logger.info("Re-login successful, retrying original request...")
                try:
                    resp = self.session.request(method, self._url(path), **kwargs)
                    try:
                        data = resp.json()
                    except:
                        text = resp.text.strip()
                        if text.startswith("http"):
                            return {"status": 200, "url": text}
                        data = {"status": 0, "msg": "重试后仍返回非JSON响应"}
                except Exception as e:
                    return {"status": 0, "msg": f"重试请求失败: {str(e)}"}
            elif login_result.get("status") == -2:
                # 需要验证码，返回给调用方处理
                return login_result
            elif login_result.get("status") == -3:
                # 需要二次验证，返回给调用方处理
                return login_result
            else:
                # 登录失败
                return {"status": 0, "msg": f"重新登录失败: {login_result.get('msg', '未知错误')}"}

        return data if data else {"status": 0, "msg": "空响应"}

    def _save_jwt(self, jwt_token):
        """保存JWT到实例、session、数据库和缓存"""
        self.jwt = jwt_token
        self.jwt_expire = int(time.time()) + 3600
        self.session.headers["authorization"] = f"JWT {self.jwt}"
        pid = self.platform["id"]
        platform_update_jwt(pid, self.jwt, self.jwt_expire)
        _jwt_cache[pid] = {"jwt": self.jwt, "expire": self.jwt_expire}
        logger.info(f"JWT cached for platform {pid}")

    def login(self, captcha="", idtoken=""):
        """登录魔方平台获取JWT - 支持4种登录方式"""
        if self._login_in_progress:
            return {"status": 0, "msg": "登录正在进行中"}

        self._login_in_progress = True
        try:
            p = self.platform
            auth_method = p.get("auth_method", "email")

            # 根据认证方式构建请求
            if auth_method == "api":
                path = "/v1/login_api"
                payload = {"account": p["account"], "password": p["password"]}
            elif auth_method == "email":
                path = "/v1/login"
                payload = {"Lemail": p["account"], "Lpassword": p["password"]}
            elif auth_method == "phone":
                path = "/v1/login"
                payload = {"Lphone": p["account"], "Lpassword": p["password"]}
                # 可选：手机区号，默认+86
                if p.get("phone_code"):
                    payload["Lphone_code"] = p["phone_code"]
            elif auth_method == "id":
                path = "/v1/login"
                payload = {"Lid": p["account"], "Lpassword": p["password"]}
            else:
                return {"status": 0, "msg": f"不支持的认证方式: {auth_method}"}

            # 如果有验证码参数，添加到payload
            if captcha and idtoken:
                payload["Lcaptcha"] = captcha
                payload["Lidtoken"] = idtoken

            try:
                # 登录请求不带 authorization 头，用 form data 提交
                headers = {"User-Agent": _UA}
                resp = requests.post(self._url(path), data=payload, headers=headers, timeout=30)
                data = resp.json()
            except Exception as e:
                logger.error(f"Login failed: {e}")
                return {"status": 0, "msg": f"登录失败: {str(e)}"}

            logger.info(f"Login response for platform {p['id']}: status={data.get('status')}, has_jwt={'jwt' in data}, keys={list(data.keys())}")

            # 魔方API登录成功: status=200, jwt在根级别
            if data.get("status") == 200 and data.get("jwt"):
                self._save_jwt(data["jwt"])
                return {"status": 1, "msg": "登录成功"}

            # 兼容: 响应中直接有jwt字段（无论status值）
            if data.get("jwt"):
                self._save_jwt(data["jwt"])
                return {"status": 1, "msg": "登录成功"}

            # 兼容旧版: status=1, jwt在data里
            if data.get("status") == 1:
                jwt = data.get("data", {}).get("jwt", "") if isinstance(data.get("data"), dict) else ""
                if jwt:
                    self._save_jwt(jwt)
                    return {"status": 1, "msg": "登录成功"}

            # 检查是否需要图形验证码
            d = data.get("data", {}) if isinstance(data.get("data"), dict) else {}
            if d.get("captcha") or d.get("idtoken"):
                # 如果响应中有captcha字段，说明需要验证码
                # 尝试获取验证码图片
                captcha_img = d.get("captcha", "")
                captcha_idtoken = d.get("idtoken", "")

                # 如果没有图片，主动获取
                if not captcha_img and captcha_idtoken:
                    captcha_data = self.get_captcha()
                    if captcha_data.get("status") == 200:
                        captcha_img = captcha_data.get("img", "")
                        captcha_idtoken = captcha_data.get("idtoken", captcha_idtoken)

                sid = captcha_session_create(
                    p["id"],
                    captcha_idtoken,
                    captcha_img
                )
                return {
                    "status": -2,
                    "msg": "need_captcha",
                    "captcha_session": sid,
                    "captcha_image": captcha_img,
                    "idtoken": captcha_idtoken
                }

            # 检查是否需要二次验证
            if "second_verify" in data:
                second_verify = data["second_verify"]
                return {
                    "status": -3,
                    "msg": "need_second_verify",
                    "second_verify": second_verify
                }

            logger.warning(f"Login failed for platform {p['id']}: {data}")
            return {"status": 0, "msg": data.get("msg", "登录失败")}
        finally:
            self._login_in_progress = False

    def ensure_jwt(self):
        """确保JWT有效，过期则尝试重新登录"""
        if self.jwt and self.jwt_expire > int(time.time()):
            return {"status": 1}
        result = self.login()
        return result

    def get_captcha(self):
        """获取图形验证码图片"""
        try:
            resp = requests.get(self._url("/v1/captcha"), headers={"User-Agent": _UA}, timeout=30)
            data = resp.json()
            return data
        except Exception as e:
            logger.error(f"Get captcha failed: {e}")
            return {"status": 0, "msg": f"获取验证码失败: {str(e)}"}

    def send_verify_code(self, action, vtype, account, captcha="", idtoken=""):
        """发送验证码（手机/邮箱）"""
        payload = {"action": action, "type": vtype, "account": account}
        if captcha and idtoken:
            payload["captcha"] = captcha
            payload["idtoken"] = idtoken
        try:
            resp = requests.post(self._url("/v1/code"), data=payload, headers={"User-Agent": _UA}, timeout=30)
            data = resp.json()
            return data
        except Exception as e:
            logger.error(f"Send verify code failed: {e}")
            return {"status": 0, "msg": f"发送验证码失败: {str(e)}"}

    def submit_second_verify(self, account, code):
        """提交二次验证"""
        payload = {"account": account, "code": code}
        try:
            resp = requests.post(self._url("/v1/second_verify"), data=payload, headers={"User-Agent": _UA}, timeout=30)
            data = resp.json()
            return data
        except Exception as e:
            logger.error(f"Submit second verify failed: {e}")
            return {"status": 0, "msg": f"提交验证失败: {str(e)}"}

    def get_hosts(self, page=1, limit=20, keywords=""):
        """获取所有产品列表"""
        params = {"page": page, "limit": limit}
        if keywords:
            params["keywords"] = keywords
        return self._request("GET", "/v1/hosts", params=params)

    def get_host(self, host_id):
        return self._request("GET", f"/v1/hosts/{host_id}")

    def get_status(self, host_id, stype="host"):
        return self._request("GET", f"/v1/hosts/{host_id}/module/status", params={"type": stype})

    def power_on(self, host_id):
        return self._request("PUT", f"/v1/hosts/{host_id}/module/on")

    def power_off(self, host_id):
        return self._request("PUT", f"/v1/hosts/{host_id}/module/off")

    def reboot(self, host_id):
        return self._request("PUT", f"/v1/hosts/{host_id}/module/reboot")

    def hard_off(self, host_id):
        return self._request("PUT", f"/v1/hosts/{host_id}/module/hard_off")

    def hard_reboot(self, host_id):
        return self._request("PUT", f"/v1/hosts/{host_id}/module/hard_reboot")

    def vnc(self, host_id):
        return self._request("GET", f"/v1/hosts/{host_id}/module/vnc")

    def rescue(self, host_id, rescue_id="1", **kwargs):
        return self._request("POST", f"/v1/hosts/{host_id}/module/rescue", data={"rescue_id": rescue_id})

    def exit_rescue(self, host_id):
        """退出救援系统 — 标准API自定义函数"""
        return self._request("POST", f"/v1/hosts/{host_id}/module/custom", data={"key": "exitRescue"})

    def repassword(self, host_id, password):
        return self._request("POST", f"/v1/hosts/{host_id}/module/repassword", data={"password": password})

    def get_reinstall_os(self, host_id):
        return self._request("GET", f"/v1/hosts/{host_id}/module/reinstall")

    def reinstall(self, host_id, os_id, password="", port=22, part_type=0):
        payload = {"os_id": os_id}
        if password:
            payload["dcim"] = {"password": password, "port": port, "part_type": part_type}
        return self._request("POST", f"/v1/hosts/{host_id}/module/reinstall", json=payload)

    def update_host_remark(self, host_id, remark):
        """更新服务器备注 — 尝试使用与狐蒂云相同的接口"""
        payload = {"id": host_id, "remark": remark}
        return self._request("POST", "/host/remark", data=payload)


def get_client(platform_id):
    """获取平台客户端实例，根据平台类型选择对应的client"""
    p = platform_get(platform_id)
    if not p:
        return None

    # 从缓存注入有效JWT
    cached = _jwt_cache.get(platform_id)
    if cached and cached["expire"] > int(time.time()):
        p["jwt"] = cached["jwt"]
        p["jwt_expire"] = cached["expire"]

    # 根据平台类型选择对应的client
    platform_type = p.get("platform_type", "mofang")

    if platform_type == "hudi":
        # 狐蒂云平台
        from hudi_client import HudiClient
        return HudiClient(p)
    else:
        # 标准魔方财务平台
        return MofangClient(p)

