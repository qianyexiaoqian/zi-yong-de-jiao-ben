# -*- coding: utf-8 -*-
"""
狐蒂云平台客户端 - 基于标准魔方财务API，仅对魔改部分做适配
标准API：列表/详情/电源/状态/重置密码 等均走标准 /v1/ 接口
狐蒂云魔改适配（仅以下三项）：
1. VNC → POST /provision/default func=vnc
2. 重装系统 → /dcim/check_reinstall + /host/dedicatedserver(cloud_os) + /provision/default func=reinstall
3. 救援系统 → POST /provision/default func=rescue_system
其他：登录仅支持 API 方式（/v1/login_api），JWT存储在cookie ZJMF_0DE0451317118732
"""
import requests
import logging
from urllib.parse import urljoin, urlparse

logger = logging.getLogger(__name__)


class HudiClient:
    def __init__(self, platform):
        self.platform = platform
        self.base_url = platform["url"].rstrip("/")
        self._domain = urlparse(self.base_url).hostname or ""
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        })
        self._login_in_progress = False
        
        # 如果有JWT，设置到cookie中
        if platform.get("jwt"):
            self.session.cookies.set("ZJMF_0DE0451317118732", platform["jwt"], domain=self._domain)

    def _url(self, path):
        return urljoin(self.base_url, path)

    def _save_jwt(self, jwt_token):
        """保存JWT到数据库和session cookie"""
        from models import platform_update_jwt
        import time
        platform_update_jwt(self.platform["id"], jwt_token, int(time.time()) + 7200)
        self.platform["jwt"] = jwt_token
        self.session.cookies.set("ZJMF_0DE0451317118732", jwt_token, domain=self._domain)

    def _request(self, method, path, **kwargs):
        """发起请求，自动处理token过期和重试"""
        # 确保JWT在cookie中
        if self.platform.get("jwt") and "ZJMF_0DE0451317118732" not in self.session.cookies:
            self.session.cookies.set("ZJMF_0DE0451317118732", self.platform["jwt"], domain=self._domain)

        try:
            resp = self.session.request(method, self._url(path), timeout=30, **kwargs)
        except Exception as e:
            logger.error(f"Request failed: {e}")
            return {"status": 0, "msg": f"请求失败: {str(e)}"}

        # 尝试解析JSON
        try:
            data = resp.json()
        except:
            # 非JSON响应，可能是HTML错误页面或token过期
            if resp.status_code in [404, 302, 401]:
                is_token_expired = True
            else:
                return {"status": 0, "msg": f"非JSON响应: {resp.text[:200]}"}
        else:
            # 检测token过期
            is_token_expired = False
            if data.get("status") == 405 or resp.status_code == 405:
                is_token_expired = True

        # 自动重试登录
        if is_token_expired and not self._login_in_progress:
            logger.info("Token expired, attempting re-login...")
            login_result = self.login()
            
            if login_result.get("status") == 1:
                # 登录成功，重试原请求
                try:
                    resp = self.session.request(method, self._url(path), timeout=30, **kwargs)
                    try:
                        data = resp.json()
                    except:
                        return {"status": 0, "msg": "重试后仍返回非JSON响应"}
                except Exception as e:
                    return {"status": 0, "msg": f"重试请求失败: {str(e)}"}
            elif login_result.get("status") == -2:
                # 需要极验验证码
                return login_result
            elif login_result.get("status") == -3:
                # 需要二次验证
                return login_result
            else:
                return {"status": 0, "msg": "自动登录失败"}

        return data

    def login(self, lot_number="", pass_token="", gen_time="", captcha_output=""):
        """
        狐蒂云登录 - 仅使用API密钥方式 (/v1/login_api)
        如果遇到验证码，返回 status: -2 让前端弹窗给用户手动过
        """
        self._login_in_progress = True
        has_captcha = bool(lot_number and pass_token and gen_time and captcha_output)
        try:
            p = self.platform
            path = "/v1/login_api"
            payload = {"account": p["account"], "password": p["password"]}

            # 如果前端传来了极验验证码参数，附加到请求中
            if has_captcha:
                payload["captcha_id"] = "24175a896d8650f94aa5ba56d0caf7ef"
                payload["lot_number"] = lot_number
                payload["pass_token"] = pass_token
                payload["gen_time"] = gen_time
                payload["captcha_output"] = captcha_output

            headers = {"Content-Type": "application/x-www-form-urlencoded"}

            try:
                resp = requests.post(self._url(path), data=payload, headers=headers, timeout=30)
                data = resp.json()
            except Exception as e:
                logger.error(f"Login request failed: {e}")
                return {"status": 0, "msg": f"登录请求失败: {str(e)}"}

            logger.info(f"Hudi login response: status={data.get('status')}, msg={data.get('msg')}")

            # 登录成功
            if data.get("status") == 200:
                jwt_token = resp.cookies.get("ZJMF_0DE0451317118732", "")
                if not jwt_token:
                    jwt_token = data.get("jwt", "")
                if jwt_token:
                    self._save_jwt(jwt_token)
                    return {"status": 1, "msg": "登录成功"}
                else:
                    return {"status": 0, "msg": "登录成功但未获取到JWT"}

            # 带了验证码仍失败，返回真实错误，不再循环
            if has_captcha:
                return {"status": 0, "msg": data.get("msg", "验证码验证失败，请重试")}

            # API返回需要验证码（status=-2 或其他非200），弹到前端让用户手动过
            if data.get("status") == -2 or data.get("msg", "").lower().find("captcha") >= 0:
                return {
                    "status": -2,
                    "msg": "need_captcha",
                    "captcha_id": "24175a896d8650f94aa5ba56d0caf7ef",
                    "geetest": True,
                    "platform_type": "hudi",
                    "login_msg": data.get("msg", "需要完成行为验证")
                }

            # 其他错误直接返回
            return {"status": 0, "msg": data.get("msg", "登录失败")}

        finally:
            self._login_in_progress = False

    def ensure_jwt(self):
        """确保有有效的JWT"""
        if not self.platform.get("jwt"):
            return self.login()
        return {"status": 1, "msg": "JWT已存在"}

    def get_hosts(self, page=1, limit=20, keywords=""):
        """获取机器列表 — 标准API"""
        params = {"page": page, "limit": limit}
        if keywords:
            params["keywords"] = keywords
        return self._request("GET", "/v1/hosts", params=params)

    def get_host(self, host_id):
        """获取机器详情 — 标准API + 补充 port"""
        result = self._request("GET", f"/v1/hosts/{host_id}")
        # 标准API不含端口，从 /host/dedicatedserver 补充
        try:
            detail = self._request("GET", "/host/dedicatedserver", params={"host_id": host_id})
            if detail.get("status") == 200:
                hd = detail.get("data", {}).get("host_data", {})
                host = result.get("data", {}).get("host", result.get("data", {}))
                if isinstance(host, dict):
                    port = hd.get("port", 0)
                    if not port:
                        # 端口为0或不存在，根据操作系统推断默认端口
                        os_name = (hd.get("os") or host.get("os") or "").lower()
                        port = 3389 if "win" in os_name else 22
                    host["port"] = port
        except Exception:
            pass
        return result

    def get_status(self, host_id, stype="host"):
        """获取运行状态 — 标准API"""
        return self._request("GET", f"/v1/hosts/{host_id}/module/status", params={"type": stype})

    def power_on(self, host_id):
        return self._request("PUT", f"/v1/hosts/{host_id}/module/on")

    def power_off(self, host_id):
        return self._request("PUT", f"/v1/hosts/{host_id}/module/off")

    def reboot(self, host_id):
        return self._request("PUT", f"/v1/hosts/{host_id}/module/reboot")

    def hard_off(self, host_id):
        return self._request("PUT", f"/v1/hosts/{host_id}/module/hard_off")

    def hard_reboot(self, host_id):
        return self._request("PUT", f"/v1/hosts/{host_id}/module/hard_reboot")

    def repassword(self, host_id, password):
        """重置密码 — 标准API"""
        return self._request("POST", f"/v1/hosts/{host_id}/module/repassword", data={"password": password})

    # ---- 以下三个功能狐蒂云魔改了，需要适配 ----

    def _provision(self, host_id, func, extra=None):
        """狐蒂云通用操作入口 POST /provision/default"""
        payload = {"id": host_id, "func": func}
        if extra:
            payload.update(extra)
        return self._request("POST", "/provision/default", data=payload)

    def vnc(self, host_id):
        """获取VNC — 狐蒂云魔改：POST /provision/default func=vnc"""
        return self._provision(host_id, "vnc")

    def get_reinstall_os(self, host_id):
        """获取可重装系统列表 — 狐蒂云魔改：先 check_reinstall，再从机器详情取 cloud_os"""
        check = self._request("POST", "/dcim/check_reinstall", data={"id": host_id})
        if check.get("status") != 200:
            return check

        detail = self._request("GET", "/host/dedicatedserver", params={"host_id": host_id})
        if detail.get("status") != 200:
            return detail

        cloud_os = detail.get("data", {}).get("cloud_os", [])
        os_list = []
        for o in cloud_os:
            os_list.append({
                "os_id": o.get("id", ""),
                "name": o.get("name", ""),
                "group_name": o.get("group", ""),
            })
        return {"status": 200, "data": {"os": os_list}}

    def reinstall(self, host_id, os_id, password=""):
        """重装系统 — 狐蒂云魔改：POST /provision/default func=reinstall"""
        os_group = ""
        detail = self._request("GET", "/host/dedicatedserver", params={"host_id": host_id})
        if detail.get("status") == 200:
            for o in detail.get("data", {}).get("cloud_os", []):
                if str(o.get("id")) == str(os_id):
                    os_group = o.get("group", "")
                    break

        extra = {"os": os_id, "code": "undefined"}
        if os_group:
            extra["os_group"] = os_group
        return self._provision(host_id, "reinstall", extra)

    def rescue(self, host_id, rescue_id="1", system="2", temp_pass="", force="on"):
        """救援系统 — 狐蒂云魔改：POST /provision/default func=rescue_system"""
        extra = {"system": system, "force": force}
        if temp_pass:
            extra["temp_pass"] = temp_pass
        return self._provision(host_id, "rescue_system", extra)

    def exit_rescue(self, host_id):
        """退出救援系统 — 狐蒂云魔改：POST /provision/custom/{host_id} func=exitRescue"""
        payload = {"id": host_id, "func": "exitRescue"}
        return self._request("POST", f"/provision/custom/{host_id}", data=payload)

    def get_rescue_list(self, host_id):
        """获取救援系统列表 — 标准API"""
        return self._request("GET", f"/v1/hosts/{host_id}/module/rescue")

    def update_host_remark(self, host_id, remark):
        """更新服务器备注 — 狐蒂云魔改：POST /host/remark"""
        payload = {"id": host_id, "remark": remark}
        return self._request("POST", "/host/remark", data=payload)
